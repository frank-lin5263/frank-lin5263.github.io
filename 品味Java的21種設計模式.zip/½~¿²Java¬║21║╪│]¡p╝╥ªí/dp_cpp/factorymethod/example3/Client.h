#pragma once

#include "ExportOperate.h"
#include "ExportDBOperate.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace factorymethod {
namespace example3 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}