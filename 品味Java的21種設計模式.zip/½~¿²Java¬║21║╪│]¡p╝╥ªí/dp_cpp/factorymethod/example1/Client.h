#pragma once

#include "ExportOperate.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace factorymethod {
namespace example1 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}