#include "Product.h"

namespace cn {
namespace javass {
namespace dp {
namespace factorymethod {
namespace example2 {
}
}
}
}
}
