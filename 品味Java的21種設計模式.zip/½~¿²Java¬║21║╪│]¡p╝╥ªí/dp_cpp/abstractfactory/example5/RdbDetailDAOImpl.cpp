#include "RdbDetailDAOImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {

void RdbDetailDAOImpl::saveOrderDetail() {
    puts("now in RdbDetailDAOImpl saveOrderDetail");
}
}
}
}
}
}
