#include "XmlDetailDAOImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {

void XmlDetailDAOImpl::saveOrderDetail() {
    puts("now in XmlDAOImpl2 saveOrderDetail");
}
}
}
}
}
}
