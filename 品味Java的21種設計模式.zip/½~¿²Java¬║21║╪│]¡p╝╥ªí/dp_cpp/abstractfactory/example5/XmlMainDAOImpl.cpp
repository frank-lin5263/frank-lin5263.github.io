#include "XmlMainDAOImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {

void XmlMainDAOImpl::saveOrderMain() {
    puts("now in XmlMainDAOImpl saveOrderMain");
}
}
}
}
}
}
