#pragma once

#include "DAOFactory.h"
#include "RdbDAOFactory.h"
#include "OrderMainDAO.h"
#include "OrderDetailDAO.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {

class BusinessObject {
    static void main(std::string args[]);
};

}
}
}
}
}