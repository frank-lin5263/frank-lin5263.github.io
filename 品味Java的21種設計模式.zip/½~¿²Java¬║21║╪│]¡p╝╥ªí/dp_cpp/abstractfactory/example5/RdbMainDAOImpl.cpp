#include "RdbMainDAOImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {

void RdbMainDAOImpl::saveOrderMain() {
    puts("now in RdbMainDAOImpl saveOrderMain");
}
}
}
}
}
}
