#include "DAOFactory.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example5 {
}
}
}
}
}
