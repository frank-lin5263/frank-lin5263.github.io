#pragma once

#include "ComputerEngineer.h"
#include "AbstractFactory.h"
#include "Schema1.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example3 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}