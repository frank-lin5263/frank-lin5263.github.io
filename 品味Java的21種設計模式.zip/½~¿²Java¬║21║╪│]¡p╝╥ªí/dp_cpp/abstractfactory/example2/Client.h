#pragma once

#include "AbstractFactory.h"
#include "ConcreteFactory1.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example2 {

class Client {

    static void main(std::string args[]);
};

}
}
}
}
}