#include "ProductB1.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example2 {
}
}
}
}
}
