#pragma once

#include "MemoryApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example4 {
///
/// <summary> * �ִ��ڴ���� </summary>
///
class HyMemory : public MemoryApi {
public:
    virtual void cacheData();
};

}
}
}
}
}