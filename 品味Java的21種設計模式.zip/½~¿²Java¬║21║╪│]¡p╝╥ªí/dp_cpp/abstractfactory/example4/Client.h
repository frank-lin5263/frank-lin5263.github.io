#pragma once

#include "ComputerEngineer.h"
#include "AbstractFactory.h"
#include "Schema3.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example4 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}