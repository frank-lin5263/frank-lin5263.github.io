#include "HyMemory.h"

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example4 {

void HyMemory::cacheData() {
    puts("现在正在使用现代内存");
}
}
}
}
}
}
