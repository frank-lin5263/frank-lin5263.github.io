#pragma once

#include "ComputerEngineer.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace abstractfactory {
namespace example1 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}