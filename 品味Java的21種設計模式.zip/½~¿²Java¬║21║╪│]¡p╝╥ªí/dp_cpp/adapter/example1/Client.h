#pragma once

#include "Adaptee.h"
#include "Adapter.h"
#include "Target.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example1 {
///
/// <summary> * ʹ���������Ŀͻ��� </summary>
///
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}