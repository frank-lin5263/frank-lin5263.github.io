#include "Adaptee.h"

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example1 {

void Adaptee::specificRequest() {
    //具体的功能处理
}
}
}
}
}
}
