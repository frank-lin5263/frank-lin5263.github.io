#pragma once

#include "LogModel.h"
#include "LogFileOperate.h"
#include "LogFileOperateApi.h"
#include "LogDbOperateApi.h"
#include "LogDbOperate.h"
#include "TwoDirectAdapter.h"
#include <string>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example4 {
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}