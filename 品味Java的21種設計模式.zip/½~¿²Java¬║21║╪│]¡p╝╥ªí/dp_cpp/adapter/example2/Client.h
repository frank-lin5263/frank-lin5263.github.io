#pragma once

#include "LogModel.h"
#include "LogFileOperate.h"
#include "LogFileOperateApi.h"
#include <string>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example2 {
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}