#pragma once

#include "LogModel.h"
#include "LogFileOperate.h"
#include "LogFileOperateApi.h"
#include "Adapter.h"
#include "LogDbOperateApi.h"
#include <string>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example3 {
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}