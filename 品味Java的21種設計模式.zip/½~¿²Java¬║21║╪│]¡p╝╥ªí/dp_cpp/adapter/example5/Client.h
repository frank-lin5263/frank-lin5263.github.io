#pragma once

#include "LogModel.h"
#include "LogDbOperateApi.h"
#include "ClassAdapter.h"
#include <string>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example5 {
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}