#include "LogDbOperateApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace adapter {
namespace example5 {
}
}
}
}
}
