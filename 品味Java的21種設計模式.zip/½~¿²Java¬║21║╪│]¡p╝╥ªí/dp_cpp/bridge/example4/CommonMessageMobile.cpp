#include "CommonMessageMobile.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example4 {

void CommonMessageMobile::send(std::string message, std::string toUser) {
}
}
}
}
}
}
