#include "UrgencyMessageMobile.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example4 {

void UrgencyMessageMobile::send(std::string message, std::string toUser) {
}

object *UrgencyMessageMobile::watch(std::string messageId) {
    return 0;
}
}
}
}
}
}
