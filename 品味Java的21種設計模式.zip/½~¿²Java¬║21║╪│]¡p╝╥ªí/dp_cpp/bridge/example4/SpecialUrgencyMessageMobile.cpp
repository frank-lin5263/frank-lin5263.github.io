#include "SpecialUrgencyMessageMobile.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example4 {

void SpecialUrgencyMessageMobile::hurry(std::string messageId) {
    // TODO Auto-generated method stub

}

void SpecialUrgencyMessageMobile::send(std::string message, std::string toUser) {
    // TODO Auto-generated method stub

}
}
}
}
}
}
