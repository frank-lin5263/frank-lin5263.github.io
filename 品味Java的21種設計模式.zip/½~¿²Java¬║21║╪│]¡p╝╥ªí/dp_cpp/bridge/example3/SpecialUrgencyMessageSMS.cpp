#include "SpecialUrgencyMessageSMS.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example3 {

void SpecialUrgencyMessageSMS::hurry(std::string messageId) {
    // TODO Auto-generated method stub

}

void SpecialUrgencyMessageSMS::send(std::string message, std::string toUser) {
    // TODO Auto-generated method stub

}
}
}
}
}
}
