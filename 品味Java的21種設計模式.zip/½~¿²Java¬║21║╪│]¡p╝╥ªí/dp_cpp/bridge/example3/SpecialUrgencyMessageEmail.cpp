#include "SpecialUrgencyMessageEmail.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example3 {

void SpecialUrgencyMessageEmail::hurry(std::string messageId) {
    // TODO Auto-generated method stub

}

void SpecialUrgencyMessageEmail::send(std::string message, std::string toUser) {
    // TODO Auto-generated method stub

}
}
}
}
}
}
