#pragma once

#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example8 {


class JDBCTest {
    static void main(std::string args[]) throw(Exception);
};

}
}
}
}
}