#pragma once

#include "CommonMessageSMS.h"
#include "Message.h"
#include "CommonMessageEmail.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example2 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}