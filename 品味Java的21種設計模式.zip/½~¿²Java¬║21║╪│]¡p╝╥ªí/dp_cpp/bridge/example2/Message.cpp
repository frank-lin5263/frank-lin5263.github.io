#include "Message.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example2 {
}
}
}
}
}
