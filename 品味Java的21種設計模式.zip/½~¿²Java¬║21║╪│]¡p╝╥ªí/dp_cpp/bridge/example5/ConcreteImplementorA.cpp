#include "ConcreteImplementorA.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example5 {

void ConcreteImplementorA::operationImpl() {
    //真正的实现
}
}
}
}
}
}
