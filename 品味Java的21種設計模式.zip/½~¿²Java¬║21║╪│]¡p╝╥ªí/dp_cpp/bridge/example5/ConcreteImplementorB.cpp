#include "ConcreteImplementorB.h"

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example5 {

void ConcreteImplementorB::operationImpl() {
    //真正的实现
}
}
}
}
}
}
