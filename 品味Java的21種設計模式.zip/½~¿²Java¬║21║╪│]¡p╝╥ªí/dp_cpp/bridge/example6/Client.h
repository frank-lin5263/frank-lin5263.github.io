#pragma once

#include "MessageImplementor.h"
#include "MessageSMS.h"
#include "AbstractMessage.h"
#include "CommonMessage.h"
#include "UrgencyMessage.h"
#include "SpecialUrgencyMessage.h"
#include "MessageMobile.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace bridge {
namespace example6 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}