#pragma once

#include "EncryptOutputStream.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example5 {


class Client {
    static void main(std::string args[]) throw(Exception);
};

}
}
}
}
}