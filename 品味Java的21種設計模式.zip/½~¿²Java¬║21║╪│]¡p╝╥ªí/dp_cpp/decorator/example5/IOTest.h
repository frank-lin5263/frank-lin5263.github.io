#pragma once

#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example5 {
class IOTest {
    static void main(std::string args[]) throw(Exception);
};

}
}
}
}
}