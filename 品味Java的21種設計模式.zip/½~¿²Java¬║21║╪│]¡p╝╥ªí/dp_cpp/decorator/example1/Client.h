#pragma once

#include "Prize.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example1 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}