#include "ConcreteComponent.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example3 {

void ConcreteComponent::operation() {
    //相应的功能处理
}
}
}
}
}
}
