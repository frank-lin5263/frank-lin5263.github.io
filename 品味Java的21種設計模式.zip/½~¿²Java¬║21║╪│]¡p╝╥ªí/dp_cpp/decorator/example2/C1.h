#pragma once

#include "A.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

class C1 : public A {
public:
    virtual void c11();
};

}
}
}
}
}