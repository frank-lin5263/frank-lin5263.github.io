#include "C1.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

void C1::c11() {
    puts("now in C1.c11");
}
}
}
}
}
}
