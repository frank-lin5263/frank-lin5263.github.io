#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

class A {
public:
    virtual void a1();
};

}
}
}
}
}