#include "B.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

void B::b1() {
    puts("now in B.b1");
}
}
}
}
}
}
