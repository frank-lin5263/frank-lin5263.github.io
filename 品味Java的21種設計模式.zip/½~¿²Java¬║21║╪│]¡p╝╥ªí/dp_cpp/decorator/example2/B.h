#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

class B {
public:
    virtual void b1();
};

}
}
}
}
}