#include "A.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example2 {

void A::a1() {
    puts("now in A.a1");
}
}
}
}
}
}
