#pragma once

#include "CheckDecorator.h"
#include "GoodsSaleEbi.h"
#include "GoodsSaleEbo.h"
#include "LogDecorator.h"
#include "SaleModel.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example6 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}