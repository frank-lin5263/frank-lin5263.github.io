#include "GoodsSaleEbi.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example6 {
}
}
}
}
}
