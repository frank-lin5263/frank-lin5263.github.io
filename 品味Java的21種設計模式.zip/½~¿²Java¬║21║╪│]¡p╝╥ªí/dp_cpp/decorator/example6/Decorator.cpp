#include "Decorator.h"

namespace cn {
namespace javass {
namespace dp {
namespace decorator {
namespace example6 {

Decorator::Decorator(GoodsSaleEbi *ebi) {
    this->ebi = ebi;
}
}
}
}
}
}
