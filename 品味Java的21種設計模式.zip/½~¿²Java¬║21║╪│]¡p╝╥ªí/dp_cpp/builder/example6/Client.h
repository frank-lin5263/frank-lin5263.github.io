#pragma once

#include "InsuranceContract.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace builder {
namespace example6 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}