#pragma once

#include "ExportHeaderModel.h"
#include "ExportDataModel.h"
#include "ExportFooterModel.h"
#include "TxtBuilder.h"
#include "Director.h"
#include "XmlBuilder.h"
#include <string>
#include <map>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace builder {
namespace example3 {


class Client {
    static void main(std::string args[]);
};

}
}
}
}
}