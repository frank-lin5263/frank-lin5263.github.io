#include "ExportFooterModel.h"

namespace cn {
namespace javass {
namespace dp {
namespace builder {
namespace example1 {

std::string ExportFooterModel::getExportUser() {
    return exportUser;
}

void ExportFooterModel::setExportUser(std::string exportUser) {
    this->exportUser = exportUser;
}
}
}
}
}
}
