#pragma once

#include "ExportHeaderModel.h"
#include "ExportDataModel.h"
#include "ExportFooterModel.h"
#include "ExportToTxt.h"
#include "ExportToXml.h"
#include <string>
#include <map>
#include <vector>

namespace cn {
namespace javass {
namespace dp {
namespace builder {
namespace example1 {


class Client {
    static void main(std::string args[]);
};

}
}
}
}
}