#pragma once

#include "GigaMainBoard.h"
#include "MainBoardApi.h"
#include "OpenCommand.h"
#include "ResetCommand.h"
#include "Box.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example3 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}