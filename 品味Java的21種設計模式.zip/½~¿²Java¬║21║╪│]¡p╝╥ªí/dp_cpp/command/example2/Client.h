#pragma once

#include "GigaMainBoard.h"
#include "MainBoardApi.h"
#include "OpenCommand.h"
#include "Box.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example2 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}