#pragma once

#include "Invoker.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example9 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}