#pragma once

#include "Command.h"

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example9 {

class Invoker {
public:
    virtual void startPrint(Command *cmd);
};
}
}
}
}
}