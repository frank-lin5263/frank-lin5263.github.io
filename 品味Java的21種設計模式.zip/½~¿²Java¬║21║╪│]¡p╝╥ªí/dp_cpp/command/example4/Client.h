#pragma once

#include "Operation.h"
#include "OperationApi.h"
#include "AddCommand.h"
#include "SubstractCommand.h"
#include "Calculator.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example4 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}