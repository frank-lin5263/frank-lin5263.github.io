#include "HotCook.h"

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example5 {

void HotCook::cook(std::string name) {
    puts("本厨师正在做：" + name);
}
}
}
}
}
}
