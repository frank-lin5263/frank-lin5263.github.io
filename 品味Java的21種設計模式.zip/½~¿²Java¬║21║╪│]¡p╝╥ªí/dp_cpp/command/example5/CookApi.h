#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example5 {
///
/// <summary> * ��ʦ�Ľӿ� </summary>
///
class CookApi {
    ///
    ///  <summary> * ʾ�⣬���˵ķ��� </summary>
    ///  * <param name="name"> ���� </param>
    ///
public:
    virtual public void cook(std::string) = 0;
};

}
}
}
}
}