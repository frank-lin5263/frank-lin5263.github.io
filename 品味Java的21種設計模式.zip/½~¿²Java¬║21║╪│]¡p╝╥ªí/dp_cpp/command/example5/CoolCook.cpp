#include "CoolCook.h"

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example5 {

void CoolCook::cook(std::string name) {
    puts("凉菜" + name + "已经做好，本厨师正在装盘。");
}
}
}
}
}
}
