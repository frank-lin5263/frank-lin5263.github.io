#pragma once

#include "Waiter.h"
#include "Command.h"
#include "ChopCommand.h"
#include "DuckCommand.h"
#include "PorkCommand.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example5 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}