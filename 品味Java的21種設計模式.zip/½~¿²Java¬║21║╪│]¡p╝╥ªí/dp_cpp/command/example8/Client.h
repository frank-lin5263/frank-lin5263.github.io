#pragma once

#include "Command.h"
#include "PrintService.h"
#include "Invoker.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example8 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}