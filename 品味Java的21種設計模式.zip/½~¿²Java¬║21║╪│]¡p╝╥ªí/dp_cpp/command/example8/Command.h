#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example8 {

class Command {
public:
    virtual public void execute() = 0;
};

}
}
}
}
}