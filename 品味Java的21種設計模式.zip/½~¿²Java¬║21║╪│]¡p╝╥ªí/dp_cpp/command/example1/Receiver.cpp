#include "Receiver.h"

namespace cn {
namespace javass {
namespace dp {
namespace command {
namespace example1 {

void Receiver::action() {
    //真正执行命令操作的功能代码
}
}
}
}
}
}
