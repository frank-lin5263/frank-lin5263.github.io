#include "Component.h"

namespace cn {
namespace javass {
namespace dp {
namespace composite {
namespace example5 {
}
}
}
}
}
