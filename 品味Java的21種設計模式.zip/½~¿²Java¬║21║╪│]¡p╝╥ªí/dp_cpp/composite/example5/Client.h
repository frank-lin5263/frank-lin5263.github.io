#pragma once

#include "Composite.h"
#include "Leaf.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace composite {
namespace example5 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}