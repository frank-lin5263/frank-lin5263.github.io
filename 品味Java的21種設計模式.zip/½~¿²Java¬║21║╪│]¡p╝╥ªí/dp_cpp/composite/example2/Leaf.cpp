#include "Leaf.h"

namespace cn {
namespace javass {
namespace dp {
namespace composite {
namespace example2 {

void Leaf::someOperation() {
    // do something
}
}
}
}
}
}
