#pragma once

#include "Composite.h"
#include "Component.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace composite {
namespace example7 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}