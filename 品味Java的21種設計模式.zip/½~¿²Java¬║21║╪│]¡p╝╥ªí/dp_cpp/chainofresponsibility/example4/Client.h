#pragma once

#include "Handler.h"
#include "GeneralManager.h"
#include "DepManager.h"
#include "ProjectManager.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace chainofresponsibility {
namespace example4 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}