#include "Handler.h"

namespace cn {
namespace javass {
namespace dp {
namespace chainofresponsibility {
namespace example3 {

void Handler::setSuccessor(Handler *successor) {
    this->successor = successor;
}
}
}
}
}
}
