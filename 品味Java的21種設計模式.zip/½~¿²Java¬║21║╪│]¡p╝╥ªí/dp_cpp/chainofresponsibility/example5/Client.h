#pragma once

#include "Handler.h"
#include "GeneralManager2.h"
#include "DepManager2.h"
#include "ProjectManager2.h"
#include "FeeRequestModel.h"
#include "PreFeeRequestModel.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace chainofresponsibility {
namespace example5 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}