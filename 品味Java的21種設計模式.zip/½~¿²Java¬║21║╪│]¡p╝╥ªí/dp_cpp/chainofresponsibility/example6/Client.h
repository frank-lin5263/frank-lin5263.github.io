#pragma once

#include "GoodsSaleEbo.h"
#include "SaleModel.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace chainofresponsibility {
namespace example6 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}