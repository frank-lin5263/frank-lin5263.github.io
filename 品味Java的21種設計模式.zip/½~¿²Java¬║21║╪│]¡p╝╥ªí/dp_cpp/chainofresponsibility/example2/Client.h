#pragma once

#include "ConcreteHandler1.h"
#include "Handler.h"
#include "ConcreteHandler2.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace chainofresponsibility {
namespace example2 {
///
/// <summary> * ְ�����Ŀͻ��ˣ�����ֻ�Ǹ�ʾ�� </summary>
///
class Client {
    static void main(std::string args[]);
};

}
}
}
}
}