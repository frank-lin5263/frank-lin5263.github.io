#pragma once

#include "ConfigManager.h"
#include "ConfigModel.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example3 {
///
/// <summary> * ʾ�����ɱ��ֲ��ģ�� </summary>
///
class Presentation {
public:
    virtual void generate();
};
}
}
}
}
}