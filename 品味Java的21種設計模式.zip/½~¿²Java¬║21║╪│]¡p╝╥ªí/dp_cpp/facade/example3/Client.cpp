#include "Client.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example3 {

void Client::main(std::string args[]) {
    new Facade()->generate();
}
}
}
}
}
}
