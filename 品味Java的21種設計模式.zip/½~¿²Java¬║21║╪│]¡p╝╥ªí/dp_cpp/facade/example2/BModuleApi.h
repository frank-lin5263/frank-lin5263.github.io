#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class BModuleApi {
public:
    virtual public void testB() = 0;
};

}
}
}
}
}