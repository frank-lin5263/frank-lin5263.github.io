#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class CModuleApi {
public:
    virtual public void testC() = 0;
};

}
}
}
}
}