#include "BModuleApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {
}
}
}
}
}
