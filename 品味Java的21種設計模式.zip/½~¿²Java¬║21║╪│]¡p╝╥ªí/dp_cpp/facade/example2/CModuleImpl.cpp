#include "CModuleImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

void CModuleImpl::testC() {
    puts("现在在C模块里面操作testC方法");
}
}
}
}
}
}
