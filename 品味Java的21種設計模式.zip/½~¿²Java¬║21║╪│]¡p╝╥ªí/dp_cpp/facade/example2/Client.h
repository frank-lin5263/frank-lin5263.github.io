#pragma once

#include "Facade.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class Client {
    static void main(std::string args[]);
};

}
}
}
}
}