#pragma once

#include "AModuleApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class AModuleImpl : public AModuleApi {
public:
    virtual void testA();
};

}
}
}
}
}