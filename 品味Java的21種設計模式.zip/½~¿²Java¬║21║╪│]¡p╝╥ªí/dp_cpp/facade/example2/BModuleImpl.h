#pragma once

#include "BModuleApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class BModuleImpl : public BModuleApi {


public:
    virtual void testB();

};

}
}
}
}
}