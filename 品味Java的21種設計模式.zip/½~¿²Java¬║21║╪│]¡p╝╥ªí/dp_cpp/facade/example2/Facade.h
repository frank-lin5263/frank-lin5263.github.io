#pragma once

#include "AModuleApi.h"
#include "AModuleImpl.h"
#include "BModuleApi.h"
#include "BModuleImpl.h"
#include "CModuleApi.h"
#include "CModuleImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {
///
/// <summary> * ��۶��� </summary>
///
class Facade {
    ///
    ///  <summary> * ʾ�ⷽ��������ͻ���Ҫ�Ĺ��� </summary>
    ///
public:
    virtual void test();
};

}
}
}
}
}