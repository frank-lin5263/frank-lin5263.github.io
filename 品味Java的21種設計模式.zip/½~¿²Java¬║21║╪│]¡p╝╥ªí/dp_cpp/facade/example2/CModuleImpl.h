#pragma once

#include "CModuleApi.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

class CModuleImpl : public CModuleApi {


public:
    virtual void testC();

};

}
}
}
}
}