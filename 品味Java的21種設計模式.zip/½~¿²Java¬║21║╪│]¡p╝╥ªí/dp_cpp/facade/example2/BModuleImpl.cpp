#include "BModuleImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

void BModuleImpl::testB() {
    puts("现在在B模块里面操作testB方法");
}
}
}
}
}
}
