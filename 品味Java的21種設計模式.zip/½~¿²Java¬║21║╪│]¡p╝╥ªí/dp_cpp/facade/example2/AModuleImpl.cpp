#include "AModuleImpl.h"

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example2 {

void AModuleImpl::testA() {
    puts("现在在A模块里面操作testA方法");
}
}
}
}
}
}
