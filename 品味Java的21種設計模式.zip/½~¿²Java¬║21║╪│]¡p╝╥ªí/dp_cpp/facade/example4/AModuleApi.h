#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example4 {

class AModuleApi {
public:
    virtual public void a1() = 0;
    virtual public void a2() = 0;
    virtual public void a3() = 0;
};

}
}
}
}
}