#pragma once

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example4 {

class FacadeApi {
public:
    virtual public void a1() = 0;
    virtual public void b1() = 0;
    virtual public void c1() = 0;
    virtual public void test() = 0;
};

}
}
}
}
}