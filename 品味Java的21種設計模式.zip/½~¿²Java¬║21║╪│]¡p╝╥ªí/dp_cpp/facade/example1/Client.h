#pragma once

#include "Presentation.h"
#include "Business.h"
#include "DAO.h"
#include <string>

namespace cn {
namespace javass {
namespace dp {
namespace facade {
namespace example1 {

class Client {
    static void main(std::string args[]);
};
}
}
}
}
}