angular.module("ArchivesApp").controller('SendQueryController', function($scope, $http, $uibModal, archivesService,
    archivesConstant, accountFactory, stateChangeFactory) {
    $scope.filterContent = {};
    $scope.archivesService = angular.copy(archivesService);
    $scope.archivesService.registerApp('SendQueryController');

    $scope.queryFunc = function() {
        var url = stateChangeFactory.getStateURI() +"/list"
        $http.post(url).then(function (response) {
            $scope.toggleResult = true;
            $scope.resultContent = response.data.resultData;
            $scope.archivesService.setSessionStorage(angular.toJson($scope.filterContent));
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    $scope.$on('$viewContentLoaded', function() {
        var sessionFilterContent = $scope.archivesService.getSessionStorage();

        if (typeof sessionFilterContent === "undefined") {
            $scope.initFilter();
        } else {
            $scope.filterContent = angular.fromJson(sessionFilterContent);
            $scope.filterContent.dateFrom = $scope.convertToDate($scope.filterContent.dateFrom);
            $scope.filterContent.dateTo = $scope.convertToDate($scope.filterContent.dateTo);
            $scope.queryFunc();
        }
    });

    $scope.initFilter = function() {
        $scope.filterContent = {};
        $scope.filterContent.dateFrom = new Date();
        $scope.filterContent.dateTo = new Date();
        $scope.filterContent.hourFrom = "00";
        $scope.filterContent.hourTo = "23";

        $scope.toggleResult = true;
        $scope.toggleAlert = false;
        $scope.resultContent = [];
        $scope.archivesService.resetSorterAndPager();
    };

    $scope.convertToDate = function(value) {
        return typeof value === "undefined" || value === "" || value === 0 ? "" : new Date(value);
    };

    $scope.preViewFunc = function(rowData) {
        var params = {
            documentId: rowData.documentId
        }
        var endpoint = stateChangeFactory.getStateURI() +"/preview"
        var url = endpoint + accountFactory.getFormatParams(params);
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            windowOpenFile(response);
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    function windowOpenFile(response) {
        var html = document.createElement('a');
        html.href = URL.createObjectURL(new File([response.data], { type: 'text/html' }));
        html.class = 'hidden';
        html.download = 'send.html';
        document.body.appendChild(html);
        window.open(html.href, 'PreView', 'width=1280,height=960');
    }

    $scope.detailModalFunc = function(currentRowData) {
        $uibModal.open({
            templateUrl: archivesConstant.APP_PATH + "/views/OfficialFolder/sendQueryDetail.html",
            controller: "SendQueryDetailController",
            size: 'lg',
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [
                            archivesConstant.APP_PATH +
                            '/controllers/OfficialFolder/SendQueryDetailController.js',
                        ]
                    });
                }],
                rowData: function() {
                    return currentRowData;
                }
            }
        });
    };
});