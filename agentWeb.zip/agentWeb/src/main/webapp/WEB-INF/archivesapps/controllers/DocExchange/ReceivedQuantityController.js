angular.module("ArchivesApp").controller('ReceivedQuantityController', function($scope, $http) {
    console.log('ReceivedQuantityController: ');
});