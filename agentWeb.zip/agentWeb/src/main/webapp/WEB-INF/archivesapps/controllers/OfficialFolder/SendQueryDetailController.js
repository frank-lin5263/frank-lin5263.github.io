angular.module("ArchivesApp").controller('SendQueryDetailController', function($scope, $http, $uibModalInstance,
    archivesService, accountFactory, stateChangeFactory, rowData) {
    $scope.archivesService = angular.copy(archivesService);
    $scope.archivesService.registerApp('SendQueryDetailController');
    $scope.sendDetailContent = angular.copy(rowData);
    $scope.toggleResult = true;
    var testResultContent = [{
        "print": true,
        "attach": '是',
        "receiveName": 'TEST001837',
        "receiveStatus": '使用者確認',
        "receiveDateTime": '2017/09/15 AM 01:01:01',
        "rejectDataTime": '',
        "rejectReason": ''
    }];

    $scope.resultContent = testResultContent;

    $scope.cancel = function() {
        $uibModalInstance.dismiss();
    }

    function anchorClickDownload(response, documentId) {
        var zip = document.createElement('a');
        zip.href = URL.createObjectURL(new Blob([response.data], { type: 'application/octet-stream' }));
        zip.id = 'zipPath';
        zip.class = 'hidden';
        zip.download = documentId + '.zip';
        document.body.appendChild(zip);
        zip.click();
        document.body.removeChild(zip);
    }

    function processDownload(action, params) {
        var endpoint = stateChangeFactory.getStateURI() + action;
        var url = endpoint + accountFactory.getFormatParams(params);
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            anchorClickDownload(response, params.documentId);
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    $scope.downloadAll = function() {
        var params = {
            documentId: $scope.sendDetailContent.documentId
        }
        processDownload("/download", params);
    }

    $scope.downloadFunc = function(fileName) {
        console.log('downloadFunc: ' + fileName);
/*        var params = {
            documentId: $scope.sendDetailContent.documentId,
            fileName: fileName
        }
        processDownload("/filename", params);*/
    }

    $scope.preView = function() {
        var params = {
            documentId: $scope.sendDetailContent.documentId
        }
        var endpoint = stateChangeFactory.getStateURI() +"/preview";
        var url = endpoint + accountFactory.getFormatParams(params);
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            windowOpenFile(response);
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    function windowOpenFile(response) {
        var html = document.createElement('a');
        html.href = URL.createObjectURL(new File([response.data], { type: 'text/html' }));
        html.class = 'hidden';
        html.download = 'send.html';
        document.body.appendChild(html);
        window.open(html.href, 'PreView', 'width=1280,height=960');
    }
});