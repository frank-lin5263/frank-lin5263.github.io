angular.module("ArchivesApp").controller('ReceivedQueryDetailController', function($scope, $http, $uibModalInstance,
    archivesService, rowData) {
    $scope.archivesService = angular.copy(archivesService);
    $scope.archivesService.registerApp('ReceivedQueryDetailController');
    $scope.detailContent = angular.copy(rowData);
    $scope.toggleResult = true;

    $scope.downloadAll = function() {
        console.log('downloadAll: ');
    }

    $scope.downloadFunc = function(appendix) {
        console.log('downloadFunc: ' + appendix);
    }


    $scope.cancel = function() {
        $uibModalInstance.dismiss();
    }
});