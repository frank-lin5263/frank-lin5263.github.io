angular.module('ArchivesApp').controller('HomeController', function($scope, $state, $http, httpAuth, archivesConstant) {

    $scope.$on('$viewContentLoaded', function() {
        var homeState = $state.get('home');
        var url = null;
        if (homeState != null) {
            url = homeState.url;
        } else {
            homeState = $state.get('home_not_auth');
            if (homeState != null) {
                url = homeState.url;
            }
        }
        if (url != null) {
            actionAddress = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + url;
            $http.get(actionAddress).then (function(response) {
                $("#viewArea").text(response.data.viewText);
            });
        }
    });
    $scope.errorMessage = angular.element('#errorMessage').val();
    if ($scope.errorMessage.length > 0) {
        $scope.toggleAlert = true;
    } else {
        $scope.toggleAlert = false;
    }
});