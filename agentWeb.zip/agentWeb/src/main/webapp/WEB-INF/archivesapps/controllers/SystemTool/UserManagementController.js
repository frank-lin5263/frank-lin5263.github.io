angular.module('ArchivesApp').controller('UserManagementController', function($scope, $http, $uibModal, stateChangeFactory,
    archivesService, archivesConstant) {
        $scope.$on('$viewContentLoaded', function() {
            var url = stateChangeFactory.getStateURIByName('/roleManage') + "/listRoleName";
            $scope.filterQueryUsers();
            $http.get(url).success(function(response) {
                $scope.roleList = response;
            });
        });
        $scope.userList = [];
        $scope.isQueried = false;
        $scope.status = {
            active: true,
            inactive: true
        };

        $scope.archivesService = archivesService;
        $scope.archivesService.sorter.columnName = "account";

        $scope.filterQueryUsers = function() {
            var nameKeyWord = {
                keyWord: $('#nameKeyWord').val(),
                verification: false,
                active: $scope.status.active,
                inactive: $scope.status.inactive
            };

            var url = stateChangeFactory.getStateURI()  + "/list";
            $http.get(url, {
                params: nameKeyWord
            }).then(function successCallback(response) {
                $scope.userList = response.data;
                if (response.data.length == 0) {
                    $scope.isQueried = true;
                    $scope.errorPrint = archivesConstant.SEARCH_WITHOUT_RESULT;
                }
            }, function errorCallback(response) {
                exceptionViewer(response, false);
            });
        };

        $scope.selected = {
            user: $scope.userList[0]
        };

        $scope.openUserDetail = function() {
            var uibModalInstance = $uibModal.open({
                templateUrl: archivesConstant.APP_PATH + "/views/SystemTool/userAccountModify.html",
                controller: "UserAccountModifyController",
                size: 'lg',
                resolve: {
                    deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                        return $ocLazyLoad.load({
                            name: 'ArchivesApp',
                            insertBefore: '#ng_load_plugins_before',
                            files: [
                                archivesConstant.APP_PATH +
                                '/controllers/SystemTool/UserAccountModifyController.js',
                            ]
                        });
                    }],
                    user: function() {
                        return $scope.selected.user;
                    },
                    roleList: function() {
                        return $scope.roleList;
                    },
                    userList: function(){
                        return $scope.userList;
                    }
                }
            });
        };
    });