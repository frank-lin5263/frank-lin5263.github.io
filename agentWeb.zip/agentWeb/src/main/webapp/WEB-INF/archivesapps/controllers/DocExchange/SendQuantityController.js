angular.module("ArchivesApp").controller('SendQuantityController', function($scope, $http) {
    console.log('SendQuantityController: ');
});