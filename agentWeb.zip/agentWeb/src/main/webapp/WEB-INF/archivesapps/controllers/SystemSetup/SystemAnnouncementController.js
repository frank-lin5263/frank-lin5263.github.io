angular.module("ArchivesApp").controller('SystemAnnouncementController', function($scope, $http) {
    console.log('SystemAnnouncementController: ');
});