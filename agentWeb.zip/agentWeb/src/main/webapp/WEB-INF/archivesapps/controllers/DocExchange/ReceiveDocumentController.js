angular.module("ArchivesApp").controller('ReceiveDocumentController', function($scope, $http, archivesConstant,
    archivesService, accountFactory, stateChangeFactory, receiveFilesService) {
    $scope.filterContent = {};
    $scope.archivesService = angular.copy(archivesService);
    $scope.archivesService.registerApp("ReceiveDocumentController");
    $scope.dynamicPopover = {
        title: '附件名稱'
    };

    $scope.queryFunc = function() {
        $http.get(stateChangeFactory.getStateURI() +"/list").then(function (response) {
            $scope.toggleResult = true;
            $scope.resultContent = response.data.resultData;
            $scope.archivesService.setSessionStorage(angular.toJson($scope.filterContent));
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    $scope.$on('$viewContentLoaded', function() {
        $scope.toggleAlert = false;
        var sessionFilterContent = $scope.archivesService.getSessionStorage();
        if (typeof sessionFilterContent === "undefined") {
            $scope.initFilter();
        } else {
            $scope.filterContent = angular.fromJson(sessionFilterContent);
            $scope.filterContent.dateFrom = $scope.convertToDate($scope.filterContent.dateFrom);
            $scope.filterContent.dateTo = $scope.convertToDate($scope.filterContent.dateTo);
            $scope.queryFunc();
        }
    });

    $scope.initFilter = function() {
        $scope.filterContent = {};
        $scope.filterContent.dateFrom = new Date();
        $scope.filterContent.dateTo = new Date();
        $scope.filterContent.hourFrom = "00";
        $scope.filterContent.hourTo = "23";

        $scope.toggleResult = true;
        $scope.toggleAlert = false;
        $scope.resultContent = [];
        $scope.archivesService.resetSorterAndPager();
    };

    $scope.convertToDate = function(value) {
        return typeof value === "undefined" || value === "" || value === 0 ? "" : new Date(value);
    };

    $scope.csvFile = function() {
        var url = stateChangeFactory.getStateURI() +"/report"
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            var length = response.headers('Content-Length');
            if (length > 0) {
                anchorClickDownload(response);
            }
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    function anchorClickDownload(response) {
        var csv = document.createElement('a');
        csv.href = URL.createObjectURL(new Blob([response.data], { type: 'application/octet-stream' }));
        csv.id = 'csvPath';
        csv.class = 'hidden';
        csv.download = 'receive.csv';
        document.body.appendChild(csv);
        csv.click();
        document.body.removeChild(csv);
    }

    $scope.downloadFile = function(documentId) {
        receiveFilesService.downloadFile(documentId);
    }

    $scope.receiveFunc = function() {
        $scope.toggleAlert = false;
        $scope.btTestDisabled = true;
        receiveFilesService.receiveFiles();
    };

    $scope.$on('toggleNoFiles', function(events) {
        $scope.toggleAlert = true;
        $scope.btTestDisabled = false;
        $scope.errorMessage = '尚無待收公文';
    });

    $scope.$on('errorResponse', function(events, response) {
        $scope.btTestDisabled = false;
        exceptionViewer(response, false);
    });

    $scope.$on('receiveResult', function(events, args) {
        $scope.btTestDisabled = false;
        $scope.queryFunc();
    });
});