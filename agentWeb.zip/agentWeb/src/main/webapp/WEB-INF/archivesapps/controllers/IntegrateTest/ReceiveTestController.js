angular.module("ArchivesApp").controller('ReceiveTestController', function($scope, $http, receiveFilesService,
    archivesService, accountFactory, archivesConstant) {
    $scope.archivesService = archivesService;
    $scope.archivesService.registerApp("ReceiveTestController");
    $scope.receiveConfirmList = [];

    $scope.$on('$viewContentLoaded', function() {
        $scope.toggleAlert = false;
        checkAutoReceive();
    });

    function checkAutoReceive() {
        if (localStorage.getItem("autoReceive") == 'true') {
            $('#autoReceive').prop('checked', true);
        } else {
            $('#autoReceive').prop('checked', false);
        }
    }

    $('#autoReceive').checkboxpicker().on('change', function() {
        localStorage.setItem("autoReceive", this.checked);
        receiveFilesService.autoReceiveScheduled(this.checked);
    });

    $scope.testFunc = function() {
        $scope.toggleAlert = false;
        $scope.btTestDisabled = true;
        receiveFilesService.receiveFiles();
    };

    $scope.$on('toggleNoFiles', function(events) {
        $scope.toggleAlert = true;
        $scope.btTestDisabled = false;
        $scope.errorMessage = '尚無待收公文';
    });

    $scope.$on('errorResponse', function(events, response) {
        $scope.btTestDisabled = false;
        exceptionViewer(response, false);
    });

    $scope.$on('receiveResult', function(events, args) {
        $scope.btTestDisabled = false;
        $scope.receiveConfirmList = args;
    });
});