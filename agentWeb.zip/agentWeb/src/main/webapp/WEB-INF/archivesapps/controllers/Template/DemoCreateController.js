angular.module("ArchivesApp").constant('demoCreateConstant', {
    APP_TITLE : "Demo Create",
    TEMPLATE_PATH: "/template",
    DEMO_PATH: "/demo"
}).controller('DemoCreateController', function($scope, $http, $uibModalInstance, archivesService, archivesConstant, demoCreateConstant) {

    $scope.createContent = {};
    $scope.demoCreateConstant = demoCreateConstant;

    $scope.createFunc = function() {
        $scope.errorMessage = validation();
        $scope.toggleAlert = $scope.errorMessage !== "";

        if (!$scope.toggleAlert) {
            var createUrl = buildCustomUrl(archivesConstant.REST_CREATE_PATH);
            $http.post(createUrl, angular.toJson($scope.createContent)).success(function(response) {
                actionResultViewer(archivesConstant.INSERT_SUCCESS_MSG);

                $uibModalInstance.close();
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }
    };

    $scope.cancel = function() {
        $uibModalInstance.dismiss("cancel");
    };

    function validation() {
        return archivesService.formatErrorMessage(
                           archivesService.validationNonEmpty("name", $scope.createContent.name, archivesConstant.VALID_STRING),
                           archivesService.validationNonEmpty("age", $scope.createContent.age, archivesConstant.VALID_NUMBER),
                           archivesService.validationNonEmpty("birthday", $scope.createContent.birthday, archivesConstant.VALID_EMPTY));
    }

    function buildCustomUrl(urlName) {
        return archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                demoCreateConstant.TEMPLATE_PATH, demoCreateConstant.DEMO_PATH, urlName);
    }

});