includeOtherController("Template", "DemoCreateController");
includeOtherController("Template", "DemoUpdateController");

angular.module("ArchivesApp").constant('demoReadConstant', {
    TEMPLATE_PATH: "/template",
    DEMO_PATH: "/demo"
}).controller('DemoReadController', function($scope, $http, $uibModal, archivesService, archivesConstant, demoReadConstant) {

    $scope.filterContent = {};

    $scope.archivesService = archivesService;
    $scope.archivesService.registerApp("DemoReadController");

    $scope.$on('$viewContentLoaded', function() {

        var sessionFilterContent = $scope.archivesService.getSessionStorage();

        if (typeof sessionFilterContent === "undefined") {
            $scope.initFilter();
        } else {
            console.log(sessionFilterContent);
            $scope.filterContent = angular.fromJson(sessionFilterContent);
            $scope.filterContent.dateFrom = convertToDateType($scope.filterContent.dateFrom);
            $scope.filterContent.dateTo = convertToDateType($scope.filterContent.dateTo);

            $scope.queryFunc();
        }
    });

    $scope.queryFunc = function() {
        var queryUrl = buildCustomUrl(archivesConstant.REST_READ_PATH);

        $http.get(queryUrl, { params: $scope.filterContent }).success(function(response) {
            setViewData(response);

            $scope.archivesService.setSessionStorage(angular.toJson($scope.filterContent));
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    };

    $scope.initFilter = function() {
        $scope.toggleResult = false;
        $scope.toggleAlert = false;

        $scope.filterContent.id = "";
        $scope.filterContent.name = "";
        $scope.filterContent.age = "";
        $scope.filterContent.dateFrom = "";
        $scope.filterContent.dateTo = "";
    };

    function convertToDateType(value) {
        return value ? new Date(value) : "";
    }

    function buildCustomUrl(urlName) {
        return archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                demoReadConstant.TEMPLATE_PATH, demoReadConstant.DEMO_PATH, urlName);
    }

    function setViewData(viewData) {
        var hasAnyViewData = $.trim(viewData) !== '';

        $scope.toggleResult = hasAnyViewData;
        $scope.resultContent = $scope.toggleResult ? viewData : "";

        $scope.toggleAlert = !hasAnyViewData;
        $scope.errorMessage = $scope.toggleAlert ? archivesConstant.SEARCH_WITHOUT_RESULT : "";
    }

    $scope.createDialogFunc = function() {
        $uibModal.open({
            templateUrl: archivesService.includeOtherHtml('Template', 'demoCreate'),
            controller: 'DemoCreateController'
        }).result.then(function() {
            $scope.initFilter();
            $scope.queryFunc();
        });
        //then(successCallback, errorCallback, notifyCallback)
        //.close -> successCallback
        //.dismiss -> errorCallback
    };

    $scope.updateDialogFunc = function(currentRowData) {
        $uibModal.open({
            templateUrl: archivesService.includeOtherHtml('Template', 'demoUpdate'),
            controller: 'DemoUpdateController',
            resolve: {
                rowData: function() {
                    return currentRowData;
                }
            }
        }).result.then(function(result) {
             $scope.initFilter();
             $scope.queryFunc();
        });
    };

});