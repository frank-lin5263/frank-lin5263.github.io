angular.module("ArchivesApp").controller('SendExceptionController', function($scope, $http) {
    console.log('SendExceptionController: ');
});