angular.module('ArchivesApp').controller('ModifyPersonDataController', function($rootScope, $scope, $http, readCerFactory,
archivesConstant, stateChangeFactory, archivesService) {

    $scope.$on('$viewContentLoaded', function() {
        var url = stateChangeFactory.getStateURI() + "/getUser";
        return $http.get(url).then(function(response) {
            $scope.user = response.data;
        });
    });

    $scope.save = function () {
        readCerFactory.getCertByUsage($scope.savePersonData, 'digitalSignature');
    }

    $scope.savePersonData = function() {
        var phoneFront = angular.element("#lblPhone").text() + '區碼';
        var phoneEnd = angular.element("#lblPhone").text() + '分機';
        var mobileFront = angular.element("#lblMobilePhone").text() + '前四碼';
        var mobileEnd = angular.element("#lblMobilePhone").text() + '後六碼';

        setError(false,'');
        var filterJson = {
            filterSymbol: {
                [angular.element("#lblOrgInfo").text()]: $scope.user.orgName
            },
            onlyNumber: {
                [phoneFront]: $scope.user.phoneAreaCode,
                [angular.element("#lblPhone").text()]: $scope.user.phoneLocalNumber,
                [phoneEnd]: $scope.user.phoneExtNumber,
                [mobileFront]: $scope.user.mobileAreaCode,
                [mobileEnd]: $scope.user.mobileLocalNumber
            },
            mail: {
                [angular.element("#lblEMail").text()]: $scope.user.email
            }
        }

        if (!archivesService.filterPattern(filterJson)) {
            setError(archivesService.filterJson.errorStatus, archivesService.filterJson.errorMessage);
            return;
        }
        var url = stateChangeFactory.getStateURI() + "/modifyUser";
        var personDataJson = {
            phoneAreaCode: $scope.user.phoneAreaCode,
            phoneLocalNumber: $scope.user.phoneLocalNumber,
            phoneExtNumber: $scope.user.phoneExtNumber,
            mobileAreaCode: $scope.user.mobileAreaCode,
            mobileLocalNumber: $scope.user.mobileLocalNumber,
            email: $scope.user.email,
            orgInfo: $scope.user.orgName
        };
        var userJson = angular.toJson(personDataJson);
        $http.put(url, userJson).then(function(response) {
            if (response.data.result === '') {
                $scope.error = false;
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
            } else {
                $scope.error = true;
                $scope.errorMessage = response.data.result;
            }
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    };

    function setError(showError, errorPrint) {
        $scope.error = showError;
        $scope.errorMessage = errorPrint;
    }
});