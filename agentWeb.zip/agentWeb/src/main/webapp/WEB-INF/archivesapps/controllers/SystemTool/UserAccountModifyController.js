angular.module('ArchivesApp').controller('UserAccountModifyController',
    function($scope, $http, $uibModalInstance, $timeout, $window, $uibModal,
        readCerFactory, user, roleList, archivesConstant, stateChangeFactory,
        archivesService, $q) {
        var defer = $q.defer();
        var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
            archivesConstant.SYSTEM_TOOL_PATH, '/userManagement');
        var constant = {
            HTML_TYPE: 'SystemTool',
            FINISH_HTML: 'updateCertFinish',
            UPDATE_CERT_HTML: 'updateCert'
        }

        $http.get(url + "/list", {
            params: ''
        }).then(function successCallback(response) {
              defer.resolve($scope.userList = response.data);
        })
        setTimeout(function() {
            switch ($scope.shadowUser.activeStatus) {
                case 1:
                    $scope.shadowUser.activeStatus = 1;
                    break;
                case 0:
                    $scope.shadowUser.activeStatus = 0;
                    break;
                default:
                    $scope.shadowUser.activeStatus = 0;
                    break;
            }
            $('.archives-checkbox').checkboxpicker().prop('checked', $scope.shadowUser.activeStatus);
            $('.selectpicker').selectpicker();
        }, 500);

        function setUibModal(func, htmlType, htmlName) {
            return $uibModal.open({
                templateUrl: archivesService.includeOtherHtml(htmlType, htmlName),
                controller: func,
                backdrop : 'static',
                keyboard : false
            });
        }

        $scope.updateCert = function() {
            var updateCertModal = function($scope, $uibModalInstance, Upload) {
                $scope.file = { name: '未選擇任何檔案' };
                $scope.btDisabled = true;
                $scope.uploadFiles = function(file, errFiles) {
                    if (file == null) {
                        $scope.toggleAlert = false;
                        $scope.btDisabled = true;
                    } else {
                        $scope.toggleAlert = false;
                        $scope.btDisabled = false;
                    }
                    $scope.file = file;
                    $scope.errFile = errFiles && errFiles[0];
                };

                $scope.submitEvent = function() {
                    if ($scope.file) {
                        $scope.file.upload = Upload.upload({
                            url: url + '/upload/cert',
                            data: {file: $scope.file, account: user.account}
                        });

                        $scope.file.upload.then(function (response) {
                            $uibModalInstance.close();
                            $scope.finishModal(response);
                        }, function (response) {
                            if (response.status > 0) {
                                $scope.errorMessage = response.data.errorMessage;
                                $scope.toggleAlert = true;
                                $scope.btDisabled = true;
                            }
                        });
                    }
                }

                $scope.submit = function() {
                    readCerFactory.getCertByUsage($scope.submitEvent, 'digitalSignature');
                };
                $scope.cancel = function() {
                    $uibModalInstance.close();
                };
                $scope.finishModal = function(response) {
                    var finishModalController = function($scope, $uibModalInstance) {
                        $scope.headerMsg = '憑證變更作業';
                        $scope.cardChangeMsg = '憑證更新作業完成';
                        if (response.data.resultData) {
                            $scope.cardChangeMsg += ',請重新登入';
                        }
                        $scope.okBtn = '確定';
                        $scope.submit = function() {
                            $uibModalInstance.close();
                            if (response.data.resultData) {
                                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/login?logout";
                            } else {
                                $window.location.reload();
                            }
                        };
                    };
                    setUibModal(finishModalController, constant.HTML_TYPE, constant.FINISH_HTML);
                };
            };
            setUibModal(updateCertModal, constant.HTML_TYPE, constant.UPDATE_CERT_HTML);
        };

        $scope.user = user;
        $scope.shadowUser = angular.copy(user);
        var userCopy = angular.copy(user);
        $scope.roleList = [];
        $scope.cardStatus = false;
        $scope.errorMessage = "";
        $scope.showErrorMessage = false;

        $scope.searchRoleName = function(keyword) {
            angular.forEach($scope.roleList, function(role) {
                if (role.roleName.match(keyword))
                    $scope.shadowUser.roleName = role.roleName;
            });
        };

        $scope.save = function() {
            setError(false, '');
            var filterJson = {
                filterSymbol: {
                    [angular.element("#lblOrgInfo").text()]: ($scope.shadowUser.orgInfo !== undefined) ?
                                                                $scope.shadowUser.orgInfo.trim() : ''
                }
            }
            console.log(filterJson);
            if (!archivesService.filterPattern(filterJson)) {
                $scope.showErrorMessage = true;
                $scope.errorMessage = '所屬單位請勿輸入特殊符號';
                return false;
            }

            readCerFactory.getCertByUsage($scope.saveUser, 'digitalSignature');
        };

        $scope.saveUser = function() {
            switch ($('.archives-checkbox').checkboxpicker().prop('checked')) {
                case true:
                    $scope.shadowUser.activeStatus = 1;
                    break;
                case false:
                    $scope.shadowUser.activeStatus = 0;
                    break;
                default:
                    $scope.shadowUser.activeStatus = -1;
                    break;
            }
            $scope.shadowUser.phoneNumber = $scope.shadowUser.phoneAreaCode + "-" + $scope.shadowUser.phoneLocalNumber +
                ($scope.shadowUser.phoneExtNumber ? ("#" + $scope.shadowUser.phoneExtNumber) : "");

            angular.copy($scope.shadowUser, $scope.user);
            var userJson = angular.toJson($scope.user);
            $http.put(url + "/saveUser", userJson).then(function successCallback(response) {
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);
                setTimeout(function() {
                    $uibModalInstance.close($scope.user);
                    $window.location.reload();
                }, 500);
                $scope.showErrorMessage = false;

            }, function errorCallback(response) {
                handleErrorMessage(response);
            });
        };

        function handleErrorMessage(response) {
            angular.copy(userCopy, $scope.user);
            if (response.data.errorCode == "SYS0000" || response.data.errorCode == "SYS0001") {
                exceptionViewer(response, true);
            } else {
                $scope.showErrorMessage = true;
                $scope.errorMessage = response.data.errorMessage;
                $timeout(function() {
                    $scope.showErrorMessage = false;
                }, 3000);
            }
        }

        $scope.cancel = function() {
            angular.copy(userCopy, $scope.shadowUser);
            angular.copy(userCopy, $scope.user);
            $scope.userDetailForm.$setPristine();
            $uibModalInstance.dismiss('cancel');
        };

        function setError(showError, errorPrint) {
            $scope.toggleResult = false;
            $scope.showErrorMessage = showError;
            $scope.errorMessage = errorPrint;
        }

        $uibModalInstance.opened.then(function() {
            $scope.roleList = roleList;
        });
        $http.get(url + "/list", {
            params: ''
        }).then(function successCallback(response) {
            $scope.userList = response.data;
        })
    });