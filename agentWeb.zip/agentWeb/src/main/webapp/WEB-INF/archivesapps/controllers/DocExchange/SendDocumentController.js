angular.module("ArchivesApp").controller('SendDocumentController', function($scope, $http, Upload,
    stateChangeFactory, uploadFilesService, archivesService, archivesConstant) {
    var uploadUrl = stateChangeFactory.getStateURI() + archivesConstant.REST_UPLOAD_PATH;
    $scope.filterContent = {};
    $scope.archivesService = angular.copy(archivesService);
    $scope.archivesService.registerApp("SendDocumentController");
    $scope.UploadDisabled = false;
    $scope.file = { select: '未選擇任何檔案' };

    $scope.queryFunc = function() {
        var url = stateChangeFactory.getStateURI() +"/list"
        $http.get(url).then(function (response) {
            $scope.toggleResult = true;
            $scope.resultContent = response.data.resultData;
            $scope.archivesService.setSessionStorage(angular.toJson($scope.filterContent));
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    $scope.$on('$viewContentLoaded', function() {
        $scope.toggleAlert = false;
        var sessionFilterContent = $scope.archivesService.getSessionStorage();
        if (typeof sessionFilterContent === "undefined") {
            $scope.initFilter();
        } else {
            $scope.filterContent = angular.fromJson(sessionFilterContent);
            $scope.filterContent.dateFrom = $scope.convertToDate($scope.filterContent.dateFrom);
            $scope.filterContent.dateTo = $scope.convertToDate($scope.filterContent.dateTo);
            $scope.queryFunc();
        }
    });

    $scope.convertToDate = function(value) {
        return typeof value === "undefined" || value === "" || value === 0 ? "" : new Date(value);
    };

    $scope.initFilter = function() {
        $scope.filterContent = {};
        $scope.filterContent.dateFrom = new Date();
        $scope.filterContent.dateTo = new Date();
        $scope.filterContent.hourFrom = "00";
        $scope.filterContent.hourTo = "23";

        $scope.toggleResult = true;
        $scope.toggleAlert = false;
        $scope.resultContent = [];
        $scope.archivesService.resetSorterAndPager();
    };

    $scope.csvFile = function() {
        var url = stateChangeFactory.getStateURI() +"/report"
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            var length = response.headers('Content-Length');
            if (length > 0) {
                anchorClickDownload(response);
            }
        }), function errorCallback(response) {
            exceptionViewer(response, false);
        }
    }

    function anchorClickDownload(response) {
        var csv = document.createElement('a');
        csv.href = URL.createObjectURL(new Blob([response.data], { type: 'application/octet-stream' }));
        csv.id = 'csvPath';
        csv.class = 'hidden';
        csv.download = 'send.csv';
        document.body.appendChild(csv);
        csv.click();
        document.body.removeChild(csv);
    }

    function isZipFile(fileName) {
        return fileName.endsWith('.zip');
    }

    $scope.uploadZipFile = function(files) {
        if (files.length > 0) {
            if (files.length > 1) {
                $scope.file.select = '不支援多Zip';
            } else {
                if (isZipFile(files[0].name)) {
                    $scope.toggleAlert = false;
                    $scope.file.select = '選擇' + files[0].name;
                    $scope.files = files;
                    uploadFilesService.uploadZipFile(files);
                } else {
                    $scope.file.select = '不是ZipFile';
                }
            }
        }
    }

    $scope.uploadFiles = function(files) {
        $scope.toggleAlert = false;
        if (files.length > 0) {
            $scope.UploadDisabled = true;
            $scope.files = files;
            $scope.file.select = '選擇' + files.length + '檔案';
            uploadFilesService.uploadFileArray(files);
        }
    }

    $scope.$on('sendFinished', function(events, args) {
        $scope.UploadDisabled = false;
        $scope.queryFunc();
    });

    $scope.$on('toggleAlert', function(events, args) {
        $scope.UploadDisabled = false;
        $scope.errorMessage = args.errorMessage;
        $scope.toggleAlert = true;
    });
});