angular.module("ArchivesApp").constant('demoUpdateConstant', {
    APP_TITLE : "Demo Update",
    TEMPLATE_PATH: "/template",
    DEMO_PATH: "/demo"
}).controller('DemoUpdateController', function($scope, $http, $uibModalInstance, archivesService, archivesConstant, demoUpdateConstant, rowData) {

    $scope.updateContent = rowData;
    $scope.demoUpdateConstant = demoUpdateConstant;

    $scope.updateFunc = function() {
        $scope.errorMessage = validation();
        $scope.toggleAlert = $scope.errorMessage !== "";

        if (!$scope.toggleAlert) {
            var updateUrl = buildCustomUrl(archivesConstant.REST_UPDATE_PATH);
            $http.put(updateUrl, angular.toJson($scope.updateContent)).success(function(response) {
                actionResultViewer(archivesConstant.UPDATE_SUCCESS_MSG);

                $uibModalInstance.close();
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }
    };

    $scope.cancel = function() {
        $uibModalInstance.dismiss("cancel");
    };

    function validation() {
        return archivesService.formatErrorMessage(
                           archivesService.validationNonEmpty("name", $scope.updateContent.name, archivesConstant.VALID_STRING),
                           archivesService.validationNonEmpty("age", $scope.updateContent.age, archivesConstant.VALID_NUMBER),
                           archivesService.validationNonEmpty("birthday", $scope.updateContent.birthday, archivesConstant.VALID_EMPTY));
    }

    function buildCustomUrl(urlName) {
        return archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                demoUpdateConstant.TEMPLATE_PATH, demoUpdateConstant.DEMO_PATH, urlName);
    }
});