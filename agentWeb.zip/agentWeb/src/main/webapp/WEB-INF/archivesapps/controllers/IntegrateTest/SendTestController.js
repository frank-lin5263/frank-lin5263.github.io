angular.module("ArchivesApp").controller('SendTestController', function($scope, $http, accountFactory, archivesService, archivesConstant, uploadFilesService) {
    $scope.archivesService = archivesService;
    $scope.archivesService.registerApp("SendTestController");
    $scope.sendOutList = [];
    $scope.processIds = [];
    $scope.file = { select: '未選擇任何檔案' };
    $scope.maxRepeat = 1;

    function checkAutoSend() {
        if (localStorage.getItem("autoSend") == 'true') {
            $('#autoSend').prop('checked', true);
        } else {
            $('#autoSend').prop('checked', false);
        }
    }

    $scope.$on('$viewContentLoaded', function() {
        $scope.toggleAlert = false;
        checkAutoSend();
    });

    $('#autoSend').checkboxpicker().on('change', function() {
        localStorage.setItem("autoSend", this.checked);
        uploadFilesService.autoSendScheduled(this.checked);
    });

    $scope.queryFunc = function() {
        var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
            archivesConstant.DOC_EXCHANGE_PATH, archivesConstant.SEND_DOC_PATH) + '/Query';
        var params = accountFactory.getDocumentParams();
        $http.post(url, params).success(function(response) {
            var sendResults = response.resultData.sendResults;
        }).error(function(response) {
            exceptionViewer(response, false);
        });
    }

    $scope.uploadFiles = function(files) {
        $scope.toggleAlert = false;
        $scope.files = files;
        $scope.file.select = '選擇' + files.length + '檔案';
        if (files && files.length) {
            uploadFilesService.uploadFiles(files);
        }
    }

    $scope.massAutoSendFile = function() {
        $scope.toggleAlert = false;
        $scope.sendBtDisabled = true;
        uploadFilesService.massAutoSendFiles($scope.maxRepeat);
    }

    $scope.$on('maxRepeat', function(events, args) {
        $scope.maxRepeat = args;
    });

    $scope.$on('sendFinished', function(events, args) {
        $scope.sendBtDisabled = false;
    });

    $scope.$on('toggleAlert', function(events, args) {
        $scope.sendBtDisabled = false;
        $scope.errorMessage = args.errorMessage;
        $scope.toggleAlert = true;
    });
});