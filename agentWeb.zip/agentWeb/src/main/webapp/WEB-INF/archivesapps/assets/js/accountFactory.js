ArchivesApp.factory('accountFactory', function($http, $window, httpAuth, archivesConstant) {
    var self = this;
	self.accountDetail;
	self.isWorking = false;

	var documentParams = {
		orgUnitId : "",
	    decryptedToken : "",
	    signedToken : "",
        documentId : "",
        confirmResult : {},
        signedFiles : [],
        processIds : [],
        encryptedPsw : "",
        confirmSignature : "",
        rejectMsg : "",
        fileHash : ""
	}

    function isWindowsOS() {
        return ($window.navigator.userAgent.indexOf("Windows NT") != -1);
    }

    function execWindowStop() {
        if (isWindowsOS()) {
            $window.document.execCommand('Stop');
        } else {
            $window.stop();
        }
    }

    function formatParams(params) {
        return "?" + Object
            .keys(params)
            .map(function(key) {
                return key + "=" + params[key]
            })
            .join("&")
    }

	return {
        getAccountDetail: function() {
    	    return self.accountDetail;
        },
        setAccountDetail: function(detail) {
            self.accountDetail = detail;
            documentParams.orgUnitId = detail.orgUnitId;
            console.log('setAccountDetail: ' + documentParams.orgUnitId);
        },
        getDocumentParams: function() {
    	    return documentParams;
        },
        setDocumentParams: function(params) {
            documentParams = params;
        },
        getOrgUnitId: function() {
    	    return documentParams.orgUnitId;
        },
        setOrgUnitId: function(orgUnitId) {
            documentParams.orgUnitId = orgUnitId;
        },
        getDecryptedToken: function() {
    	    return documentParams.decryptedToken;
        },
        setDecryptedToken: function(decryptedToken) {
            documentParams.decryptedToken = decryptedToken;
        },
        getSignedToken: function() {
    	    return documentParams.signedToken;
        },
        setSignedToken: function(signedToken) {
            documentParams.signedToken = signedToken;
            httpAuth.setCookies('signedToken', signedToken);
        },
        getDocumentId: function() {
    	    return documentParams.documentId;
        },
        setDocumentId: function(documentId) {
            documentParams.documentId = documentId;
        },
        getConfirmResult: function() {
    	    return documentParams.confirmResult;
        },
        setConfirmResult: function(result) {
            documentParams.confirmResult = result;
            httpAuth.setCookies('sessionId', result.sessionId);
        },
        getSignedFiles: function() {
    	    return documentParams.signedFiles;
        },
        setSignedFiles: function(signedFiles) {
            documentParams.signedFiles = signedFiles;
        },
        setProcessIds: function(processId) {
            documentParams.processIds.push(processId);
        },
        getEncryptedPsw: function() {
    	    return documentParams.encryptedPsw;
        },
        setEncryptedPsw: function(encryptedPsw) {
            documentParams.encryptedPsw = encryptedPsw;
        },
        getConfirmSignature: function() {
    	    return documentParams.confirmSignature;
        },
        setConfirmSignature: function(confirmSignature) {
            documentParams.confirmSignature = confirmSignature;
        },
        setRejectMsg: function(rejectMsg) {
            documentParams.rejectMsg = rejectMsg;
        },
        isWorking: function() {
    	    return self.isWorking;
        },
        setWorking: function(isWorking) {
            self.isWorking = isWorking;
        },
        getFormatParams: function(params) {
            return formatParams(params);
        },
        isSmartCard: function() {
            var pkiUsage = localStorage.getItem("PKIUsage");
            if (pkiUsage == null) {
                localStorage.setItem("PKIUsage", false);
            }
            return (pkiUsage == 'true');
        },
        sessionLogout: function(message) {
            var account = httpAuth.getCookies('account');
            var remoteIP = httpAuth.getCookies('remoteIP');
            var signedToken = httpAuth.getCookies('signedToken');
            var sessionId = httpAuth.getCookies('sessionId');
            var logoutParams = {
                "account": account,
                "remoteAddress": remoteIP,
                "sessionId": sessionId,
                "signedToken": signedToken
            }
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SESSION_PATH + '/logout';
            $http.post(url, logoutParams)
            .success(function(response) {
                sessionStorage.setItem('authenticatedCSM', false);
                httpAuth.setCookies('account', undefined);
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/index?error=" + message;
            }).error(function(response) {
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/index?error=" + response.resultData;
            });
        },
        checkSessionId: function(event) {
            $http.post(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SESSION_PATH + '/checkSessionId', self.accountDetail)
            .error(function(response) {
                event.preventDefault();
                execWindowStop();
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/index?error=conflict";
            });
        },
        sessionExpired: function() {
            execWindowStop();
            $http.post(archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.SESSION_PATH + '/expired', self.accountDetail)
            .success(function(response) {
                $window.location.href = archivesConstant.WEB_ROOT_PATH + "/index?error=expired";
            }).error(function(response) {
                exceptionViewer(response, false);
            });
        }
    };
});