ArchivesApp.factory('signatureFactory', function($rootScope, $http, httpAuth, accountFactory, readCerFactory,
    pkiErrorReasonFactory, decryptedFactory, archivesConstant) {
    var postTarget;
    var timeoutId;
    var isCancel = false;
    function postData(target,data) {
	    if(!http.sendRequest) {
		    return null;
	    }
	    http.url=target;
	    http.actionMethod="POST";
	    var code=http.sendRequest(data);
	    if(code!=0) return null;
	    return http.responseText;
    }

    function checkFinish() {
	    if(postTarget){
		    postTarget.close();
	    	var response = {
	    	    errorMessage: '簽章連線逾時'
	    	};
	    	exceptionViewer(response, false);
	    }
    }

    var signPackage = {
        event : "",
        fileHash : "",
        fileName : "",
        signType : "",
        getTbsPackage : function () {
	        var tbsData = {};
	        var encode = "base64";
	        if (this.signType == 'PKCS1') {
	            encode = "NONE";
	            tbsData["hashAlgorithm"] = "SHA256";
	        }
	        tbsData["tbs"] = this.fileHash;
	        tbsData["tbsEncoding"] = encode;
	        tbsData["pin"] = httpAuth.getCookies('pinCode');
	        tbsData["func"] = "MakeSignature";
	        tbsData["signatureType"] = this.signType;
	        tbsData["slotDescription"] = httpAuth.getCookies('slotDesc');
	        return JSON.stringify(tbsData ).replace(/\+/g,"%2B");
        }
    }

    var makeHWSignature = {
	    makeSignature: function(signingFile, event) {
            var ua = window.navigator.userAgent;
            signPackage.signType = 'RAW';
            if (event == 'login') {
                signPackage.signType = 'PKCS1';
            }
            signPackage.event = event;
            signPackage.fileHash = signingFile.fileHash;
            signPackage.fileName = signingFile.fileName;
            //is IE, use ActiveX
	        if(ua.indexOf("MSIE")!=-1 || ua.indexOf("Trident")!=-1) {
		        postTarget = window.open("http://localhost:61161/waiting.gif", "Signing","height=200, width=200, left=100, top=20");
		        var tbsPackage = signPackage.getTbsPackage();
		        document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
		        var data=postData("http://localhost:61161/sign","tbsPackage="+tbsPackage);
		        postTarget.close();
		        postTarget = null;
		        if(!data) {
	    	        var response = {
	    	            errorMessage: '尚未安裝元件'
	    	        };
	    	        exceptionViewer(response, false);
		        } else {
		            setSignature(data, signPackage.event, signPackage.fileName);
		        }
	        } else {
		        postTarget = window.open("http://localhost:61161/popupForm", "簽章中","height=200, width=200, left=100, top=20");
		        timeoutId = setTimeout(checkFinish, 10000);
	        }
        }
    }

    function confirmCommand(params) {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/initExchange/confirm';
        var confirmParams = {
            signInMeta : accountFactory.getAccountDetail().signInMeta,
            hashPackage : params
        }
        $http.post(url, confirmParams).then(function(response) {
            var confirmResult = response.data.resultData;
            accountFactory.setConfirmResult(confirmResult);
            decryptedFactory.getDecryptedData(confirmResult.encryptedToken, null, 'decryptToken');
        }, function errorCallback(response) {
            accountFactory.sessionLogout(response.data.errorMessage);
        });
    }

    function broadcastRejectMsg(rejectMsg) {
        $rootScope.$broadcast('rejectRequest', rejectMsg);
    }

    function getSignPackage() {
        return {
            signature: httpAuth.getCookies('signature'),
            sigCert: httpAuth.getCookies('sigCert'),
            encCert: httpAuth.getCookies('encCert')
        }
    }

    function saveEncCert(encCert) {
        httpAuth.setCookies('encCert', encCert),
        confirmCommand(getSignPackage());
    }

    function setSignature(signature, event, fileName) {
        var ret = JSON.parse(signature);
	    if(ret.ret_code == 0) {
	        if (event == 'signFinish') {
                accountFactory.setSignedToken(ret.signature);
                $rootScope.$broadcast(event);
	        } else if (event == 'login') {
                angular.element('#signature').val(ret.signature);
                angular.element('#certificate').val(ret.certb64);
                angular.element('#encCert').val('');
                document.getElementById('loginForm').submit();
	            angular.element($('.modal')[0]).scope().modalOptions.close();
	        } else if (event == 'confirm') {
                httpAuth.setCookies('signature', ret.signature);
                httpAuth.setCookies('sigCert', ret.certb64);
	            readCerFactory.getCertByUsage(saveEncCert, "keyEncipherment|dataEncipherment");
	        } else {
                var signPackage =  {
                    signature: ret.signature,
                    sigCert: ret.certb64,
                    encCert: httpAuth.getCookies('encCert')
                }
                $rootScope.$broadcast(event, signPackage, fileName);
	        }
	    } else {
	        var message = pkiErrorReasonFactory.majorErrorReason(ret.ret_code);
            if(ret.last_error) {
    		    message += " - ";
    		    message += pkiErrorReasonFactory.minorErrorReason(ret.last_error);
            }
	    	var response = {
	    	    errorMessage: message
	    	};
	    	exceptionViewer(response, false);
	    }
    }

    function receiveMessage(event) {
	    //if(console) console.debug(event);

	    //安全起見，這邊應填入網站位址檢查
	    if(event.origin!="http://localhost:61161")
		    return;
	    try{
		    var ret = JSON.parse(event.data);
		    if(ret.func) {
			    if(ret.func=="getTbs") {
			        if (postTarget != null) {
				        clearTimeout(timeoutId);
				        var json = signPackage.getTbsPackage();
				        postTarget.postMessage(json,"*");
			        }
			    } else if(ret.func=="sign") {
				    setSignature(event.data, signPackage.event, signPackage.fileName);
			    }
		    } else {
		        broadcastRejectMsg('收文取消,簽章異常');
			    if(console) console.error("no func");
		    }
	    } catch(e) {
		    //error handle
		    broadcastRejectMsg('收文取消,簽章異常');
		    if(console) console.error(e);
	    }
    }

    if (window.addEventListener) {
	    window.addEventListener("message", receiveMessage, false);
    } else {
	    //for IE8
	    window.attachEvent("onmessage", receiveMessage);
    }

    function digitalSign(signingFile) {
        var endpoint = 'https://localhost:61162/v1/digitalSign';
        var params = {
            account: httpAuth.getCookies('account'),
            password: httpAuth.getCookies('pinCode'),
            hash: signingFile.fileHash
        };
        var url = endpoint + accountFactory.getFormatParams(params);
        $http.get(url).success(function (response) {
            if (response.resultCode == 0) {
	            var resultData = response.resultData;
                angular.element('#signature').val(resultData.base64Sign);
                angular.element('#certificate').val(resultData.base64Cert);
                angular.element('#encCert').val('');
                document.getElementById('loginForm').submit();
	            angular.element($('.modal')[0]).scope().modalOptions.close();
	        }
        }).error(function (response) {
            var exceptionResponse = {
                errorMessage : response.resultMessage
            }
            exceptionViewer(exceptionResponse, false);
        });
    }

    function digitalSignHash(signingFile, event) {
        var endpoint = 'https://localhost:61162/v1/signHash';
        var params = {
            account: httpAuth.getCookies('account'),
            password: httpAuth.getCookies('pinCode'),
            hash: signingFile.fileHash
        };
        $http.post(endpoint, params).success(function (response) {
            if (response.resultCode == 0) {
	            var resultData = response.resultData;
	            if (event == 'signFinish') {
                    accountFactory.setSignedToken(resultData.signature);
                    $rootScope.$broadcast(event);
	            } else if (event == 'confirm') {
	                httpAuth.setCookies('signature', resultData.signature);
                    httpAuth.setCookies('sigCert', resultData.sigCert);
	                readCerFactory.getCertByUsage(saveEncCert, "dataEncipherment");
	            } else {
                    $rootScope.$broadcast(event, resultData, signingFile.fileName);
	            }
	        }
        }).error(function (response) {
            exceptionViewer(response, false);
        });
    }

    return {
        getSignHashByEvent: function(signingFile, event) {
            var isCard = accountFactory.isSmartCard();
            if (isCard) {
                makeHWSignature.makeSignature(signingFile, event);
            } else {
                if (event === 'login') {
                    digitalSign(signingFile);
                } else {
                    digitalSignHash(signingFile, event);
                }
            }
        }
    };
});