var ArchivesApp = angular.module("ArchivesApp", [
    "ui.router",
    "ui.bootstrap",
    "ngFileUpload",
    "oc.lazyLoad",
    "ngCookies",
    "ngSanitize",
    "ngFileUpload",
    "angular-loading-bar"
]);

ArchivesApp.config(['$ocLazyLoadProvider', function($ocLazyLoadProvider) {
    $ocLazyLoadProvider.config({});
}]);


ArchivesApp.config(['$controllerProvider', function($controllerProvider) {
    $controllerProvider.allowGlobals();
}]);

ArchivesApp.config(['cfpLoadingBarProvider', function(cfpLoadingBarProvider) {
    cfpLoadingBarProvider.parentSelector = '#loading-bar-container';
}]);

ArchivesApp.config(function($httpProvider) {
    var auth = document.getElementById("auth").value;
    $httpProvider.interceptors.push(function($q) {
        return {
            request: function(request) {
                request.headers.authorization = auth;
                return request;
            },
            response: function(response) {
                response.data.status = response.status;
                return response;
            },
            responseError: function(rejection) {
                return $q.reject(rejection);
            }
        }
    });
});

ArchivesApp.factory('settings', ['$rootScope', function($rootScope) {
    var settings = {
        layout: {
            pageSidebarClosed: false,
            pageContentWhite: true,
            pageBodySolid: false,
            pageAutoScrollOnLoad: 1000
        },
        appPath: 'archivesapps',
        assetsPath: 'resources/assets',
        globalPath: 'resources/assets/global',
        layoutPath: 'resources/assets/layouts/layout',
        PDF_DOWNLOAD_BUTTON_TEXT: 'PDF下載',
        CSV_BUTTON_TEXT: 'CSV下載',
        PRINT_BUTTON_TEXT: '列印',
        RESEND_BUTTON_TEXT: '重送',
        PREVIEW_BUTTON_TEXT: '檢視公文',
        SEARCH_BUTTON_TEXT: '查詢',
        RESET_BUTTON_TEXT: '重填',
        ADD_BUTTON_TEXT: '新增',
        UPDATE_BUTTON_TEXT: '修改',
        DELETE_BUTTON_TEXT: '刪除',
        BACK_BUTTON_TEXT: '返回',
        RECEIVE_BUTTON_TEXT: '收文',
        FILE_BUTTON_TEXT: '選擇檔案',
        UPLOAD_BUTTON_TEXT: '上傳公文檔案',
        VIEW_TEST_ORG: '顯示測試機關',
        TRANSFER_BUTTON_TEXT: '移轉',
        FULL_COMPARISON_TEXT: '完全比對',
        TIME_FROM: '小時（起）：00：00',
        TIME_TO: '小時（迄）：59：59'
    };

    $rootScope.settings = settings;

    return settings;
}]);

ArchivesApp.controller('AppController', ['$scope', '$rootScope', function($scope) {
    $scope.$on('$viewContentLoaded', function() {

    });
}]);

ArchivesApp.controller('HeaderController', function($scope, $http, $window, modalService, httpAuth,
    accountFactory, signatureFactory, archivesConstant) {

    $scope.$on('$includeContentLoaded', function () {
        $scope.errorMessage = angular.element('#errorMessage').val();
        console.log('errorMessage: ' + $scope.errorMessage);
        if ($scope.errorMessage.length > 0) {
            httpAuth.setCookies('account', undefined);
            $scope.account = 'Login';
            httpAuth.setSession('authenticatedCSM', false);
        }
        var account = httpAuth.getCookies('account');
        console.log('account: ' + account);
        if (typeof account !== 'undefined') {
            $scope.account = account;
        } else {
            $scope.account = 'Login';
        }
    });

    $scope.menuModal = function () {
        var feature = 'login';
        modalService.showModal({templateUrl:'archivesapps/templates/partials/'+feature+'Modal.jsp'}, {});
    }

    $scope.userAuthenticated = function () {
        return httpAuth.isUserAuthenticated();
    }

    $scope.logoutFunc = function() {
        accountFactory.sessionLogout('登出成功!!!!');
    }

    function signInCommand(signInMeta) {
        var url = archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
                '/initExchange' +
                '/signIn';
        $http.post(url, signInMeta).then(function(response) {
            var signingFile = { fileName: null, fileHash: response.data.resultData };
            signatureFactory.getSignHashByEvent(signingFile, 'confirm');
        }, function errorCallback(response) {
            accountFactory.sessionLogout(response.data.errorMessage);
        });
    }
});

ArchivesApp.controller('SidebarController', function($scope, $http, $rootScope, archivesConstant) {
    $scope.$on('$includeContentLoaded', function() {
        if (location.href.indexOf('home') === -1) {
	        var webSide = location.href.indexOf('#') === -1 ? location.pathname : location.hash;
            setTimeout(function() {
                $('#menu-head-' + getCurrentTopMenu(webSide)).trigger('click');
            }, 1200);
        }
    });

    var getCurrentTopMenu = function(topMenuName) {
        var menuArray = topMenuName.match(/\/[a-zA-Z0-9]*\//);
        if (menuArray != null) {
            return menuArray[0].slice(1, -1);
        }
    };

    $scope.toLowUrl = function(topMenu, submenu) {
        return '/' + $scope.toLowerCamelCase(topMenu) + '/' + $scope.toLowerCamelCase(submenu);
    }
    $scope.toLowerCamelCase = function(menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }
});

ArchivesApp.controller('PageHeadController', function($scope, $rootScope, $http, accountFactory, slotStatusFactory,
    archivesConstant, $location, archivesService) {
    $scope.$on('$includeContentLoaded', function() {
    });
});

ArchivesApp.controller('FooterController', function($scope, $http, archivesConstant, accountFactory, signatureFactory) {
    $scope.$on('$includeContentLoaded', function() {
    });
    $scope.$on('decryptToken', function(events, args) {
        var url = archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH +
                '/initExchange/uuidHash';
        $http.post(url, args).then(function(response) {
            var signingFile = { fileName: null, fileHash: response.data.resultData };
            signatureFactory.getSignHashByEvent(signingFile, 'signFinish');
        }, function errorCallback(response) {
            accountFactory.sessionLogout(response.data.errorMessage);
        });
    });
});

var $stateProviderRef = null;
angular.module('ArchivesApp').config(function($stateProvider) {
    $stateProviderRef = $stateProvider;
}).run(function($rootScope, settings, $state, $http, Upload, uploadFilesService, receiveFilesService, archivesConstant,
    archivesService, httpAuth, accountFactory, signatureFactory, stateChangeFactory) {
    $rootScope.$state = $state;
    $rootScope.$settings = settings;
    var sessionTimeOut = 72000000;;
    var lastDigestRun = Date.now();

    setTimeout(function() {
        var isAuth = httpAuth.isUserAuthenticated();
        console.log("isAuth: " + isAuth);
        var account = httpAuth.getCookies('account');
        console.log('account: ' + account);
        if (isAuth && typeof account !== 'undefined') {
            getCoreMenu();
        } else {
            setRouterState('home_not_auth', '/home/not_auth', archivesConstant.APP_PATH + '/views/home.html', 'HomeController', '',
                archivesConstant.APP_PATH + '/controllers/HomeController.js');
            $state.go('home_not_auth');
	        if (!isAuth && account != null) {
	            getSessionDetail();
            }
        }
    }, 500);


    function signInCommand(signInMeta) {
        var url = archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
                '/initExchange' +
                '/signIn';
        $http.post(url, signInMeta).then(function(response) {
            var signingFile = { fileName: null, fileHash: response.data.resultData };
            signatureFactory.getSignHashByEvent(signingFile, 'confirm');
        }, function errorCallback(response) {
            accountFactory.sessionLogout(response.data.errorMessage);
        });
    }

    function getSessionDetail() {
        var url = archivesConstant.WEB_ROOT_PATH +
            archivesConstant.REST_API_VERSION_PATH +
            archivesConstant.SESSION_PATH +
            '/detail';
        $http.get(url).then(function(response) {
            sessionTimeOut = response.data.timeOut * 1000;
            accountFactory.setAccountDetail(response.data);
            httpAuth.setCookies('remoteIP', response.data.remoteAddress);
            signInCommand(response.data.signInMeta);
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    }

    function isSessionExpire(now) {
        return (now - lastDigestRun > sessionTimeOut);
    }

    $rootScope.$on('$stateChangeStart', function(event, toState) {
        stateChangeFactory.setStateURI(toState.url);
        var isAuth = httpAuth.isUserAuthenticated();
        if (isAuth) {
            var now = Date.now();
            if (isSessionExpire(now)) {
                event.preventDefault();
                accountFactory.sessionExpired();
            } else {
                lastDigestRun = now;
                //accountFactory.checkSessionId(event);
            }
        }
    });

    $rootScope.$on('signFinish', function(event) {
        httpAuth.setSession('authenticatedCSM', true);
        getCoreMenu();
    });

    function getCoreMenu() {
        var menuUrl = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH, '/core', '/menu');
        $http.get(menuUrl).success(function (response) {
            $rootScope.menus = response.resultData.menu;
            angular.forEach(response.resultData.menu, function(topMenuValue) {
                angular.forEach(topMenuValue.subMenus, function(subMenuValue) {
                    if (subMenuValue.menuName !== 'undefined') {
                        setRouterStateByMenu(topMenuValue, subMenuValue);
                    }
                });
            });
        }).error(function (response) {
            $state.go('home_not_auth');
        });
        setRouterState('home', '/home/auth_home', archivesConstant.APP_PATH + '/views/home.html', 'HomeController', '', archivesConstant.APP_PATH + '/controllers/HomeController.js');
        $state.go('home');
    }

    function setRouterState(stateName, restUrl, htmlFilePath, controllerName, pageTitleName, controllerFilePath) {
        $stateProviderRef.state(stateName, {
            url: restUrl,
            views: {
                "content": {
                    templateUrl: htmlFilePath,
                    controller: controllerName
                }
            },
            data: {
                pageTitle: pageTitleName
            },
            resolve: {
                deps: ['$ocLazyLoad', '$rootScope', function($ocLazyLoad, $rootScope) {
                    return $ocLazyLoad.load({
                        name: 'ArchivesApp',
                        insertBefore: '#ng_load_plugins_before',
                        files: [controllerFilePath]
                    });
                }]
            }
        });
    }

    function setRouterStateByMenu(jsonMenuParent, jsonMenuChild) {
        var toLowerCamelCase = function(menuCode) {
            return menuCode.slice(0, 1).toLowerCase() + menuCode.slice(1);
        };

        var stateName = jsonMenuChild.menuCode;
        var restUrl = '/' + toLowerCamelCase(jsonMenuParent.menuCode) + '/' + toLowerCamelCase(jsonMenuChild.menuCode);
        var htmlFilePath = archivesConstant.APP_PATH + '/views/' + jsonMenuParent.menuCode + '/' +
                    toLowerCamelCase(jsonMenuChild.menuCode) + '.html';
        var controllerName = jsonMenuChild.menuCode + 'Controller';
        var pageTitleName = jsonMenuChild.menuName;
        var controllerFilePath = archivesConstant.APP_PATH + '/controllers/' + jsonMenuParent.menuCode + '/' + jsonMenuChild.menuCode + 'Controller.js';

        setRouterState(stateName, restUrl, htmlFilePath, controllerName, pageTitleName, controllerFilePath);
    }
});