ArchivesApp.controller('LoginController', function ($rootScope, $scope, $http, accountManagementFactory, httpAuth,
    slotStatusFactory, accountFactory, signatureFactory, archivesConstant) {

    $scope.slotData = {};

    function slotStateProbe(status) {
        $scope.slotData = slotStatusFactory.defaultSlotData(status);
        $scope.slotData.selected = $scope.slotData.available[0];
    }

    $scope.$on('slotStateProbe', function(events, slotData) {
        $scope.slotData.selected = slotData.available[0];
        $scope.checkSlot();
        $scope.$apply();
    });

    $scope.$on('slotStateChange', function(events, serial) {
        console.log('slotStateChange: ' + serial);
        var status = '連線異常';
        if (serial !== null) {
            status = '連線成功';
        }
        slotStateProbe(status);
        $scope.slotData.selected.serial = serial;
    });

    var isCard = accountFactory.isSmartCard();
    angular.element('#PKIUsage').attr('checked', isCard);
    slotStateProbe('偵測中');
    slotStatusFactory.querySlotStatus($scope.slotData);

    function getAuthToken() {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/auth/signToken'
        httpAuth.get(url).success(function(data, status, headers, config) {
            $scope.SignPackageData = data;
        });
    }

    $('.archives-checkbox').checkboxpicker().on('change', function() {
        localStorage.setItem("PKIUsage", this.checked);
        slotStateProbe('偵測中');
        slotStatusFactory.querySlotStatus($scope.slotData);
    });

    $scope.checkSlot = function() {
        if ($scope.slotData.selected.serial) {
            $scope.loginForm.slotDesc.$setValidity("slotDesc", true);
        } else {
            $scope.loginForm.slotDesc.$setValidity("slotDesc", false);
        }
    }

    $scope.loginBt = function (form) {
        httpAuth.setCookies('account', $scope.form.account);
        httpAuth.setCookies('pinCode', $scope.form.pinCode);

        var statusEnd = $scope.slotData.selected.cardStatus.indexOf(' 卡號:');
        var slotDesc = $scope.slotData.selected.cardStatus.slice(0, statusEnd);
        httpAuth.setCookies('slotDesc', slotDesc);
        httpAuth.setCookies('cardNo', $scope.slotData.selected.serial);
        angular.element('#cardNo').val($scope.slotData.selected.serial);
        var content = angular.element('#content').val();
        var signingFile = {
            fileHash: content,
            fileName: ''
        }
        signatureFactory.getSignHashByEvent(signingFile, 'login');
    }

    getAuthToken();
});