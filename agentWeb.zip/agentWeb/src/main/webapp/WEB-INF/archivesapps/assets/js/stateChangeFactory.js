ArchivesApp.factory('stateChangeFactory', function(archivesConstant) {
    var stateProvider;
    var baseURI = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH;
    var stateURI = "";

    function stateURISlice() {
        var pos = stateURI.lastIndexOf("/");
        return stateURI.slice(0, pos);
    }

    return {
        setStateProvider: function(provider) {
            stateProvider = provider;
        },
        getStateURI: function() {
            return stateURI;
        },
        setStateURI: function(uri) {
            stateURI = baseURI + uri;
        },
        getStateURIByName: function(stateName) {
            return stateURISlice() + stateName;
        },
        getStateURIByFullName: function(fullName) {
            return baseURI + fullName;
        },
    };
});