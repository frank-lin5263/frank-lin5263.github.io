ArchivesApp.controller('AccountController', function ($rootScope, $scope, $http, httpAuth,
    slotStatusFactory, accountFactory, archivesConstant, readCerFactory) {
    $scope.slotData = {};
    $scope.errorMessage = "";

    function slotStateProbe(status) {
        $scope.slotData = slotStatusFactory.defaultSlotData(status);
        $scope.slotData.selected = $scope.slotData.available[0];
    }

    $scope.$on('slotStateProbe', function(events, slotData) {
        $scope.slotData.selected = slotData.available[0];
        $scope.$apply();
    });

    $scope.$on('slotStateError', function(events, error) {
        console.log('slotStateError: ' + error);
        slotStateProbe(error);
    });

    $scope.$on('slotStateChange', function(events, serial) {
        console.log('slotStateChange: ' + serial);
        var status = '連線異常';
        if (serial !== null) {
            status = '連線成功';
        }
        slotStateProbe(status);
        $scope.slotData.selected.serial = serial;
    });

    var isCard = accountFactory.isSmartCard();
    angular.element('#PKIUsage').attr('checked', isCard);
    slotStateProbe('偵測中');
    slotStatusFactory.querySlotStatus($scope.slotData);

    $('.archives-checkbox').checkboxpicker().on('change', function() {
        localStorage.setItem("PKIUsage", this.checked);
        slotStateProbe('偵測中');
        slotStatusFactory.querySlotStatus($scope.slotData);
    });

    function saveSignCert(signCert) {
        $scope.accountForm.b64Cert = signCert;
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/core/account';
        $http.post(url, $scope.accountForm)
        .then(function(response) {
            $scope.modalOptions.close();
        }, function errorCallback(response) {
            $scope.errorMessage = response.errorMessage;
        });
    }

    $scope.accountBt = function (form) {
        httpAuth.setCookies('cardNo', $scope.slotData.selected.serial);
        $scope.accountForm.cardNo = $scope.slotData.selected.serial;
        readCerFactory.accountGetCertByUsage(saveSignCert, "digitalSignature");
    }

});