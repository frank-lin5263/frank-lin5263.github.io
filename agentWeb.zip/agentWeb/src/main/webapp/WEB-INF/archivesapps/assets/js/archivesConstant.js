ArchivesApp.constant('archivesConstant', {
    WEB_ROOT_PATH: $('#ng_load_plugins_before').attr("value"),
    REST_API_VERSION_PATH: '/v1',
    APP_PATH: 'archivesapps',
    CHANGE_RECORD_PATH: '/changeRecord',
    REGISTER_SEARCH_PATH: '/registerSearch',
    DOCUMENT_SYSTEM_PATH: '/documentSystem',
    SYSTEM_TOOL_PATH: '/systemTool',
    SESSION_PATH: '/session',
    HTML_FOLDER:'/views',
    SYSTEM_TOOL_FOLDER_PATH: '/SystemTool',
    DOC_EXCHANGE_PATH: "/docExchange",
    SEND_DOC_PATH: "/sendDocument",

    REST_READ_PATH: '/read',
    REST_CREATE_PATH: '/create',
    REST_UPDATE_PATH: '/update',
    REST_DELETE_PATH: '/delete',
    REST_INIT_PATH: '/init',
    REST_UPLOAD_PATH: '/upload',
    REST_UPLOAD_ZIP: '/zipFile',

    VALID_NUMBER: 0,
    VALID_STRING: 1,
    VALID_MAIL_ADDRESS: 2,
    VALID_EMPTY: 3,
    VALID_ENG_NUM: 4,

    ROLE: '權限',
    CHOICE: '請選擇',
    INPUT: '請輸入',
    CANT_EMPTY: '不可為空',
    NO_UPDATE: '尚未做任何修改',
    NO_INPUT: '尚未輸入資料',
    INPUT_ERROR: '輸入格式錯誤',

    INSERT_SUCCESS_MSG: '新增成功',
    RUN_SUCCESS_MSG: '執行成功',
    UPDATE_SUCCESS_MSG: '修改成功',
    DELETE_SUCCESS_MSG: '刪除成功',

    ALL_CENTER_STATUS: '全部',
    ACTIVE_CENTER_STATUS: '啟用',
    PAUSE_CENTER_STATUS: '暫停',
    STOP_CENTER_STATUS: '停用',

    SENDER_TITLE_MSG: ' 交換記錄彙整 / 公文傳送訊息',
    RECEIVE_TITLE_MSG: ' 交換記錄彙整 / 公文接收訊息',
    INNER_TITLE_MSG: '內部對內部交換',
    OUT_TITLE_MSG: '內部對外部交換',
    INNER_TRANSMIT_TYPE: 'INNER',
    OUT_TRANSMIT_TYPE: 'OUTTER',
    SAVE_SUCCESS_MSG: '儲存成功',
    FORM_INVALID_MSG: "輸入格式錯誤",
    QUERY_WITHOUT_RESULT: '無符合條件的查詢結果！',

    BUTTON_SUBMIT_MSG: '確定',
    BUTTON_EXPORT_MSG: '轉檔成功',
    BUTTON_RETURN_MSG: '返回列表',

    NO_REG_CERT: '憑證檔案不存在,請插入卡片後重新整理網頁',
    SLOT_EMPTY: '未插入IC卡',
    SEARCH_WITHOUT_RESULT: '無符合條件的查詢結果！',

    START_DOC_ID:'起始文號',
    END_DOC_ID:'結束文號'

});