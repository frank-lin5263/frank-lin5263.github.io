ArchivesApp.factory("accountManagementFactory", function ($http, httpAuth, archivesConstant) {
    return {
        login: function (body) {
            var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + '/users/login'
        	return httpAuth.post(url, body);
        },
        token: function (url) {
            return httpAuth.get(url);
        },
        createAccount: function (body, spi) {
/*        	if(spi){
            	httpAuth.setSession('Spi', spi);
            	httpAuth.setSession('OAuthProvider', 'yahoo');
        	}
        	return httpAuth.post('/api/users', body);*/
        },
        saveImage: function (formData) {
/*        	return $http.post('/api/users/file', formData, {
                headers: {'Content-Type': undefined },
                transformRequest: angular.identity
            });*/
        }
    }
});