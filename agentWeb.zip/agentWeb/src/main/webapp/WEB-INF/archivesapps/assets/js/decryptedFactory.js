ArchivesApp.factory('decryptedFactory', function($rootScope, $http, httpAuth, accountFactory, archivesConstant) {
    var target;
    var timeoutId;
    function postData(target,data) {
	    if(!http.sendRequest) {
		    return null;
	    }
	    http.url=target;
	    http.actionMethod="POST";
	    var code=http.sendRequest(data);
	    if(code!=0) return null;
	    return http.responseText;
    }

    function checkFinish() {
	    if(target) {
		    target.close();
		    //alert("尚未安裝元件");
	    	var response = {
	    	    errorMessage: '尚未安裝元件'
	    	};
	    	exceptionViewer(response, false);
	    }
    }

    var encryptPackage = {
        event : "",
        documentId: "",
        encryptData : "",
        getEncryptedPackage : function(encryptData) {
	        var tbsData = {};
	        tbsData["cipher"] = encryptData;
	        tbsData["cipherType"] = "PKCS1";
	        tbsData["plainEncoding"] = "base64";
	        tbsData["pin"] = httpAuth.getCookies('pinCode');
	        tbsData["func"]="DecryptData";
	        tbsData["slotDescription"] = httpAuth.getCookies('slotDesc');
	        return JSON.stringify(tbsData ).replace(/\+/g,"%2B");
        }
    }

    function decryptData(encryptData, documentId, event) {
        var ua = window.navigator.userAgent;
        encryptPackage.event = event;
        encryptPackage.documentId = documentId;
        encryptPackage.encryptData = encryptData;
        //is IE, use ActiveX
	    if(ua.indexOf("MSIE")!=-1 || ua.indexOf("Trident")!=-1) {
		    target=window.open("http://localhost:61161/waiting.gif", "Decrypting","height=200, width=200, left=100, top=20");
		    var tbsPackage = encryptPackage.getEncryptedPackage(encryptPackage.encryptData);
		    document.getElementById("httpObject").innerHTML='<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
		    var data=postData("http://localhost:61161/decrypt","tbsPackage="+tbsPackage);
		    target.close();
		    target=null;
		    if(!data) {
	    	    var response = {
	    	        errorMessage: '尚未安裝元件'
	    	    };
	    	    exceptionViewer(response, false);
		    } else {
		        setDecryptResult(data, encryptPackage.documentId, encryptPackage.event);
		    }
	    } else {
		    target = window.open("http://localhost:61161/popupForm", "解密中","height=200, width=200, left=100, top=20");
		    timeoutId = setTimeout(checkFinish, 6000);
	    }
    }

    function processDecryptPsw(event, documentId, plain) {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + archivesConstant.DOC_EXCHANGE_PATH + '/receiveDocument/MSDecrypted';
        var params = accountFactory.getDocumentParams();
        params.documentId = documentId;
        params.encryptedPsw = plain;
        $http.post(url, params).then(function(response) {
            if (response.data.resultCode === 0) {
                $rootScope.$broadcast(event, response.data.resultData);
            }
        }, function errorCallback(response) {
            exceptionViewer(response, false);
        });
    }

    function broadcastDecryptToken(event, plain) {
	    accountFactory.setDecryptedToken(plain);
        $rootScope.$broadcast(event, plain);
    }

    function broadcastRejectMsg(rejectMsg) {
        $rootScope.$broadcast('rejectRequest', rejectMsg);
    }

    function setDecryptResult(result, documentId, event) {
	    var res = JSON.parse(result);
	    if(res.ret_code == 0) {
	        if (event === 'decryptPsw') {
	            processDecryptPsw(event, documentId, res.plain);
	        } else {
	            broadcastDecryptToken(event, res.plain);
	        }
	    } else {
	    	var response = {
	    	    errorMessage: res.ret_code.toString(16)
	    	};
	    	exceptionViewer(response, false);
	        broadcastRejectMsg(response.errorMessage);
	    }
    }

    function receiveMessage(event) {
	    //if(console) console.debug(event);

	    //安全起見，這邊應填入網站位址檢查
	    if(event.origin!="http://localhost:61161")
		    return;
	    try {
		    var ret = JSON.parse(event.data);
		    if(ret.func) {
			    if(ret.func == "getTbs") {
			        if (target != null) {
				        clearTimeout(timeoutId);
				        var json = encryptPackage.getEncryptedPackage(encryptPackage.encryptData);
				        target.postMessage(json,"*");
			        }
			    } else if(ret.func == "decrypt") {
				    setDecryptResult(event.data, encryptPackage.documentId, encryptPackage.event);
			    }
		    } else {
		        broadcastRejectMsg('收文取消,解密異常');
			    if(console) console.error("no func");
		    }
	    } catch(e) {
		    broadcastRejectMsg('收文取消,解密異常');
		    if(console) console.error(e);
	    }
    }
    if (window.addEventListener) {
	    window.addEventListener("message", receiveMessage, false);
	} else {
	    //for IE8
        window.attachEvent("onmessage", receiveMessage);
    }

    function decryptedData(data, documentId, event) {
        var decryptUrl = 'https://localhost:61162/v1/decrypt';
        var params = {
            account: httpAuth.getCookies('account'),
            password: httpAuth.getCookies('pinCode'),
            encryptData: data
        };
        $http.post(decryptUrl, params).success(function (response) {
	        if (response.resultCode == 0) {
	            if (event === 'decryptPsw') {
	                processDecryptPsw(event, documentId, response.resultData);
	            } else {
	                broadcastDecryptToken(event, response.resultData);
	            }
	        }
        }).error(function (response) {
            exceptionViewer(response, false);
        });
	}

    return {
        getDecryptedData: function(encryptData, documentId, event) {
            if (localStorage.getItem("PKIUsage") == 'true') {
                decryptData(encryptData, documentId, event);
            } else {
                decryptedData(encryptData, documentId, event);
            }
        }
    };
});