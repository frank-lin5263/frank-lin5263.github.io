ArchivesApp.service('modalService', function($uibModal, archivesConstant) {

    var modalDefaults = {
        backdrop: true,
        keyboard: true,
        modalFade: true,
        templateUrl: 'archivesapps/templates/partials/defaultModal.html'
    };

    var modalOptions = {
        closeButtonText: 'Close',
        actionButtonText: 'OK',
        headerText: '全國共用公文電子交換機關系統',
        bodyText: 'Perform this action?'
    };

    this.showModal = function (customModalDefaults, customModalOptions) {
        if (!customModalDefaults)
            customModalDefaults = {};
        customModalDefaults.backdrop = 'static';
        return this.show(customModalDefaults, customModalOptions);
    }

    this.show = function (customModalDefaults, customModalOptions) {
        var tempModalDefaults = {};
        var tempModalOptions = {};

        angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);
        angular.extend(tempModalOptions, modalOptions, customModalOptions);

        if (!tempModalDefaults.controller) {
            tempModalDefaults.controller = function ($scope, $uibModalInstance) {
                $scope.modalOptions = tempModalOptions;

                $scope.modalOptions.ok = function (result) {
                    $uibModalInstance.close(result);
                };
                $scope.modalOptions.close = function (result) {
                    $uibModalInstance.dismiss('cancel');
                };
                $scope.modalOptions.reloadFor = function (feature) {
                	$uibModalInstance.dismiss('cancel');
                	tempModalDefaults.templateUrl = 'archivesapps/templates/partials/'+feature+'Modal.jsp';
                	return $uibModal.open(tempModalDefaults).result;
                };
            }
        }

        return $uibModal.open(tempModalDefaults).result;
    }

});