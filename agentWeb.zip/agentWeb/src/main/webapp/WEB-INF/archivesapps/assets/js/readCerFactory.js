ArchivesApp.factory('readCerFactory', function($rootScope, $window, $http, $uibModal, accountFactory, httpAuth,
    archivesService, archivesConstant) {
    var self = this;
    var postTarget;
    var timeoutId;
    var certUsage = '';

    var message = {
        notInstallMsg: "尚未安裝元件",
        notTrustMsg: "非信任網站，請先加入信任網站",
        notStartMsg: "未安裝客戶端程式或未啟動服務",
        notCORSMsg: "CORS not supported",
        requestErrorMsg: "Woops, there was an error making the request."
    }

    function postData(target, data) {
        if (!http.sendRequest) {
            return null;
        }
        http.url = target;
        http.actionMethod = "POST";
        var code = http.sendRequest(data);
        if (code != 0) return null;
        return http.responseText;
    }

    function checkFinish() {
        if (postTarget) {
            postTarget.close();
            exceptionViewer(message.notInstallMsg, false);
        }
    }

    function setUibModal(func, htmlType, htmlName) {
        $uibModal.open({
            templateUrl: archivesService.includeOtherHtml(htmlType, htmlName),
            controller: func,
            backdrop : 'static',
            keyboard : false
        });
    }

    function checkCertSuccess(certb64) {
        var url = archivesConstant.WEB_ROOT_PATH + archivesConstant.REST_API_VERSION_PATH + "/cert/check";
        $http.post(url, certb64).then(function(response) {
            if (typeof self.callback === 'function') {
                self.callback();
            }
        },
        function(errResponse) {
            var uibModalController = function($scope, $uibModalInstance) {
                $scope.headerMsg = '系統訊息';
                $scope.cardChangeMsg = errResponse.data.errorMessage;
                $scope.okBtn = '確定';
                $scope.submit = function() {
                    $uibModalInstance.close();
                };
            };
            setUibModal(uibModalController, message.HTML_TYPE, message.HW_HTML_NAME);
            $rootScope.btDisabled = false;
        });
    }

    function slotEmpty() {
        var slotStatus = {
            serialNumber: '',
            slotDescription: '未驗證憑證'
        };
        $rootScope.$broadcast('slotStateChange', slotStatus);
        actionResultViewer(archivesConstant.NO_REG_CERT);
    }

    function receiveMessage(event) {
        //安全起見，這邊應填入網站位址檢查
        if (event.origin != "http://localhost:61161")
            return;
        try {
            var ret = JSON.parse(event.data);

            if (ret.func === "getTbs") {
                if (postTarget != null) {
                    clearTimeout(timeoutId);
                    var tbsData = {"func": "GetUserCert"};
                    var json = JSON.stringify(tbsData);
                    postTarget.postMessage(json, "*");
                }
            } else if (ret.func === "pkcs11info") {
                setUserCert(event.data);
            }
        } catch (e) {
            if (console)
                console.error(e);
        }
    }

    function setUserCert(certData) {
        var ret = JSON.parse(certData);
        if (ret.ret_code == 0) {
            var cardNumber = httpAuth.getCookies('cardNo');
            var slots = ret.slots;
            for (var index in slots) {
                if (slots[index].token == null || slots[index].token === "unknown token") continue;
                var certs = slots[index].token.certs;
                for (var indexCert in certs) {
                    if (certs[indexCert].usage == certUsage) {
                        if (cardNumber == slots[index].token.serialNumber) {
                            if (typeof self.callback === 'function') {
                                self.callback(certs[indexCert].certb64);
                            }
                            return;
                        }
                    }
                }
            }
        }
        slotEmpty();
    }

    function checkUserCert(usage) {
        certUsage = usage;
        var ua = window.navigator.userAgent;
        if (ua.indexOf("MSIE") != -1 || ua.indexOf("Trident") != -1) //is IE, use ActiveX
        {
            postTarget = window.open("http://localhost:61161/waiting.gif", "Reading", "height=200, width=200, left=100, top=20");
            $window.document.getElementById("httpObject").innerHTML = '<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
            var data = postData("http://localhost:61161/pkcs11info?withcert=true", "");
            postTarget.close();
            postTarget = null;
            if (!data)
                exceptionViewer(message.notInstallMsg, false);
            else
                setUserCert(data);
        }
        else
        {
            postTarget = window.open("http://localhost:61161/popupForm", "處理中", "height=200, width=200, left=100, top=20");
            timeoutId = setTimeout(checkFinish, 3500);
        }
    }

    if ($window.addEventListener) {
        $window.addEventListener("message", receiveMessage, false);
    } else {
        //for IE8
        $window.attachEvent("onmessage", receiveMessage);
    }

    // Create the XHR object.
    function createCORSRequest(method, url) {
        var xhr = new XMLHttpRequest();
        if ("withCredentials" in xhr) {
            // XHR for Chrome/Firefox/Opera/Safari.
            xhr.open(method, url, true);
        } else if (typeof XDomainRequest != "undefined") {
            // XDomainRequest for IE.
            xhr = new XDomainRequest();
            xhr.open(method, url);
        } else {
            xhr = null;
        }
        return xhr;
    }

	function getSWUserCert(endpoint, params) {
        var url = endpoint + accountFactory.getFormatParams(params);
        var xhr = createCORSRequest('GET', url);
        if (!xhr) {
            exceptionViewer(message.notCORSMsg, false);
            return;
        }
        // Response handlers.
        xhr.onload = function() {
            setCertResponse(xhr.responseText);
        };

        xhr.onerror = function() {
            exceptionViewer(message.requestErrorMsg, false);
        };
        xhr.send();
	}

    function setCertResponse(certData) {
        var ret = JSON.parse(certData);
	    if(ret.resultCode == 0x0) {
            if (typeof self.callback === 'function') {
                self.callback(ret.resultData);
            }
            return ret.resultData;
        } else {
	        if(ret.resultCode == 0x76000031) {
		        exceptionViewer($window.location.hostname + message.notTrustMsg, false);
	        }
        }
    }

    function checkPKIUsage(usage) {
        if (localStorage.getItem("PKIUsage") == 'true') {
            checkUserCert(usage);
        } else {
            var params = {
                usage: usage,
                password: httpAuth.getCookies('pinCode')
            };
            getSWUserCert('https://localhost:61162/v1/publicKey', params);
        }
    }

    function accountPKIUsage(usage) {
        if (localStorage.getItem("PKIUsage") == 'true') {
            checkUserCert(usage);
        } else {
            var params = {
                isDigitalSign: true
            };
            getSWUserCert('https://localhost:61162/v1/base64Cer', params);
        }
    }

    return {
        getCertByUsage: function(callback, usage) {
            self.callback = callback;
            checkPKIUsage(usage);
        },
        accountGetCertByUsage: function(callback, usage) {
            self.callback = callback;
            accountPKIUsage(usage);
        }
    };
});