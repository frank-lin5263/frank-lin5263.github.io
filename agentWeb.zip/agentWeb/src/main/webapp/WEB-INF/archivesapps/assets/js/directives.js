ArchivesApp.directive('a', function() {
    return {
        restrict: 'E',
        link: function(scope, elem, attrs) {
            if (attrs.ngClick || attrs.href === '' || attrs.href === '#') {
                elem.on('click', function(e) {
                    e.preventDefault();
                });
            }
        }
    };
}).directive('archivesSort', function($compile) {
    return {
        restrict: 'A',
        link: function(scope, elem, attrs) {
            scope.toggleArrowClass = function(toggle) {
                return toggle ? 'fa-sort-desc' : 'fa-sort-asc';
            };

            var arrow = "<i class=\"fa\" ng-class=\"toggleArrowClass(archivesService.sorter.descending)\" ng-show=\"archivesService.isCurrentSort(" + attrs.archivesSort + ")\" aria-hidden=\"true\"></i>";
            elem.html($compile('<a href="#" ng-click="archivesService.sortByColumnName(' + attrs.archivesSort + ')">' + elem.text() + '</a>' + arrow)(scope));
            elem.on('click', function(e) {
                e.preventDefault();
                scope.$apply();
            });
        }
    };
}).directive('modal', function() {
    return {
        templateUrl: "archivesapps/templates/messageModal.html",
        restrict: 'E',
        transclude: true,
        replace: true,
        scope: true,
        link: function postLink(scope, element, attrs) {
            scope.title = attrs.title;
            scope.size = attrs.size;

            scope.$watch(attrs.visible, function(value) {
                if (value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function() {
                scope.$apply(function() {
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function() {
                scope.$apply(function() {
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
});