ArchivesApp.service('progressBarService', function($rootScope, $uibModal, archivesService, archivesConstant) {
    var self = this;
    self.progressType = 0;
    self.title = "";
    self.uibModal;

    this.openProgressModal = function(type, title, showFooter) {
        var types = ['success', 'info'];
        self.progressType = type;
        self.title = title;
        var modal = function($scope, $uibModalInstance, $interval) {
            $scope.dynamic = 0;
            sessionStorage.setItem("dynamic", 0);
            $scope.title = self.title;
            $scope.showFooter = showFooter;
            var delay = 100;
            if (type == 0) {
                $scope.type = types[type];
                $scope.max = 100;
                $scope.number = sessionStorage.getItem("max");
            } else if (type == 1) {
                $scope.type = types[type];
                $scope.max = sessionStorage.getItem("max");
                $scope.number = $scope.max;
            } else {
                console.error("error type:" + type);
                return;
            }
            if (localStorage.getItem("PKIUsage") == 'true') {
                delay = 500;
            }

            var timer = null;
            if (type == 0) {
                var updatePercent = function() {
                    $scope.dynamic = sessionStorage.getItem("dynamic");
                    $scope.progress = $scope.dynamic + '%';
                    if ($scope.dynamic == 100) {
                        setTimeout(function() {
                            showFooter = false;
                            $scope.cancel();
                        }, 500);
                    }
                }

                timer = $interval(updatePercent, delay);
            } else {
                var update = function() {
                    $scope.dynamic = sessionStorage.getItem("dynamic");
                    $scope.progress = $scope.dynamic + "/" + $scope.max;
                    if ($scope.dynamic == $scope.max) {
                        setTimeout(function() {
                            showFooter = false;
                            $scope.cancel();
                        }, 500);
                    }
                }

                timer = $interval(update, delay);
            }

            $scope.cancel = function() {
                $uibModalInstance.close();
                $scope.dynamic = 0;
                $scope.progress = 0;
                $interval.cancel(timer);
                if (showFooter) {
                    $rootScope.$broadcast('rejectRequest', '使用者取消');
                }
            };
        };

        self.uibModal = $uibModal.open({
            templateUrl: archivesService.includeOtherHtml('Template', 'exchangeModal'),
            controller: modal,
            backdrop : 'static',
            keyboard : false
        });
    };

    this.closeModal = function() {
        self.uibModal.close();
    }

    function setPercentValue(value) {
        var percent;
        if (value > 0) {
            var max = sessionStorage.getItem("max");
            percent = (value / max) * 100;
        } else {
            percent = 0;
        }
        var percent = Math.round(percent);
        sessionStorage.setItem("dynamic", percent);
    }

    this.setMaxValue = function(max) {
        sessionStorage.setItem("max", max);
    }

    this.setCurrentValue = function(value) {
        if (self.progressType == 0) {
            setPercentValue(value);
        } else if (self.progressType == 1) {
            sessionStorage.setItem("dynamic", value);
        }
    }

});