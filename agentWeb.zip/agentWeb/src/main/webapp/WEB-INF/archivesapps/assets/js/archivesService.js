ArchivesApp.constant("archivesServiceConstant", {
    //CONSTANT_LIST
    VALID_NUMBER_PATTERN: /^[-|\d]+$/,
    VALID_STRING_PATTERN: /^([\u4e00-\u9fa5]|\w|\-)+$/,
    VALID_ENG_NUM_PATTERN: /^\w+$/,
    VALID_MAIL_ADDRESS_PATTERN: /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
}).service('archivesService', function($http, archivesServiceConstant, archivesConstant) {

    var defaultSorter = {
        columnName: "",
        descending: false
    };

    this.sorter = angular.copy(defaultSorter);

    this.sortByColumnName = function(columnName) {
        this.sorter.descending = columnName === this.sorter.columnName ? !this.sorter.descending : false;
        this.sorter.columnName = columnName;
    };

    this.isCurrentSort = function(columnName) {
        return checkUndefinedAndEmpty(this.sorter.columnName) ? false : this.sorter.columnName.replace(/\'/g, '') === columnName;
    };

    this.resetSorter = function () {
        this.sorter = angular.copy(defaultSorter);
    };

    var defaultPager = {
        itemsPerPage: 10,
        pagerMaxSize: 5,
        firstItemDataNum: 0,
        currentPage: 1
    };

    this.pager = angular.copy(defaultPager);

    this.changePager = function() {
        this.pager.firstItemDataNum = (this.pager.currentPage - 1) * this.pager.itemsPerPage;
    };

    this.resetPager = function() {
        this.pager = angular.copy(defaultPager);
    };

    this.resetSorterAndPager = function() {
        this.resetSorter();
        this.resetPager();
    };

    //-- build url path
    this.buildUrlByPaths = function() {
        var webRootUrl = archivesConstant.WEB_ROOT_PATH;

        for (var key in arguments) {
            webRootUrl += arguments[key];
        }

        return webRootUrl;
    };

    //-- easy hours list
    //For Html ng-options="hour as hour for hour in initHourList() track by hour"
    this.initHourList = function() {
        var hourList = [];

        var formatTime = function(timeValue) {
            return timeValue.toString().length < 2 ? "0" + timeValue : timeValue;
        };

        for (var i = 0; i < 24; i++) {
            hourList.push(formatTime(i));
        }

        return hourList;
    };

    //-- validation
    this.validation = function(text, value, validType) {

        switch (validType) {
            case archivesConstant.VALID_NUMBER:
                return !archivesServiceConstant.VALID_NUMBER_PATTERN.test(value) && !checkUndefinedAndEmpty(value) ?
                        text + "僅能填入數字" : "";
            case archivesConstant.VALID_STRING:
                return !archivesServiceConstant.VALID_STRING_PATTERN.test(value) && !checkUndefinedAndEmpty(value) ?
                        text + "不能含有特殊字元" : "";
            case archivesConstant.VALID_MAIL_ADDRESS:
                return !archivesServiceConstant.VALID_MAIL_ADDRESS_PATTERN.test(value) && !checkUndefinedAndEmpty(value) ?
                        text + "不符合電子郵件格式" : "";
            case archivesConstant.VALID_ENG_NUM:
                return !archivesServiceConstant.VALID_ENG_NUM_PATTERN.test(value) && !checkUndefinedAndEmpty(value) ?
                        text + "僅能填入英文或數字" : "";
            default:
                return checkUndefinedAndEmpty(value) ?
                        text + "為必填欄位" : "";
        }
    };

    this.validationStringLength = function(text, value, min, max) {
        if (!checkUndefinedAndEmpty(value)) {
            var isLessMinValue = !checkUndefinedAndEmpty(min) && value.length < min;
            var isOverThenMaxValue = !checkUndefinedAndEmpty(max) && value.length > max;

            if (isLessMinValue) {
                return text + "最少輸入" + min + "碼";
            } else if (isLessMinValue || isOverThenMaxValue) {
                return text + "字數需介於" + min + " ~ " + max + "之間";
            }
        }
        return "";
    };

    this.validationNonEmpty = function(text, value, validType) {
        var isEmpty = this.validation(text, value, archivesConstant.VALID_EMPTY);

        return isEmpty !== "" ? isEmpty : this.validation(text, value, validType);
    };

    this.validationNonMsg = function(value, validType) {
        switch (validType) {
            case archivesConstant.VALID_NUMBER:
                return archivesServiceConstant.VALID_NUMBER_PATTERN.test(value);
            case archivesConstant.VALID_STRING:
                return archivesServiceConstant.VALID_STRING_PATTERN.test(value);
            case archivesConstant.VALID_MAIL_ADDRESS:
                return archivesServiceConstant.VALID_MAIL_ADDRESS_PATTERN.test(value);
            case archivesConstant.VALID_ENG_NUM:
                return archivesServiceConstant.VALID_ENG_NUM_PATTERN.test(value);
            case archivesConstant.VALID_EMPTY:
                return typeof value !== "undefined";
            default:
                return validType.test(value);
        }
    };

    this.formatErrorMessage = function() {
        var errorMessage = "";
        var alertSignal = "<span class=\"glyphicon glyphicon-exclamation-sign\" aria-hidden=\"true\"></span>";

        for (var key in arguments) {
            if (arguments[key] !== '') {
                errorMessage += alertSignal + arguments[key];
                errorMessage += key !== arguments.length ? "<br>" : "";
            }
        }

        return errorMessage;
    };


    //-- sessionStorage for save temp data
    var sessionSettings = {
        appName: ""
    };

    this.registerApp = function(curAppName) {
        sessionSettings.appName = curAppName;
    };

    this.setSessionStorage = function(filterContent) {
        sessionStorage[sessionSettings.appName] = filterContent;
    };

    this.getSessionStorage = function() {
        return sessionStorage[sessionSettings.appName];
    };

    //-- for modal use
    this.includeOtherHtml = function(htmlType, htmlName) {
        return this.buildUrlByPaths(
                "/" + archivesConstant.APP_PATH +
                archivesConstant.HTML_FOLDER +
                "/" + htmlType +
                "/" + htmlName + ".html");
    };

    function checkUndefinedAndEmpty(value) {
        return (typeof value === "undefined" || value === "");
    }

    this.sendGetRequest = function(url, config) {
    	return $http.get(url, config).error(function(response) {
    		exceptionViewer(response, false);
    	});
    };


    this.sendPostRequest = function(url, content, config) {
    	return $http.post(url, content, config).error(function(response) {
    		exceptionViewer(response, false);
    	});
    };

    this.sendPutRequest = function(url, content, config) {
    	return $http.put(url, content, config).error(function(response) {
    		exceptionViewer(response, false);
    	});
    };

    this.sendDeleteRequest = function(url, config) {
    	return $http.delete(url, config).error(function(response) {
    		exceptionViewer(response, false);
    	});
    };









    this.filterJson = {
        errorStatus: false,
        errorMessage: ''
    };

    this.filterPattern = (function(inputData) {
        var pattern_TW = /[^\u4e00-\u9fa5a-zA-Z0-9]/;
        var pattern_Number = /[^0-9]$/;
        var pattern_EMail = /[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
        var keepGoing = true;
        var errorStatusInside;
        var errorMessageInside = '';
        angular.forEach(inputData, function(valueOut, keyOut) {
            if (keyOut === 'filterSymbol') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value==='string') {
                        if (pattern_TW.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請勿輸入特殊符號%';
                            keepGoing = false;
                        }
                    }
                });
            }
            if (keyOut === 'onlyNumber') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value==='string') {
                        if (pattern_Number.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請輸入數字%';
                            keepGoing = false;
                        }
                    }
                });
            }
            if (keyOut === 'mail') {
                angular.forEach(valueOut, function(value, key) {
                    if (typeof value==='string') {
                        if (!pattern_EMail.test(value.trim())) {
                            errorStatusInside = true;
                            errorMessageInside = errorMessageInside + '$' + key + '請輸入正確email格式%';
                            keepGoing = false;
                        }
                    }
                });
            }
        });
        this.filterJson.errorStatus = errorStatusInside;
        this.filterJson.errorMessage = errorMessageInside;
        return keepGoing;
    });

    this.getMimeType = function(extension) {
        var mimeType = [
            { ext: 'di', mime: 'application/octet-stream'},
            { ext: 'pdf', mime: 'application/pdf'},
            { ext: 'ppt', mime: 'application/vnd.ms-powerpoint'},
            { ext: 'doc', mime: 'application/msword'},
            { ext: 'xls', mime: 'application/vnd.ms-excel'},
            { ext: 'sw', mime: 'application/octet-stream'},
            { ext: 'zip', mime: 'application/x-zip-compressed'}
        ];
        for (var i = 0; i < mimeType.length; i += 1) {
            if (extension === mimeType[i].ext) {
                return mimeType[i].mime;
            }
        }
        console.error('extension: ' + extension);
        return null;
    }
});