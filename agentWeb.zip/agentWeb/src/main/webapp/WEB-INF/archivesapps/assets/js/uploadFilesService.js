ArchivesApp.service('uploadFilesService', function($rootScope, $http, $interval, Upload, accountFactory,
    signatureFactory, progressBarService, archivesService, archivesConstant) {
    var uploadUrl = buildFileUploadUrl() + archivesConstant.REST_UPLOAD_PATH;
    var sendArray = [];
    var signedFiles = [];
    var signingFiles;
    var documentId;
    var fileArray = [];
    var maxUpload = 0;
    var deleteFile = true;
    var scheduled = null;
    var delay = 60000;
    //var repeat = 0;

    function buildFileUploadUrl() {
        return archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                archivesConstant.DOC_EXCHANGE_PATH, archivesConstant.SEND_DOC_PATH);
    }

    function addSignedFiles(fileName, fileSig) {
        signedFiles.push({
            'fileName': fileName,
            'fileSig': fileSig
        });
        return signedFiles.length;
    }

    function convertMSRequestSignedFile(agentResult) {
        documentId = agentResult.documentId;
        signingFiles = agentResult.signingFiles;
        progressBarService.setMaxValue(signingFiles.length);
        progressBarService.setCurrentValue(0);
        progressBarService.openProgressModal(1, '簽章中', false);
        signedFiles.length = 0;
        signatureFactory.getSignHashByEvent(signingFiles[0], 'msRequest');
    }

    $rootScope.$on('msRequest', function(events, args, fileName) {
        var index = addSignedFiles(fileName, args.signature);
        progressBarService.setCurrentValue(index);
        if (index < signingFiles.length) {
            var signingFile = signingFiles[index];
            signatureFactory.getSignHashByEvent(signingFile, 'msRequest');
        } else {
            var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                    archivesConstant.DOC_EXCHANGE_PATH, archivesConstant.SEND_DOC_PATH) + '/MSEncrypted';
            var params = accountFactory.getDocumentParams();
            params.documentId = documentId;
            params.signedFiles = signedFiles;
            $http.post(url, params).success(function(response) {
                convertMSEncryptSignedFile(response.resultData);
            }).error(function(response) {
                accountFactory.setWorking(false);
                exceptionViewer(response, false);
            });
        }
    });

    function convertMSEncryptSignedFile(agentResult) {
        documentId = agentResult.documentId;
        signingFiles = agentResult.signingFiles;
        progressBarService.setMaxValue(signingFiles.length);
        progressBarService.openProgressModal(1, '簽章中', false);
        signedFiles.length = 0;
        signatureFactory.getSignHashByEvent(signingFiles[0], 'msEncrypt');
    }

    function startUploadFile() {
        accountFactory.setWorking(true);
        fileArray.length = 0;
        var nameArray = sendArray.pop();
        maxUpload = nameArray.length;
        progressBarService.setMaxValue(maxUpload);
        progressBarService.setCurrentValue(0);
        progressBarService.openProgressModal(0, '上傳中', false);
	    uploadByNameArray(nameArray);
    }

    $rootScope.$on('msEncrypt', function(events, args, fileName) {
        var index = addSignedFiles(fileName, args.signature);
        progressBarService.setCurrentValue(index);
        if (index < signingFiles.length) {
            var signingFile = signingFiles[index];
            signatureFactory.getSignHashByEvent(signingFile, 'msEncrypt');
        } else {
            var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                    archivesConstant.DOC_EXCHANGE_PATH, archivesConstant.SEND_DOC_PATH) + '/sendOut';
            var params = accountFactory.getDocumentParams();
            params.documentId = documentId;
            params.signedFiles = signedFiles;
            $http.post(url, params).success(function(response) {
                accountFactory.setWorking(false);
                $rootScope.$broadcast('sendFinished', response.resultData);
            }).error(function(response) {
                accountFactory.setWorking(false);
                exceptionViewer(response, false);
            });
        }
    });

    function uploadFiles(files) {
        var params = accountFactory.getDocumentParams();
        Upload.upload({
            url: uploadUrl,
            data: {
                orgUnitId: params.orgUnitId,
                decryptedToken: params.decryptedToken,
                signedToken: params.signedToken,
                sessionId: params.confirmResult.sessionId,
                expireTime: params.confirmResult.expireTime,
                files: files
            }
        }).then(function (response) {
            var agentResult = response.data.resultData;
            progressBarService.setCurrentValue(maxUpload);
            setTimeout(function () {
                convertMSRequestSignedFile(agentResult);
            }, 750);
        }, function (response) {
            accountFactory.setWorking(false);
            progressBarService.closeModal();
            if (response.status > 0) {
                var exception = response.data;
                $rootScope.$broadcast('toggleAlert', exception);
            }
        });
    }

    function uploadByNameArray(nameArray) {
        var endpoint = 'https://localhost:61162/v1/upload';
        var url = endpoint + accountFactory.getFormatParams({
                                                            name: nameArray[fileArray.length],
                                                            isDelete: deleteFile
                                                            });
        $http.get(url, { responseType: 'arraybuffer' }).then(function(response) {
            var fileName = nameArray[fileArray.length];
            var extension = fileName.split('.').pop();
            var mimeType = archivesService.getMimeType(extension);
            var blob = new Blob([response.data], { type: mimeType });
            fileArray[fileArray.length] = new File([blob], fileName, {type: mimeType});
            if (fileArray.length == nameArray.length) {
                uploadFiles(fileArray);
            } else {
                progressBarService.setCurrentValue(fileArray.length);
                uploadByNameArray(nameArray);
            }
        }, function (errResponse) {
            accountFactory.setWorking(false);
            exceptionViewer(errResponse, false);
        });
    }

    function autoSendFiles(repeatCount) {
        repeat = repeatCount;
        if (accountFactory.isWorking() || repeat == 0) {
            return;
        }
        var url = 'https://localhost:61162/v1/autoSendFiles';
        $http.get(url).success(function (response) {
            sendArray = response.resultData;
            if (sendArray.length > 0) {
                startUploadFile();
            } else {
                var args = {
                    errorMessage: '沒有待發公文'
                };
                $rootScope.$broadcast('toggleAlert', args);
            }
        }).error(function (response) {
            if (response === null) {
                var exceptionResponse = {
                    errorMessage: '未安裝PKI local server'
                }
                exceptionViewer(exceptionResponse, false);
            } else {
                exceptionViewer(response, false);
            }
        });
    }

    this.massAutoSendFiles = function(repeat) {
        autoSendFiles(repeat);
    }

    this.autoSendFiles = function() {
        autoSendFiles(1);
    }

    this.uploadZipFile = function(zipFile) {
        uploadUrl = buildFileUploadUrl() + archivesConstant.REST_UPLOAD_ZIP;
        maxUpload = zipFile.length;
        progressBarService.setMaxValue(maxUpload);
        progressBarService.setCurrentValue(0);
        progressBarService.openProgressModal(0, '上傳中', false);
        uploadFiles(zipFile, uploadUrl);
    }

    this.uploadFileArray = function(fileArray) {
        uploadUrl = buildFileUploadUrl() + archivesConstant.REST_UPLOAD_PATH;
        maxUpload = fileArray.length;
        progressBarService.setMaxValue(maxUpload);
        progressBarService.setCurrentValue(0);
        progressBarService.openProgressModal(0, '上傳中', false);
        uploadFiles(fileArray, uploadUrl);
    }

    this.autoSendScheduled = function(isSchedule) {
        if (isSchedule) {
            if (scheduled == null) {
                autoSendFiles(1);
                scheduled = $interval(autoSendFiles, delay);
            }
        } else {
            $interval.cancel(scheduled);
            scheduled = null;
        }
    }
});