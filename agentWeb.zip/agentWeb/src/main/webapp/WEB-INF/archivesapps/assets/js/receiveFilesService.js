ArchivesApp.service('receiveFilesService', function($rootScope, $http, $interval, accountFactory, Upload,
    signatureFactory, decryptedFactory, progressBarService, archivesService, archivesConstant) {
    var receivedDocs = [];
    var receiveConfirmList = [];
    var maxProgressBar = 0;
    var isCancel = false;
    var rejectMsg = "收文取消";
    var receiveModal = {};
    var scheduled;
    var delay = 45123;

    var confirmArray = {
        addReceiveConfirm : function(documentId, result, processId, array) {
            array.push({
                'documentId': documentId,
                'confirmResult': result,
                'processId': processId
            });
            return array.length;
         }
    }

    function receiveReceive(params) {
        var url = archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH + archivesConstant.DOC_EXCHANGE_PATH +
                '/receiveDocument' +
                '/receive';
        $http.post(url, params).success(function(response) {
            if (response.resultCode === 0) {
                var signingFile = { fileName: response.resultData.receiveResult.documentId, fileHash: response.resultData.b64ConfirmHash };
                signatureFactory.getSignHashByEvent(signingFile, 'confirmHash');
            }
        }).error(function(response) {
            accountFactory.setWorking(false);
            $rootScope.$broadcast('errorResponse', response);
        });
    }

    function processReceivedDoc(receivedDoc) {
        accountFactory.setDocumentId(receivedDoc.documentId);
        var params = accountFactory.getDocumentParams();
        if (receivedDoc.cryptoType === 'MS') {
            var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                                        archivesConstant.DOC_EXCHANGE_PATH, '/receiveDocument') + '/MSRequest';
            $http.post(url, params).success(function(response) {
                var result = response.resultData;
                decryptedFactory.getDecryptedData(result.encryptedPsw, result.documentId, 'decryptPsw');
            }).error(function(response) {
                accountFactory.setWorking(false);
                exceptionViewer(response, false);
            });
        } else {
            receiveReceive(params);
        }
    }

    function autoReceiveFiles() {
        if (accountFactory.isWorking()) {
            return;
        }
        isCancel = false;
        receivedDocs.length = 0;
        var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                                archivesConstant.DOC_EXCHANGE_PATH, '/receiveDocument') + '/receiveDoc';
        var params = accountFactory.getDocumentParams();
        receiveConfirmList.length = 0;
        $http.post(url, params).success(function(response) {
            receivedDocs = response.resultData.receivedDocs;
            if (receivedDocs.length === 0) {
                $rootScope.$broadcast('toggleNoFiles');
            } else {
                maxProgressBar = receivedDocs.length;
                progressBarService.setMaxValue(maxProgressBar);
                receiveModal = progressBarService.openProgressModal(1, '收文中', true);
                accountFactory.setWorking(true);
                processReceivedDoc(receivedDocs.pop());
            }
        }).error(function(response) {
            $rootScope.$broadcast('errorResponse', response);
        });
    }

    this.receiveFiles = function() {
        autoReceiveFiles();
    }

    this.autoReceiveScheduled = function(isSchedule) {
        if (isSchedule) {
            if (scheduled == null) {
                autoReceiveFiles();
                scheduled = $interval(autoReceiveFiles, delay);
            }
        } else {
            $interval.cancel(scheduled);
            scheduled = null;
        }
    }

    $rootScope.$on('decryptPsw', function(events, resultData) {
        if (isCancel) {
            isCancel = false;
            rejectRequest(rejectMsg);
            return;
        }
        if (resultData != null) {
            var signingFile = { fileName: resultData.receiveResult.documentId, fileHash: resultData.b64ConfirmHash };
            signatureFactory.getSignHashByEvent(signingFile, 'confirmHash');
        }
    });

    function uncompressFiles(fileName, data) {
        var blob = new Blob([data], {type: archivesService.getMimeType('zip')});
        var docFile = new File([blob], fileName, {type: archivesService.getMimeType('zip')});
        Upload.upload({
            url: 'https://localhost:61162/v1/uncompressFile',
            data: {
                decryptedToken: accountFactory.getDecryptedToken(),
                files: docFile
            }
        }).then(function (response) {
            finishReceiveFiles();
        }, function (response) {
            accountFactory.setWorking(false);
            $rootScope.$broadcast('errorResponse', response);
        });
    }

    this.downloadFile = function(documentId) {
        downloadUncompressFile(documentId);
    }

    function anchorClickDownload(response, documentId) {
        var zip = document.createElement('a');
        zip.href = URL.createObjectURL(new Blob([response.data], { type: 'application/octet-stream' }));
        zip.id = 'zipPath';
        zip.class = 'hidden';
        zip.download = documentId + '.zip';
        document.body.appendChild(zip);
        zip.click();
        document.body.removeChild(zip);
    }

    function downloadUncompressFile(documentId) {
        var endpoint = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                                        '/download', '/zip');
        var params = accountFactory.getDocumentParams();
        var urlParams = {
            "documentId": documentId,
            "decryptedToken": accountFactory.getDecryptedToken(),
        }
        var url = endpoint + accountFactory.getFormatParams(urlParams);
        $http.get(url, { responseType: 'arraybuffer' }).then(function (response) {
            anchorClickDownload(response, documentId);
        }, function (errResponse) {
            exceptionViewer(errResponse, false);
        });
    }

    function finishReceiveFiles() {
        progressBarService.setCurrentValue(maxProgressBar - receivedDocs.length);
        if (receivedDocs.length > 0) {
            processReceivedDoc(receivedDocs.pop());
        } else {
            accountFactory.setWorking(false);
            $rootScope.$broadcast('receiveResult');
        }
    }

    $rootScope.$on('confirmHash', function(events, hashPackage, documentId) {
        if (isCancel) {
            isCancel = false;
            rejectRequest(rejectMsg);
            return;
        }
        setTimeout(function () {
            var url = archivesConstant.WEB_ROOT_PATH +
                archivesConstant.REST_API_VERSION_PATH + archivesConstant.DOC_EXCHANGE_PATH +
                '/receiveDocument' +
                '/receiveConfirm';
            var params = accountFactory.getDocumentParams();
            params.documentId = documentId;
            params.confirmSignature = hashPackage.signature;
            $http.post(url, params).success(function(response) {
                var documentId = response.resultData.documentId;
                var confirmResult = response.resultData.confirmResult;
                var processId = response.resultData.processId;
                confirmArray.addReceiveConfirm(documentId, confirmResult, processId, receiveConfirmList);
                finishReceiveFiles();
                //downloadUncompressFile(receiveConfirmList.pop().documentId);
            }).error(function(response) {
                $rootScope.$broadcast('errorResponse', response);
            });
        }, 150);
    });

    function rejectRequest(rejectMsg) {
        var params = accountFactory.getDocumentParams();
        var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                archivesConstant.DOC_EXCHANGE_PATH, '/receiveDocument') + '/rejectRequest';
        params.rejectMsg = rejectMsg;
        $http.post(url, params).success(function(response) {
            var rejectHash = response.resultData;
            var signingFile = { fileName: params.documentId, fileHash: rejectHash };
            signatureFactory.getSignHashByEvent(signingFile, 'reject');
        }).error(function(response) {
            $rootScope.$broadcast('errorResponse', response);
        });
    }

    $rootScope.$on('rejectRequest', function(events, args) {
        console.log('receiveModal: ' + receiveModal);
        receiveModal.close();
        isCancel = true;
        rejectMsg = args;
        if (rejectMsg.startsWith('收文取消')) {
            rejectRequest(rejectMsg);
        }
    });

    $rootScope.$on('reject', function(events, hashPackage) {
        var params = accountFactory.getDocumentParams();
        var url = archivesService.buildUrlByPaths(archivesConstant.REST_API_VERSION_PATH,
                archivesConstant.DOC_EXCHANGE_PATH, '/receiveDocument') + '/reject';
        params.confirmSignature = hashPackage.signature;
        $http.post(url, params).success(function(response) {
/*            var documentId = response.resultData.documentId;
            var rejectResult = response.resultData.rejectResult;
            var processId = response.resultData.processId;
            confirmArray.addReceiveConfirm(documentId, rejectResult, processId, receiveConfirmList);*/
            if (receivedDocs.length > 0) {
                setTimeout(function () {
                    maxProgressBar = receivedDocs.length;
                    progressBarService.setMaxValue(maxProgressBar);
                    progressBarService.openProgressModal(1, '收文下載中', true);
                    accountFactory.setWorking(true);
                    processReceivedDoc(receivedDocs.pop());
                }, 750);
            } else {
                accountFactory.setWorking(false);
                $rootScope.$broadcast('receiveResult', receiveConfirmList);
            }
        }).error(function(response) {
            $rootScope.$broadcast('errorResponse', response);
        });
    });
});