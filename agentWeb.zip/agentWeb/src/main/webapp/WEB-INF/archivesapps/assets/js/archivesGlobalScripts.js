function includeOtherScript(yourScriptName) {
    if (typeof yourScriptName === 'string' && $('#' + yourScriptName).length === 0) {
        $('head').append($("<script></script>").attr({
            id : yourScriptName,
            src : $('#ng_load_plugins_before').attr("value") + "/archivesapps/assets/js/" + yourScriptName + ".js",
            type : "text/javascript"
        }));
    }
}

function includeOtherController(scriptType, scriptName) {
    if (typeof scriptName === 'string' && $('#' + scriptName).length === 0) {
        $('head').append($("<script></script>").attr({
            id : scriptName,
            src : $('#ng_load_plugins_before').attr("value") + "/archivesapps/controllers/" + scriptType + "/" + scriptName + ".js",
            type : "text/javascript"
        }));
    }
}

function exceptionViewer(exceptionResponse, redirectAction) {
    redirectAction = typeof redirectAction === 'boolean' ? redirectAction : false;
    $('#archivesExceptionViewer').modal("show");

    var msg = '';
    if (typeof exceptionResponse === null) {
        msg = 'not defined error';
    } else if (typeof exceptionResponse.errorMessage !== "undefined") {
        msg = exceptionResponse.errorMessage;
    } else {
        msg = exceptionResponse.data.errorMessage;
    }

    $('#archivesExceptionMsg').text(msg);
    if (redirectAction) {
        setTimeout(redirectToHome(), 3000);
    }
}

function actionResultViewer(msg) {
    $('#archivesSuccessViewer').modal("show");
    $('#archivesSuccessMsg').text(msg);
    setTimeout(function () {
       $('#archivesSuccessViewer').modal("hide");
    }, 1500);
}

function redirectToHome() {
    window.location.href = "/jAgentWeb";
}
