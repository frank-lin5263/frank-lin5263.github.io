ArchivesApp.factory('slotStatusFactory', function($rootScope, $http, $window,
    pkiErrorReasonFactory, archivesConstant, accountFactory) {

    var message = {
        notTrustMsg: "非信任網站，請先加入信任網站",
        notStartMsg: "未安裝客戶端程式或未啟動服務",
        requestErrorMsg: "Woops, there was an error making the request."
    }

    function isWindowsIE() {
        var ua = window.navigator.userAgent;
        return (ua.indexOf("MSIE") != -1 || ua.indexOf("Trident") != -1);
    }

    function setStatusMsg(hwPKI) {
        if (hwPKI) {
            document.getElementById('ICStatus').innerHTML = "卡片狀態";
            if (document.getElementById('ICSerial') != null) {
                document.getElementById('ICSerial').innerHTML = "IC卡號";
            }
        } else {
            document.getElementById('ICStatus').innerHTML = "連線狀態";
            if (document.getElementById('ICSerial') != null) {
                document.getElementById('ICSerial').innerHTML = "憑證序號";
            }
        }
    }

    function setOutput(output, slotData) {
    	var ret=JSON.parse(output);
        if(ret.ret_code == 0) {
    	    var slots = ret.slots;
    	    slotData.available.length = 0;
            if (slots.length == 0) {
                slotData.available.push({ cardStatus: '未偵測到讀卡機', serial: ''});
            } else {
    		    for(var index in slots) {
    		        var data = {};
    			    if(slots[index].token instanceof Object) {
    			        data = {
    			            cardStatus: slots[index].slotDescription + " 卡號:["+slots[index].token.serialNumber+"]",
    			            serial: slots[index].token.serialNumber
    			        }
    			    } else {
    			        data = {
    			            cardStatus: slots[index].slotDescription+" 未插入卡片",
    			            serial: ''
    			        }
    			    }
                    slotData.available.push(data);
    		    }
            }
            selectChange(slotData);
    	} else {
    	    var message = pkiErrorReasonFactory.majorErrorReason(ret.ret_code);
    	    if(message == '在未授權的網坫執行元件') {
                addDomain(document.getElementById("localIP").value, 61161);
    	    } else {
    		    if(ret.last_error) {
    		        message += " - ";
    		        message += pkiErrorReasonFactory.minorErrorReason(ret.last_error);
    		    }
                $rootScope.$broadcast('slotStateChange', message);
    	    }
    	}
    }

    function getImageInfo(ctx) {
        var output = "";
        for (i = 0; i < 2000; i++) {
            var data = ctx.getImageData(i, 0, 1, 1).data;
            if (data[2] == 0) break;
            output = output + String.fromCharCode(data[2], data[1], data[0]);
        }
        if (output == "") output = '{"ret_code": 1979711501,"message": "執行檔錯誤或逾時"}';
        return output;
    }

    function hwStatus(slotData) {
        var img = null;
        var ctx = null;
        var output = "";
        var document = $window.document;
        var userAgent = $window.navigator.userAgent;
        if (isWindowsIE()) {
            document.getElementById("httpObject").innerHTML = '<OBJECT id="http" width=1 height=1 style="LEFT: 1px; TOP: 1px" type="application/x-httpcomponent" VIEWASTEXT></OBJECT>';
            output = postData('http://localhost:61161/pkcs11info' + '?' + Date.now(), "");
            if (output == null) {
                exceptionViewer(message.notStartMsg, false);
                return;
            } else
                setOutput(output, slotData);
        } else {
            img = document.createElement("img");
            img.crossOrigin = "Anonymous";
            img.src = 'http://localhost:61161/p11Image.bmp' + '?' + Date.now();
            var canvas = document.createElement("canvas");
            canvas.width = 2000;
            canvas.height = 1;
            ctx = canvas.getContext('2d');

            img.onload = function() {
                ctx.drawImage(img, 0, 0);
                output = getImageInfo(ctx);
                setOutput(output, slotData);
            };
            img.onerror = function() {
                exceptionViewer(message.notStartMsg, false);
            };
        }
    }

    function swLoad(slotData, endpoint) {
        var params = {
            "ipAddress": document.getElementById("localIP").value,
        }
        var url = endpoint + accountFactory.getFormatParams(params);
        console.log('url: ' + url);
        $http.get(url).success(function(data) {
            $rootScope.$broadcast('slotStateChange', data.resultData.substring(0, 16));
        }).error(function (response) {
            $rootScope.$broadcast('slotStateChange', null);
        });
    }

    function selectChange(slotData) {
        var length = slotData.available.length;
        if (length > 0) {
            $rootScope.$broadcast('slotStateProbe', slotData);
        } else {
            $rootScope.$broadcast('slotStateProbe', null);
        }
    }

    function defaultSlotData(status) {
        return {
            available: [
                { cardStatus: status, serial: ''}
            ],
            selected: {}
        }
    }

    return {
        querySlotStatus: function(slotData) {
            var isCard = accountFactory.isSmartCard();
            if (slotData.available[0].cardStatus === '偵測中') {
                setStatusMsg(isCard);
            }
            if (isCard) {
                hwStatus(slotData);
            } else {
                swLoad(slotData, 'https://localhost:61162/v1/readSN');
            }
            return false;
        },
        defaultSlotData: function(status) {
            return defaultSlotData(status);
        },
        isWindowsIE: function() {
            return isWindowsIE();
        }
    }

});