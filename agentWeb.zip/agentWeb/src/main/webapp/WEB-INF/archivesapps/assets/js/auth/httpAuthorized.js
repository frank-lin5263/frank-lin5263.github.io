ArchivesApp.factory("httpAuth", function ($http, $cookies) {
    return {
        setCredentials: function (account, password) {
            var encodedData = window.btoa(account+":"+password);
        	var basicAuthToken = 'Basic '+encodedData;
        	console.log('basicAuthToken: ' + basicAuthToken);
            var header = {Authorization: basicAuthToken};
            sessionStorage.setItem('basicHeaderCSM', JSON.stringify(header));
            $http.defaults.headers.common.Authorization = basicAuthToken;
        },
    	setCookies: function (key, value) {
    		$cookies.put(key, value);
        },
    	getCookies: function (key) {
    		return $cookies.get(key);
        },
    	setSession: function (attributeName, attributeValue) {
    		sessionStorage.setItem(attributeName, attributeValue);
        },
    	getSession: function (attributeName) {
    		return sessionStorage.getItem(attributeName);
        },
    	refresh: function(){
    		var authBasicItem = sessionStorage.getItem('basicHeaderCSM');
    		if(authBasicItem) {
    			$http.defaults.headers.common.Authorization = $.parseJSON(authBasicItem).Authorization;
    		}
    	},
        post: function (url, body) {
        	this.refresh();
        	return $http.post(url, body);
        },
        post: function (url, body, headers, data) {
        	this.refresh();
        	return $http.post(url, body, headers, data);
        },
        get: function (url) {
        	this.refresh();
        	return $http.get(url);
        },
        isUserAuthenticated: function () {
    		var authBasicItem = sessionStorage.getItem('authenticatedCSM');
            if (authBasicItem == null) {
                sessionStorage.setItem('authenticatedCSM', false);
            }
            return Boolean(authBasicItem === 'true');
        }
    }
});