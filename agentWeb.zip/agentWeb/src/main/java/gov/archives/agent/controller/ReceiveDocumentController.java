package gov.archives.agent.controller;

import gov.archives.agent.conf.ReceiveStatus;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.domain.vo.DocumentParams;
import gov.archives.agent.domain.vo.ReceiveReceiveVO;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.security.pki.JPKISelfCASecurityUtils;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import gov.archives.jagent.domain.result.ReceiveMSDecryptedAgentResult;
import gov.archives.jagent.domain.result.ReceiveMSRequestAgentResult;
import gov.archives.jagent.domain.result.ReceiveRejectRequestResult;
import gov.archives.jagent.domain.result.ReceiveRejectResult;
import gov.archives.jagent.domain.result.ReceiveRequestResult;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/docExchange/receiveDocument"})
public class ReceiveDocumentController {
    private static final String DECRYPTED_SUCCESS_MSG = "解密處理成功";
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public ReceiveDocumentController() {
    }

    @RequestMapping(
            value = {"/report"},
            method = {RequestMethod.GET}
    )
    public void csvReport(HttpServletResponse response) {
        try {
            List<ReceiveDocumentEntity> list = this.commandInvokerFacade.getReceiveDocumentEntities();
            if (!list.isEmpty()) {
                this.commandInvokerFacade.downloadCsvReport(response, list);
            }
        } catch (Exception var3) {
            throw new ArchivesException(var3.getMessage(), var3.getCause());
        }
    }

    @RequestMapping(
            value = {"/list"},
            method = {RequestMethod.GET}
    )
    public ResponseEntity<RestResponse<List<ReceiveDocumentEntity>>> getReceiveDocumentEntitys() {
        List<ReceiveDocumentEntity> list = this.commandInvokerFacade.getReceiveDocumentEntities();
        RestResponse<List<ReceiveDocumentEntity>> restResponse = ResponseBuilder.createResponseByData(list).setResultCode(0).setResultMessage("").build();
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    @RequestMapping(
            value = {"/receiveDoc"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveRequestResult>> receiveDocument(@RequestBody DocumentParams params) {
        try {
            ReceiveRequestResult receiveRequestResult = this.commandInvokerFacade.startDocReceive(params);
            RestResponse<ReceiveRequestResult> restResponse = ResponseBuilder.createResponseByData(receiveRequestResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/MSRequest"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveMSRequestAgentResult>> receiveMSRequest(@RequestBody DocumentParams params) {
        try {
            ReceiveMSRequestAgentResult receiveRequestResult = (ReceiveMSRequestAgentResult)this.commandInvokerFacade.executeCommand(params, "ReceiveDocument#MSRequestAgent");
            this.commandInvokerFacade.updateReceiveStatus(ReceiveStatus.DOWMLOAD_PROCESS, params.getDocumentId());
            RestResponse<ReceiveMSRequestAgentResult> restResponse = ResponseBuilder.createResponseByData(receiveRequestResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            this.commandInvokerFacade.updateReceiveStatus(ReceiveStatus.CHECK_FAILED, params.getDocumentId());
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/MSDecrypted"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveReceiveVO>> receiveMSDecrypted(@RequestBody DocumentParams params) {
        try {
            ReceiveMSDecryptedAgentResult agentResult = this.commandInvokerFacade.receiveMSDecryptedAgent(params);
            String decryptedResult = agentResult.getDecryptedResult();
            if (decryptedResult.equals("解密處理成功")) {
                return this.receiveReceive(params);
            } else {
                RestResponse<ReceiveReceiveVO> restResponse = ResponseBuilder.createResponseByData(new ReceiveReceiveVO()).setResultCode(-1).setResultMessage(decryptedResult).build();
                return new ResponseEntity(restResponse, HttpStatus.OK);
            }
        } catch (Exception var5) {
            this.commandInvokerFacade.updateReceiveStatus(ReceiveStatus.CHECK_FAILED, params.getDocumentId());
            throw new ArchivesException(var5.getMessage(), var5.getCause());
        }
    }

    @RequestMapping(
            value = {"/receive"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveReceiveVO>> receiveReceive(@RequestBody DocumentParams params) {
        try {
            ReceiveReceiveVO receiveVO = this.commandInvokerFacade.receiveReceive(params);
            RestResponse<ReceiveReceiveVO> restResponse = ResponseBuilder.createResponseByData(receiveVO).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            this.commandInvokerFacade.updateReceiveStatus(ReceiveStatus.CHECK_FAILED, params.getDocumentId());
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/receiveConfirm"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveConfirmResult>> receiveConfirm(@RequestBody DocumentParams params) {
        try {
            ReceiveConfirmResult confirmResult = this.commandInvokerFacade.saveReceiveDocumentEntity(params);
            RestResponse<ReceiveConfirmResult> restResponse = ResponseBuilder.createResponseByData(confirmResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            this.commandInvokerFacade.updateReceiveStatus(ReceiveStatus.CHECK_FAILED, params.getDocumentId());
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/rejectRequest"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<String>> receiveRejectRequest(@RequestBody DocumentParams params) {
        try {
            ReceiveRejectRequestResult result = (ReceiveRejectRequestResult)this.commandInvokerFacade.executeCommand(params, "ReceiveDocument#RejectRequest");
            String rejectHash = JPKISelfCASecurityUtils.getInstance().getB64PaddingHash("SHA-256", result.getRejectHash().getBytes());
            RestResponse<String> restResponse = ResponseBuilder.createResponseByData(rejectHash).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var5) {
            throw new ArchivesException(var5.getMessage(), var5.getCause());
        }
    }

    @RequestMapping(
            value = {"/reject"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<ReceiveRejectResult>> receiveReject(@RequestBody DocumentParams params) {
        try {
            ReceiveRejectResult result = (ReceiveRejectResult)this.commandInvokerFacade.executeCommand(params, "ReceiveDocument#Reject");
            RestResponse<ReceiveRejectResult> restResponse = ResponseBuilder.createResponseByData(result).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }
}
