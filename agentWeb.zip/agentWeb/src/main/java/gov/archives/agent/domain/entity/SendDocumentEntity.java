package gov.archives.agent.domain.entity;

import java.sql.Timestamp;
import org.apache.ibatis.type.Alias;

@Alias("SendDocInfo")
public class SendDocumentEntity extends RootEntity {
    private String exchangeId;
    private String sendOrgId;
    private String sendUnitId;
    private String sendOrgName;
    private String contractInfo;
    private String docWord;
    private String docCatalog;
    private String applicationId;
    private String docSpeed;
    private String subject;
    private String documentDate;
    private String[] appendixFile;
    private String processId;
    private Integer receiverCount;
    private Integer statusCode;
    private Timestamp docDate;
    private Timestamp sendOutTime;

    public SendDocumentEntity() {
    }

    public String getExchangeId() {
        return this.exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public void setSendOrgId(String sendOrgId) {
        this.sendOrgId = sendOrgId;
    }

    public String getSendOrgId() {
        return this.sendOrgId;
    }

    public void setSendUnitId(String sendUnitId) {
        this.sendUnitId = sendUnitId;
    }

    public String getSendUnitId() {
        return this.sendUnitId;
    }

    public String getSendOrgName() {
        return this.sendOrgName;
    }

    public void setSendOrgName(String sendOrgName) {
        this.sendOrgName = sendOrgName;
    }

    public String getContractInfo() {
        return this.contractInfo;
    }

    public void setContractInfo(String contractInfo) {
        this.contractInfo = contractInfo;
    }

    public String getDocWord() {
        return this.docWord;
    }

    public void setDocWord(String docWord) {
        this.docWord = docWord;
    }

    public String getDocCatalog() {
        return this.docCatalog;
    }

    public void setDocCatalog(String docCatalog) {
        this.docCatalog = docCatalog;
    }

    public String getApplicationId() {
        return this.applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getDocSpeed() {
        return this.docSpeed;
    }

    public void setDocSpeed(String docSpeed) {
        this.docSpeed = docSpeed;
    }

    public String getSubject() {
        return this.subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDocumentDate() {
        return this.documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String[] getAppendixFile() {
        return this.appendixFile;
    }

    public void setAppendixFile(String[] appendixFile) {
        this.appendixFile = appendixFile;
    }

    public String getProcessId() {
        return this.processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public Integer getReceiverCount() {
        return this.receiverCount;
    }

    public void setReceiverCount(Integer receiverCount) {
        this.receiverCount = receiverCount;
    }

    public Integer getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Timestamp getDocDate() {
        return this.docDate;
    }

    public void setDocDate(Timestamp docDate) {
        this.docDate = docDate;
    }

    public Timestamp getSendOutTime() {
        return this.sendOutTime;
    }

    public void setSendOutTime(Timestamp sendOutTime) {
        this.sendOutTime = sendOutTime;
    }

    public static final class Builder {
        private String exchangeId;
        private String sendOrgId;
        private String sendUnitId;
        private String sendOrgName;
        private String contractInfo;
        private String docWord;
        private String docCatalog;
        private String applicationId;
        private String docSpeed;
        private String subject;
        private String documentDate;
        private String[] appendixFile;
        private String processId;
        private Integer receiverCount;
        private Integer statusCode;
        private Timestamp docDate;
        private Timestamp sendOutTime;

        private Builder() {
        }

        public static SendDocumentEntity.Builder create() {
            return new SendDocumentEntity.Builder();
        }

        public SendDocumentEntity build() {
            SendDocumentEntity entity = new SendDocumentEntity();
            entity.setExchangeId(this.exchangeId);
            entity.setSendOrgId(this.sendOrgId);
            entity.setSendUnitId(this.sendUnitId);
            entity.setSendOrgName(this.sendOrgName);
            entity.setContractInfo(this.contractInfo);
            entity.setDocWord(this.docWord);
            entity.setDocCatalog(this.docCatalog);
            entity.setApplicationId(this.applicationId);
            entity.setDocSpeed(this.docSpeed);
            entity.setSubject(this.subject);
            entity.setDocumentDate(this.documentDate);
            entity.setAppendixFile(this.appendixFile);
            entity.setProcessId(this.processId);
            entity.setReceiverCount(this.receiverCount);
            entity.setStatusCode(this.statusCode);
            entity.setDocDate(this.docDate);
            entity.setSendOutTime(this.sendOutTime);
            return entity;
        }

        public SendDocumentEntity.Builder setExchangeId(String exchangeId) {
            this.exchangeId = exchangeId;
            return this;
        }

        public SendDocumentEntity.Builder setSendOrgId(String sendOrgId) {
            this.sendOrgId = sendOrgId;
            return this;
        }

        public SendDocumentEntity.Builder setSendUnitId(String sendUnitId) {
            this.sendUnitId = sendUnitId;
            return this;
        }

        public SendDocumentEntity.Builder setSendOrgName(String sendOrgName) {
            this.sendOrgName = sendOrgName;
            return this;
        }

        public SendDocumentEntity.Builder setContractInfo(String contractInfo) {
            this.contractInfo = contractInfo;
            return this;
        }

        public SendDocumentEntity.Builder setDocWord(String docWord) {
            this.docWord = docWord;
            return this;
        }

        public SendDocumentEntity.Builder setDocCatalog(String docCatalog) {
            this.docCatalog = docCatalog;
            return this;
        }

        public SendDocumentEntity.Builder setApplicationId(String applicationId) {
            this.applicationId = applicationId;
            return this;
        }

        public SendDocumentEntity.Builder setDocSpeed(String docSpeed) {
            this.docSpeed = docSpeed;
            return this;
        }

        public SendDocumentEntity.Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public SendDocumentEntity.Builder setDocumentDate(String documentDate) {
            this.documentDate = documentDate;
            return this;
        }

        public SendDocumentEntity.Builder setAppendixFile(String[] appendixFile) {
            this.appendixFile = appendixFile;
            return this;
        }

        public SendDocumentEntity.Builder setProcessId(String processId) {
            this.processId = processId;
            return this;
        }

        public SendDocumentEntity.Builder setReceiverCount(Integer receiverCount) {
            this.receiverCount = receiverCount;
            return this;
        }

        public SendDocumentEntity.Builder setStatusCode(Integer statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        public SendDocumentEntity.Builder setDocDate(Timestamp docDate) {
            this.docDate = docDate;
            return this;
        }

        public SendDocumentEntity.Builder setSendOutTime(Timestamp sendOutTime) {
            this.sendOutTime = sendOutTime;
            return this;
        }
    }
}
