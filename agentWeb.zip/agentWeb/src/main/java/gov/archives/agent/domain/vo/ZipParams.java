package gov.archives.agent.domain.vo;

import java.util.UUID;

public class ZipParams {
    private UUID documentId;
    private String orgUnitId;
    private String fileHash;
    private String decryptedToken;

    public ZipParams() {
    }

    public UUID getDocumentId() {
        return this.documentId;
    }

    public void setDocumentId(UUID documentId) {
        this.documentId = documentId;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getFileHash() {
        return this.fileHash;
    }

    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public String getDecryptedToken() {
        return this.decryptedToken;
    }

    public void setDecryptedToken(String decryptedToken) {
        this.decryptedToken = decryptedToken;
    }

    public static final class Builder {
        private UUID documentId;
        private String orgUnitId;
        private String fileHash;
        private String decryptedToken;

        private Builder() {
        }

        public static ZipParams.Builder create() {
            return new ZipParams.Builder();
        }

        public ZipParams build() {
            ZipParams entity = new ZipParams();
            entity.setDocumentId(this.documentId);
            entity.setOrgUnitId(this.orgUnitId);
            entity.setFileHash(this.fileHash);
            entity.setDecryptedToken(this.decryptedToken);
            return entity;
        }

        public ZipParams.Builder setDocumentId(UUID documentId) {
            this.documentId = documentId;
            return this;
        }

        public ZipParams.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public ZipParams.Builder setFileHash(String fileHash) {
            this.fileHash = fileHash;
            return this;
        }

        public ZipParams.Builder setDecryptedToken(String decryptedToken) {
            this.decryptedToken = decryptedToken;
            return this;
        }
    }
}
