package gov.archives.agent.mapper.query;

import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.domain.vo.ReceivedQuery;
import gov.archives.agent.mapper.QueryRepository;
import java.util.List;
import java.util.UUID;

public interface ReceiveInfoQueryMapper extends QueryRepository<ReceiveDocumentEntity, UUID> {
    List<ReceivedQuery> listAll();
}
