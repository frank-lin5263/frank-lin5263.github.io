package gov.archives.agent.domain.vo;

import org.apache.ibatis.type.Alias;

@Alias("SelectQuery")
public class SelectParams {
    private Integer limit;
    private Integer offset;

    public SelectParams() {
    }

    public Integer getLimit() {
        return this.limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getOffset() {
        return this.offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public static final class Builder {
        private Integer limit;
        private Integer offset;

        private Builder() {
        }

        public static SelectParams.Builder create() {
            return new SelectParams.Builder();
        }

        public SelectParams build() {
            SelectParams entity = new SelectParams();
            entity.setLimit(this.limit);
            entity.setOffset(this.offset);
            return entity;
        }

        public SelectParams.Builder setLimit(Integer limit) {
            this.limit = limit;
            return this;
        }

        public SelectParams.Builder setOffset(Integer offset) {
            this.offset = offset;
            return this;
        }
    }
}

