package gov.archives.agent.conf;

public class TransConfig {
    public static final String DTD_RESOURCE_FOLDER = "dtd";
    public static final String TEMP_FOLDER = "tmp";
    public static final String TEMP_FONT = "font";
    public static final String TEMP_HTML_NAME = "trans.html";
    public static final String SUFFIX_PDF = ".pdf";
    public static final String SUFFIX_DI = ".di";
    public static final String SUFFIX_XSL = ".xsl";
    public static final String SUFFIX_DTD = ".dtd";
    public static final String FILE_KAIU_TTF = "kaiu.ttf";
    public static final String FILE_EXCHANGE_IMAGE = "ExchangeH.png";

    public TransConfig() {
    }
}
