package gov.archives.agent.domain.vo;

import gov.archives.jagent.domain.result.InitConfirmResult;
import gov.archives.jagent.domain.vo.SignedFile;

public class DocumentParams {
    private String orgUnitId;
    private String decryptedToken;
    private String signedToken;
    private String documentId;
    private InitConfirmResult confirmResult;
    private SignedFile[] signedFiles;
    private String[] processIds;
    private String encryptedPsw;
    private String confirmSignature;
    private String rejectMsg;
    private String fileHash;

    public DocumentParams() {
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getDecryptedToken() {
        return this.decryptedToken;
    }

    public void setDecryptedToken(String decryptedToken) {
        this.decryptedToken = decryptedToken;
    }

    public String getSignedToken() {
        return this.signedToken;
    }

    public void setSignedToken(String signedToken) {
        this.signedToken = signedToken;
    }

    public String getDocumentId() {
        return this.documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public InitConfirmResult getConfirmResult() {
        return this.confirmResult;
    }

    public void setConfirmResult(InitConfirmResult confirmResult) {
        this.confirmResult = confirmResult;
    }

    public SignedFile[] getSignedFiles() {
        return this.signedFiles;
    }

    public void setSignedFiles(SignedFile[] signedFiles) {
        this.signedFiles = signedFiles;
    }

    public String[] getProcessIds() {
        return this.processIds;
    }

    public void setProcessIds(String[] processIds) {
        this.processIds = processIds;
    }

    public String getEncryptedPsw() {
        return this.encryptedPsw;
    }

    public void setEncryptedPsw(String encryptedPsw) {
        this.encryptedPsw = encryptedPsw;
    }

    public String getConfirmSignature() {
        return this.confirmSignature;
    }

    public void setConfirmSignature(String confirmSignature) {
        this.confirmSignature = confirmSignature;
    }

    public String getRejectMsg() {
        return this.rejectMsg;
    }

    public void setRejectMsg(String rejectMsg) {
        this.rejectMsg = rejectMsg;
    }

    public String getFileHash() {
        return this.fileHash;
    }

    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public static final class Builder {
        private String orgUnitId;
        private String decryptedToken;
        private String signedToken;
        private String documentId;
        private InitConfirmResult confirmResult;
        private SignedFile[] signedFiles;
        private String[] processIds;
        private String encryptedPsw;
        private String confirmSignature;
        private String rejectMsg;
        private String fileHash;

        private Builder() {
        }

        public static DocumentParams.Builder create() {
            return new DocumentParams.Builder();
        }

        public DocumentParams build() {
            DocumentParams params = new DocumentParams();
            params.setOrgUnitId(this.orgUnitId);
            params.setDecryptedToken(this.decryptedToken);
            params.setSignedToken(this.signedToken);
            params.setDocumentId(this.documentId);
            params.setConfirmResult(this.confirmResult);
            params.setSignedFiles(this.signedFiles);
            params.setProcessIds(this.processIds);
            params.setEncryptedPsw(this.encryptedPsw);
            params.setConfirmSignature(this.confirmSignature);
            params.setRejectMsg(this.rejectMsg);
            params.setFileHash(this.fileHash);
            return params;
        }

        public DocumentParams.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public DocumentParams.Builder setDecryptedToken(String decryptedToken) {
            this.decryptedToken = decryptedToken;
            return this;
        }

        public DocumentParams.Builder setSignedToken(String signedToken) {
            this.signedToken = signedToken;
            return this;
        }

        public DocumentParams.Builder setDocumentId(String documentId) {
            this.documentId = documentId;
            return this;
        }

        public DocumentParams.Builder setConfirmResult(InitConfirmResult confirmResult) {
            this.confirmResult = confirmResult;
            return this;
        }

        public DocumentParams.Builder setSignedFiles(SignedFile[] signedFiles) {
            this.signedFiles = signedFiles;
            return this;
        }

        public DocumentParams.Builder setProcessIds(String[] processIds) {
            this.processIds = processIds;
            return this;
        }

        public DocumentParams.Builder setEncryptedPsw(String encryptedPsw) {
            this.encryptedPsw = encryptedPsw;
            return this;
        }

        public DocumentParams.Builder setConfirmSignature(String confirmSignature) {
            this.confirmSignature = confirmSignature;
            return this;
        }

        public DocumentParams.Builder setRejectMsg(String rejectMsg) {
            this.rejectMsg = rejectMsg;
            return this;
        }

        public DocumentParams.Builder setFileHash(String fileHash) {
            this.fileHash = fileHash;
            return this;
        }
    }
}

