package gov.archives.agent.controller;

import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.exception.ArchivesException;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/officialFolder/sendQuery"})
public class SendQueryDetailController {
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public SendQueryDetailController() {
    }

    @RequestMapping(
            value = {"/download"},
            method = {RequestMethod.GET}
    )
    public void downloadAllZip(@RequestParam("documentId") String documentId, HttpServletResponse response) {
        try {
            this.commandInvokerFacade.downloadAllZip(response, documentId);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/filename"},
            method = {RequestMethod.GET}
    )
    public void downloadFileName(@RequestParam("documentId") String documentId, @RequestParam("fileName") String fileName, HttpServletResponse response) {
        try {
            this.commandInvokerFacade.downloadFileName(documentId, fileName, response);
        } catch (Exception var5) {
            throw new ArchivesException(var5.getMessage(), var5.getCause());
        }
    }

    @RequestMapping(
            value = {"/preview"},
            method = {RequestMethod.GET}
    )
    public void preViewSendDi(@RequestParam("documentId") String documentId, HttpServletResponse response) {
        try {
            this.commandInvokerFacade.transSendDi2HTML(documentId, response);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }
}
