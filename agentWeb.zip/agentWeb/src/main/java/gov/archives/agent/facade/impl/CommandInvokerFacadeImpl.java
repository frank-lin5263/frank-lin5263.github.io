package gov.archives.agent.facade.impl;

import gov.archives.agent.Utils.CompressUtils;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.conf.ReceiveStatus;
import gov.archives.agent.conf.SendStatus;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.vo.DocumentParams;
import gov.archives.agent.domain.vo.ReceiveReceiveVO;
import gov.archives.agent.domain.vo.ReceivedQuery;
import gov.archives.agent.domain.vo.SendQuery;
import gov.archives.agent.domain.vo.SignHashPackage;
import gov.archives.agent.domain.vo.ZipParams;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.agent.service.DownloadsService;
import gov.archives.agent.service.ReceiveInfoService;
import gov.archives.agent.service.SendInfoService;
import gov.archives.agent.service.TransDi2HTMLService;
import gov.archives.agent.service.impl.ExchangeCommandImpl;
import gov.archives.agent.service.impl.ExportCsvFactory;
import gov.archives.agent.service.impl.InitExchangeCommandImpl;
import gov.archives.agent.service.impl.ReceiveDiServiceImpl;
import gov.archives.agent.service.impl.ReceiveExportCsvFileImpl;
import gov.archives.agent.service.impl.SendExportCsvFileImpl;
import gov.archives.core.conf.AgentConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.security.pki.JPKISelfCASecurityUtils;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.util.UserInfoUtil;
import gov.archives.jagent.domain.parameter.InitConfirmParameter;
import gov.archives.jagent.domain.parameter.ReceiveConfirmParameter;
import gov.archives.jagent.domain.parameter.ReceiveMSDecryptedAgentParameter;
import gov.archives.jagent.domain.parameter.ReceiveMSRequestAgentParameter;
import gov.archives.jagent.domain.parameter.ReceiveReceiveParameter;
import gov.archives.jagent.domain.parameter.ReceiveRejectParameter;
import gov.archives.jagent.domain.parameter.ReceiveRejectRequestParameter;
import gov.archives.jagent.domain.parameter.ReceiveRequestParameter;
import gov.archives.jagent.domain.parameter.SendCheckListParameter;
import gov.archives.jagent.domain.parameter.SendMSEncryptedAgentParameter;
import gov.archives.jagent.domain.parameter.SendMSRequestAgentParameter;
import gov.archives.jagent.domain.parameter.SendOutParameter;
import gov.archives.jagent.domain.parameter.SendProcessParameter;
import gov.archives.jagent.domain.parameter.SendQueryParameter;
import gov.archives.jagent.domain.parameter.SignInParameter;
import gov.archives.jagent.domain.parameter.SignInParameter.Builder;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.InitConfirmResult;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import gov.archives.jagent.domain.result.ReceiveMSDecryptedAgentResult;
import gov.archives.jagent.domain.result.ReceiveReceiveResult;
import gov.archives.jagent.domain.result.ReceiveRequestResult;
import gov.archives.jagent.domain.result.SendMSRequestAgentResult;
import gov.archives.jagent.domain.result.SendOutResult;
import gov.archives.jagent.domain.result.SendProcessResult;
import gov.archives.jagent.domain.result.SignInResult;
import gov.archives.jagent.domain.vo.ReceivedDocument;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.io.FileUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.iii.security.hash.HashGenerator;
import org.iii.security.hash.HashGenerators;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Service
public class CommandInvokerFacadeImpl implements CommandInvokerFacade {
    private static final String KEY_ZIP_FILE = "key.zip";
    private static final String KEY_TXT_FILE = "key.txt";
    @Autowired
    private InitExchangeCommandImpl initExchangeCommand;
    @Autowired
    private ExchangeCommandImpl exchangeCommand;
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    @Autowired
    private ReceiveDiServiceImpl receiveDiService;
    @Autowired
    private SessionManageService sessionManageService;
    @Autowired
    private DownloadsService downloadsService;
    @Autowired
    private SendInfoService sendInfoService;
    @Autowired
    private ReceiveInfoService receiveInfoService;
    @Autowired
    private TransDi2HTMLService di2HTMLService;

    public CommandInvokerFacadeImpl() {
    }

    @Transactional(
            value = "JmsTransactionManager",
            propagation = Propagation.REQUIRED,
            rollbackFor = {Exception.class}
    )
    public String singInCommand(String orgUnitId, String cardNumber) {
        PreconditionUtils.checkArguments(new Object[]{orgUnitId, cardNumber});
        SignInParameter params = Builder.create().setCenterCode(AgentConf.getCenterID()).setOrgUnitId(orgUnitId).setCardNum(cardNumber).build();
        CommandResult<SignInResult> commandResult = this.initExchangeCommand.execute(params, "InitExchange#SignIn", (InitConfirmResult)null, (String)null);
        return JPKISelfCASecurityUtils.getInstance().getB64PaddingHash("SHA-256", ((SignInResult)commandResult.getResult()).getSkeyHash().getBytes());
    }

    @Transactional(
            value = "JmsTransactionManager",
            propagation = Propagation.REQUIRED,
            rollbackFor = {Exception.class}
    )
    public InitConfirmResult confirmCommand(SignHashPackage hashPackage, String orgUnitId, String cardNumber) {
        PreconditionUtils.checkArguments(new Object[]{hashPackage, orgUnitId, cardNumber});
        InitConfirmParameter params = InitConfirmParameter.getInstanceByField(orgUnitId, cardNumber, hashPackage.getSignature(), hashPackage.getSigCert(), hashPackage.getEncCert());
        CommandResult<InitConfirmResult> commandResult = this.initExchangeCommand.execute(params, "InitExchange#Confirm", (InitConfirmResult)null, (String)null);
        return (InitConfirmResult)commandResult.getResult();
    }

    public String getSignToken(String b64DecryptedToken) {
        String decryptedToken = new String(DatatypeConverter.parseBase64Binary(b64DecryptedToken));
        String token = HashGenerators.getInstanceByAlgorithm("SHA-256").getHashByString(decryptedToken);
        return JPKISelfCASecurityUtils.getInstance().getB64PaddingHash("SHA-256", token.getBytes());
    }

    public ReceiveRequestResult startDocReceive(DocumentParams params) {
        ReceiveRequestResult result = (ReceiveRequestResult)this.executeCommand(params, "ReceiveDocument#Request");
        ReceivedDocument[] var3 = result.getReceivedDocs();
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            ReceivedDocument document = var3[var5];
            this.receiveInfoService.saveReceiveInfo(document.getDocumentId());
        }

        return result;
    }

    @Transactional(
            value = "JmsTransactionManager",
            propagation = Propagation.REQUIRED,
            rollbackFor = {Exception.class}
    )
    public Object executeCommand(DocumentParams params, String commandName) {
        Object parameters = null;
        if (commandName.equals("SendDocument#Process")) {
            parameters = SendProcessParameter.getInstanceByField(params.getFileHash());
        } else {
            UUID documentId;
            if (commandName.equals("SendDocument#MSRequestAgent")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = SendMSRequestAgentParameter.getInstanceByField(documentId);
            } else if (commandName.equals("SendDocument#MSEncryptedAgent")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = SendMSEncryptedAgentParameter.getInstanceByField(documentId, params.getSignedFiles());
            } else if (commandName.equals("SendDocument#SendOut")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = SendOutParameter.getInstanceByField(documentId, params.getSignedFiles());
            } else if (commandName.equals("SendDocument#Query")) {
                parameters = SendQueryParameter.getInstanceByField(params.getProcessIds());
            } else if (commandName.equals("SendDocument#CheckList")) {
                SendCheckListParameter parameter = new SendCheckListParameter();
                String date = (new SimpleDateFormat("yyy-MM-dd")).format(Calendar.getInstance().getTime());
                System.out.println(date);
                parameter.setDate(date);
                parameters = parameter;
            } else if (commandName.equals("ReceiveDocument#Request")) {
                parameters = new ReceiveRequestParameter();
            } else if (commandName.equals("ReceiveDocument#MSRequestAgent")) {
                documentId = UUID.fromString(params.getDocumentId());
                this.documentAccessor.addPullFileQueue(documentId);
                parameters = ReceiveMSRequestAgentParameter.getInstanceByField(documentId);
            } else if (commandName.equals("ReceiveDocument#MSDecryptedAgent")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = ReceiveMSDecryptedAgentParameter.getInstanceByField(documentId, params.getFileHash());
            } else if (commandName.equals("ReceiveDocument#Receive")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = ReceiveReceiveParameter.getInstanceByField(documentId);
            } else if (commandName.equals("ReceiveDocument#Confirm")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = ReceiveConfirmParameter.getInstanceByField(documentId, params.getConfirmSignature());
            } else if (commandName.equals("ReceiveDocument#RejectRequest")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = ReceiveRejectRequestParameter.getInstanceByField(documentId, params.getRejectMsg());
            } else if (commandName.equals("ReceiveDocument#Reject")) {
                documentId = UUID.fromString(params.getDocumentId());
                parameters = ReceiveRejectParameter.getInstanceByField(documentId, params.getConfirmSignature());
            }
        }

        CommandResult<?> result = this.exchangeCommand.execute(parameters, commandName, params.getConfirmResult(), params.getSignedToken());
        return result.getName().equals("SendDocument#MSEncryptedAgent") ? this.exchangeCommand.buildMSAgentResult(result) : result.getResult();
    }

    public synchronized SendOutResult saveSendOutResult(DocumentParams params) {
        SendOutResult sendOutResult = (SendOutResult)this.executeCommand(params, "SendDocument#SendOut");
        this.sendInfoService.update(sendOutResult);
        return sendOutResult;
    }

    private File prepareKeyTxt(String b64Psw) throws IOException {
        String account = UserInfoUtil.getCurrentAccount();
        File keyTxtFile = this.documentAccessor.getTempPath("TempFiles").resolve(account).resolve("key.txt").toFile();
        String rawPsw = new String(DatatypeConverter.parseBase64Binary(b64Psw));
        FileUtils.writeStringToFile(keyTxtFile, rawPsw, "UTF-8");
        return keyTxtFile;
    }

    public synchronized ReceiveMSDecryptedAgentResult receiveMSDecryptedAgent(DocumentParams params) {
        File keyTxt = null;
        File keyZip = null;

        ReceiveMSDecryptedAgentResult var5;
        try {
            keyTxt = this.prepareKeyTxt(params.getEncryptedPsw());
            keyZip = this.prepareKeyZip(keyTxt, params.getDecryptedToken());
            this.exchangeCommand.sendFile(keyZip);
            HashGenerator hashGenerator = HashGenerators.getInstanceByAlgorithm("SHA-256");
            params.setFileHash(hashGenerator.getHashByBytes(FileUtils.readFileToByteArray(keyZip)));
            var5 = (ReceiveMSDecryptedAgentResult)this.executeCommand(params, "ReceiveDocument#MSDecryptedAgent");
        } catch (IOException var9) {
            throw new ArchivesException(var9.getMessage(), var9.getCause());
        } finally {
            IOUtils.deleteFile(keyTxt);
            IOUtils.deleteFile(keyZip);
        }

        return var5;
    }

    public ReceiveReceiveVO receiveReceive(DocumentParams params) {
        ReceiveReceiveResult receiveResult = (ReceiveReceiveResult)this.executeCommand(params, "ReceiveDocument#Receive");
        String b64ConfirmHash = JPKISelfCASecurityUtils.getInstance().getB64PaddingHash("SHA-256", receiveResult.getConfirmHash().getBytes());
        ReceiveReceiveVO receiveVO = new ReceiveReceiveVO();
        receiveVO.setB64ConfirmHash(b64ConfirmHash);
        receiveVO.setReceiveResult(receiveResult);
        return receiveVO;
    }

    public SendMSRequestAgentResult startSendDocuments(MultipartHttpServletRequest request) {
        File sendZip = this.exchangeCommand.sendDocumentFile(request);
        DocumentParams params = this.buildDocumentParams(request);
        SendProcessResult processResult = (SendProcessResult)this.executeCommand(params, "SendDocument#Process");
        params.setDocumentId(processResult.getDocumentId().toString());
        ZipParams zipParams = gov.archives.agent.domain.vo.ZipParams.Builder.create().setDocumentId(UUID.fromString(params.getDocumentId())).setOrgUnitId(params.getOrgUnitId()).setFileHash(params.getFileHash()).setDecryptedToken(params.getDecryptedToken()).build();
        SendDocumentEntity entity = this.sendInfoService.saveSendProcess(zipParams, sendZip);
        SendMSRequestAgentResult agentResult = (SendMSRequestAgentResult)this.executeCommand(params, "SendDocument#MSRequestAgent");
        entity.setStatusCode(SendStatus.POST_CHECK);
        this.sendInfoService.update(entity);
        return this.exchangeCommand.buildMSRequestAgentResult(agentResult);
    }

    private DocumentParams buildDocumentParams(MultipartHttpServletRequest request) {
        String orgUnitId = request.getParameter("orgUnitId");
        String decryptedToken = request.getParameter("decryptedToken");
        String signedToken = request.getParameter("signedToken");
        String sessionId = request.getParameter("sessionId");
        String expireTime = request.getParameter("expireTime");
        String fileHash = (String)request.getAttribute("fileHash");
        PreconditionUtils.checkArguments(new Object[]{decryptedToken, signedToken, sessionId, expireTime, fileHash});
        InitConfirmResult confirmResult = new InitConfirmResult();
        confirmResult.setSessionId(sessionId);
        confirmResult.setExpireTime(expireTime);
        return gov.archives.agent.domain.vo.DocumentParams.Builder.create().setOrgUnitId(orgUnitId).setDecryptedToken(decryptedToken).setSignedToken(signedToken).setConfirmResult(confirmResult).setFileHash(fileHash).build();
    }

    private File prepareKeyZip(File keyTxt, String b64DecryptedToken) {
        String account = UserInfoUtil.getCurrentAccount();
        File keyZip = this.documentAccessor.getTempPath("TempFiles").resolve(account).resolve("key.zip").toFile();
        String decryptedToken = new String(DatatypeConverter.parseBase64Binary(b64DecryptedToken));
        CompressUtils.compressFileToZip(keyTxt, keyZip, decryptedToken);
        return keyZip;
    }

    public ReceiveConfirmResult saveReceiveDocumentEntity(DocumentParams params) {
        ReceiveConfirmResult confirmResult = (ReceiveConfirmResult)this.executeCommand(params, "ReceiveDocument#Confirm");
        String decryptedToken = new String(DatatypeConverter.parseBase64Binary(params.getDecryptedToken()));
        this.receiveInfoService.update(confirmResult, decryptedToken);
        return confirmResult;
    }

    public List<SendDocumentEntity> getSendDocumentEntities() {
        return this.sendInfoService.listAll();
    }

    public List<ReceiveDocumentEntity> getReceiveDocumentEntities() {
        return this.receiveInfoService.listAll();
    }

    public List<SendQuery> getSendQueryEntities() {
        List<SendQuery> list = new ArrayList();
        List<SendDocumentEntity> sendList = this.getSendDocumentEntities();
        Iterator var3 = sendList.iterator();

        while(var3.hasNext()) {
            SendDocumentEntity e = (SendDocumentEntity)var3.next();
            SendQuery queryEntity = gov.archives.agent.domain.vo.SendQuery.Builder.create().setMark(false).setPrint(true).setResend(false).setDocumentId(e.getDocumentId().toString()).setExchangeId(e.getExchangeId()).setOrgUnitId(e.getSendOrgId() + e.getSendUnitId()).setOrgUnitName(e.getSendOrgName()).setSendStatus(SendStatus.findByCode(e.getStatusCode())).setWord(e.getDocWord()).setArchiveCatalog(e.getDocCatalog()).setArchiveId(e.getApplicationId()).setArchiveSpeed(e.getDocSpeed()).setContractInfo(e.getContractInfo()).setSubject(e.getSubject()).setAppendixFileName(e.getAppendixFile()).setTotal(e.getReceiverCount()).setConfirm(0).setAttach(e.getAppendixFile().length).setSendDatTime(e.getSendOutTime().toString()).build();
            list.add(queryEntity);
        }

        return list;
    }

    public List<ReceivedQuery> getReceivedQueryEntities(DocumentParams params) {
        List<ReceivedQuery> queryEntityList = new ArrayList();
        List<ReceiveDocumentEntity> entities = this.getReceiveDocumentEntities();
        entities.forEach((e) -> {
            ReceivedQuery entity = gov.archives.agent.domain.vo.ReceivedQuery.Builder.create().setMark(true).setPrint(true).setReceiveStatus(ReceiveStatus.findByCode(e.getStatusCode())).setSendOrgName(e.getSendOrgId() + e.getSendUnitId() + " " + e.getSendOrgName()).setContractInfo(e.getContractInfo()).setArchiveWord(e.getDocWord()).setArchiveId(e.getApplicationId()).setArchiveSpeed(e.getDocSpeed()).setArchiveCatalog(e.getDocCatalog()).setSubject(e.getDocSubject()).setAttach(e.getAppendixFile().length).setConfirmOrReject(e.getUserConfirmTime().toString()).setAppendixFileName(e.getAppendixFile()).build();
            entity.setDocumentId(e.getDocumentId());
            queryEntityList.add(entity);
        });
        return queryEntityList;
    }

    public void updateReceiveStatus(Integer statusCode, String documentId) {
        this.receiveInfoService.updateStatusCode(statusCode, documentId);
    }

    public void setSendEntityStatus(Integer statusCode, String documentId) {
        this.sendInfoService.updateStatusCode(statusCode, documentId);
    }

    public void downloadCsvReport(HttpServletResponse response, List<?> list) {
        String account = UserInfoUtil.getCurrentAccount();
        Class<?> entityClass = list.get(0).getClass();
        String className = entityClass.getName();
        File csvFile = null;
        ExportCsvFactory csvFactory = new ExportCsvFactory();
        if (className.endsWith("SendDocumentEntity")) {
            csvFile = ((SendExportCsvFileImpl)csvFactory.createCsvReportFactory(SendExportCsvFileImpl.class)).exportCsvFile(account, list, entityClass);
        } else if (className.endsWith("ReceiveDocumentEntity")) {
            csvFile = ((ReceiveExportCsvFileImpl)csvFactory.createCsvReportFactory(ReceiveExportCsvFileImpl.class)).exportCsvFile(account, list, entityClass);
        }

        this.downloadsService.responseDownloadingFile(csvFile, response, ".csv", "text/csv");
        FileUtils.deleteQuietly(csvFile);
    }

    public void downloadAllZip(HttpServletResponse response, String documentId) {
        File file = this.downloadsService.buildAllDownload(documentId);
        this.downloadsService.responseDownloadingFile(file, response, ".zip", "application/zip");
    }

    public void downloadFileName(String documentId, String fileName, HttpServletResponse response) {
        File file = this.downloadsService.getUncompressFile(fileName, documentId);
        this.downloadsService.responseDownloadingFile(file, response, ".zip", "application/zip");
    }

    public void transSendDi2HTML(String documentId, HttpServletResponse response) {
        String account = UserInfoUtil.getCurrentAccount();
        File diFile = this.documentAccessor.uncompressSendZipFile(account, UUID.fromString(documentId));
        File htmlFile = this.di2HTMLService.transDi2HTML(diFile, account + "SendTemp.html");
        System.out.println("html: " + htmlFile.getAbsolutePath());
        this.downloadsService.responseDownloadingFile(htmlFile, response, ".html", "text/html");
    }

    public void transReceiveDi2HTML(HttpServletResponse response, String documentId, String decryptedToken) {
        String account = UserInfoUtil.getCurrentAccount();
        File diFile = this.downloadsService.getReceiveDi(documentId, decryptedToken);
        File htmlFile = this.di2HTMLService.transDi2HTML(diFile, account + "ReceiveTemp.html");
        System.out.println("html: " + htmlFile.getAbsolutePath());
        this.downloadsService.responseDownloadingFile(htmlFile, response, ".html", "text/html");
    }
}
