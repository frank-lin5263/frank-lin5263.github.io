package gov.archives.agent.service.impl;

import gov.archives.agent.service.ExportCsvFileApi;
import gov.archives.core.exception.ArchivesException;

public class ExportCsvFactory extends CsvExportCreator {
    public ExportCsvFactory() {
    }

    public <T extends ExportCsvFileApi> T createCsvReportFactory(Class<T> clz) {
        try {
            ExportCsvFileApi csvFileApi = (ExportCsvFileApi)Class.forName(clz.getName()).newInstance();
            return (T) csvFileApi;
        } catch (IllegalAccessException | ClassNotFoundException | InstantiationException var3) {
            throw new ArchivesException(var3.getMessage(), var3.getCause());
        }
    }
}
