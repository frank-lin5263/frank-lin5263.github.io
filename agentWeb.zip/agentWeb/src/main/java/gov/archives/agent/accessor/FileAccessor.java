package gov.archives.agent.accessor;

import java.io.File;
import java.util.Map;

public interface FileAccessor {
    Map<String, byte[]> uncompressZipFile(File var1);

    Map<String, byte[]> uncompressZipFile(File var1, String var2);
}
