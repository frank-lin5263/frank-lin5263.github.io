package gov.archives.agent.messaging;

import com.fasterxml.jackson.databind.JsonNode;
import gov.archives.common.json.JsonUtils;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.InitConfirmResult;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import gov.archives.jagent.domain.result.ReceiveMSDecryptedAgentResult;
import gov.archives.jagent.domain.result.ReceiveMSRequestAgentResult;
import gov.archives.jagent.domain.result.ReceiveReceiveResult;
import gov.archives.jagent.domain.result.ReceiveRejectRequestResult;
import gov.archives.jagent.domain.result.ReceiveRejectResult;
import gov.archives.jagent.domain.result.ReceiveRequestResult;
import gov.archives.jagent.domain.result.SendCheckListResult;
import gov.archives.jagent.domain.result.SendMSEncryptedAgentResult;
import gov.archives.jagent.domain.result.SendMSRequestAgentResult;
import gov.archives.jagent.domain.result.SendOutResult;
import gov.archives.jagent.domain.result.SendProcessResult;
import gov.archives.jagent.domain.result.SendQueryResult;
import gov.archives.jagent.domain.result.SignInResult;
import gov.archives.jagent.domain.result.SystemLogoutResult;
import gov.archives.jagent.domain.result.CommandResult.Builder;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.security.authentication.AuthenticationServiceException;

public class CommandMessageConverter implements MessageConverter {
    private static final Logger log = LoggerFactory.getLogger(CommandMessageConverter.class);
    private Map<String, Class<?>> resultMap = new HashMap();

    public CommandMessageConverter() {
        this.resultMap.put("InitExchange#SignIn", SignInResult.class);
        this.resultMap.put("InitExchange#Confirm", InitConfirmResult.class);
        this.resultMap.put("SendDocument#Process", SendProcessResult.class);
        this.resultMap.put("SendDocument#MSRequestAgent", SendMSRequestAgentResult.class);
        this.resultMap.put("SendDocument#MSEncryptedAgent", SendMSEncryptedAgentResult.class);
        this.resultMap.put("SendDocument#SendOut", SendOutResult.class);
        this.resultMap.put("SendDocument#Query", SendQueryResult.class);
        this.resultMap.put("SendDocument#CheckList", SendCheckListResult.class);
        this.resultMap.put("ReceiveDocument#Request", ReceiveRequestResult.class);
        this.resultMap.put("ReceiveDocument#MSRequestAgent", ReceiveMSRequestAgentResult.class);
        this.resultMap.put("ReceiveDocument#MSDecryptedAgent", ReceiveMSDecryptedAgentResult.class);
        this.resultMap.put("ReceiveDocument#Receive", ReceiveReceiveResult.class);
        this.resultMap.put("ReceiveDocument#Confirm", ReceiveConfirmResult.class);
        this.resultMap.put("ReceiveDocument#RejectRequest", ReceiveRejectRequestResult.class);
        this.resultMap.put("ReceiveDocument#Reject", ReceiveRejectResult.class);
        this.resultMap.put("System#Logout", SystemLogoutResult.class);
    }

    public Message toMessage(Object object, Session session) throws JMSException, MessageConversionException {
        String jsonText = JsonUtils.getJsonTextByObject(object);
        TextMessage message = session.createTextMessage(jsonText);
        return message;
    }

    private <T> CommandResult<?> receiveMessage(String name, JsonNode jsonNode, Class<T> resultType) {
        JsonNode resultNode = jsonNode.get("result");
        if (resultNode == null) {
            JsonNode errorNode = jsonNode.get("error");
            Map<String, String> errorMap = (Map)JsonUtils.getObjectByJsonTree(errorNode.get(0), HashMap.class);
            String errorCode = errorMap.get("errorCode");
            String errorMessage = errorMap.get("errorMessage");
            throw new AuthenticationServiceException(errorCode, new Throwable(errorMessage));
        } else {
            String id = JsonUtils.getObjectByJsonTree(jsonNode.get("id"), String.class);
            T resultData = JsonUtils.getObjectByJsonTree(resultNode, resultType);
            CommandResult result = Builder.createResultByParameter(resultData).setId(UUID.fromString(id)).setName(name).build();
            return result;
        }
    }

    public Object fromMessage(Message message) throws JMSException, MessageConversionException {
        TextMessage textMessage = (TextMessage)message;
        JsonNode jsonNode = JsonUtils.getJsonTreeByJsonText(textMessage.getText());
        String name = JsonUtils.getObjectByJsonTree(jsonNode.get("name"), String.class);
        return this.receiveMessage(name, jsonNode, (Class)this.resultMap.get(name));
    }
}
