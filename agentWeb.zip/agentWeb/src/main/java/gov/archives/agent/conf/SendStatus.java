package gov.archives.agent.conf;

import java.util.HashMap;
import java.util.Map;

public class SendStatus {
    private static Map<Integer, String> sendStatus = new HashMap();
    public static final Integer START = 0;
    public static final String DOC_START = "公文發送開始";
    public static final Integer POST_CHECK = 1;
    public static final String DOC_POST_CHECK = "發文前置檢驗中";
    public static final Integer CHECKED_SIGN = 2;
    public static final String DOC_CHECKED_SIGN = "發文檢驗完成,簽章中";
    public static final Integer SIGN_OK = 3;
    public static final String DOC_SIGN_OK = "簽章完成,傳送公文...";
    public static final Integer CHECK_FAILED = -1;
    public static final String DOC_CHECK_FAILED = "發文檢驗失敗";
    public static final Integer SIGN_FAILED = -2;
    public static final String DOC_SIGN_FAILED = "公文簽章失敗";
    public static final Integer FAILED = -3;
    public static final String DOC_FAILED = "傳送失敗";
    public static final Integer ERROR = -4;
    public static final String DOC_ERROR = "發文異常";
    public static final Integer PARTIAL_CONFIRM = 10;
    public static final String DOC_PARTIAL_CONFIRM = "部分確認";
    public static final Integer ALL_CONFIRM = 20;
    public static final String DOC_ALL_CONFIRM = "全部確認";

    public SendStatus() {
    }

    public static String findByCode(Integer statusCode) {
        return sendStatus.containsKey(statusCode) ? (String)sendStatus.get(statusCode) : "未定義訊息";
    }

    static {
        sendStatus.put(START, "公文發送開始");
        sendStatus.put(POST_CHECK, "發文前置檢驗中");
        sendStatus.put(CHECKED_SIGN, "發文檢驗完成,簽章中");
        sendStatus.put(SIGN_OK, "簽章完成,傳送公文...");
        sendStatus.put(CHECK_FAILED, "發文檢驗失敗");
        sendStatus.put(SIGN_FAILED, "公文簽章失敗");
        sendStatus.put(FAILED, "傳送失敗");
        sendStatus.put(ERROR, "發文異常");
        sendStatus.put(PARTIAL_CONFIRM, "部分確認");
        sendStatus.put(ALL_CONFIRM, "全部確認");
    }
}
