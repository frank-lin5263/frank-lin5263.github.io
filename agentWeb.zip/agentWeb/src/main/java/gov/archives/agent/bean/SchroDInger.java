package gov.archives.agent.bean;

import gov.archives.agent.Utils.Di2PdfUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.apache.commons.io.FileUtils;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.IOUtils;
import org.iii.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchroDInger {
    private static final Logger log = LoggerFactory.getLogger(SchroDInger.class);
    private static final String XML_ENTITY = "!ENTITY";
    private static final String XML_SYSTEM = "SYSTEM";
    private static final String REGEX_ENTITY_TAG = "((\"|\\s)%1$s)|(%1$s(\"|\\s))";
    private static final String REGEX_ENTITY_NDATA = "NDATA.+[^>]";
    private static final String REGEX_SPLIT = "(?=<)";
    private static final String TEMP_DI_NAME = "trans.di";
    private String xslYear;
    private String xslName;
    private List<String> originContent;
    private List<String> entityKeys;
    private List<String> formatContent;

    private SchroDInger(File diFile) throws IOException {
        this.originContent = this.transXMLToStringList(diFile);
        this.entityKeys = this.filterEntityKeys();
        this.xslName = this.filterXslName();
        this.xslYear = this.filterXslYear(this.xslName);
        this.formatContent = this.format();
    }

    public static SchroDInger build(File diFile) {
        try {
            return new SchroDInger(diFile);
        } catch (IOException var2) {
            log.error(StringUtils.stackTraceFromException(var2));
            throw new ApplicationException(var2);
        }
    }

    public String getXslName() {
        return this.xslName;
    }

    public String getXslYear() {
        return this.xslYear;
    }

    public List<String> getOriginContent() {
        return this.originContent;
    }

    public List<String> getEntityKeys() {
        return this.entityKeys;
    }

    public List<String> getFormatContent() {
        return this.formatContent;
    }

    public File getFormatDiFile() throws IOException {
        try {
            File tempDiFile = Di2PdfUtils.createTempFile("trans.di");
            FileUtils.writeLines(tempDiFile, this.formatContent);
            return tempDiFile;
        } catch (IOException var2) {
            throw new IOException("Format String -> Di 時發生問題", var2);
        }
    }

    private List<String> transXMLToStringList(File xmlFile) throws IOException {
        Reader fileReader = null;
        BufferedReader bufReader = null;

        List var5;
        try {
            fileReader = new FileReader(xmlFile);
            bufReader = new BufferedReader(fileReader);
            String xmlAsLine = (String)bufReader.lines().map((line) -> {
                return line.replaceAll("\r\n", "");
            }).collect(Collectors.joining());
            var5 = Arrays.asList(xmlAsLine.split("(?=<)"));
        } catch (FileNotFoundException var9) {
            throw new IOException("Di -> String Content 時發生問題", var9);
        } finally {
            IOUtils.closeReader(fileReader);
            IOUtils.closeReader(bufReader);
        }

        return var5;
    }

    private String filterXslName() {
        return Di2PdfUtils.getXslName((String)this.originContent.stream().filter(Di2PdfUtils::isHeadLine).map((diLine) -> {
            return diLine.substring(diLine.indexOf("\"") + 1, diLine.lastIndexOf("\""));
        }).findFirst().orElse(""));
    }

    private String filterXslYear(String xslName) {
        return xslName.substring(0, xslName.indexOf("_"));
    }

    private List<String> filterEntityKeys() {
        return (List)this.originContent.stream().filter((s) -> {
            return s.contains("!ENTITY");
        }).map(this::getEntityNameByEntityBlock).collect(Collectors.toList());
    }

    private List<String> format() {
        return (List)this.originContent.stream().map((s) -> {
            return this.replaceXMLEntityTag(s, this.entityKeys);
        }).collect(Collectors.toList());
    }

    private String replaceXMLEntityTag(String xmlLine, List<String> entityKeyWords) {
        Iterator var3 = entityKeyWords.iterator();

        while(true) {
            while(var3.hasNext()) {
                String entityKeyWord = (String)var3.next();
                Matcher matcher = Pattern.compile(String.format("((\"|\\s)%1$s)|(%1$s(\"|\\s))", entityKeyWord)).matcher(xmlLine);
                if (!xmlLine.contains("!ENTITY") && matcher.find()) {
                    String matchKey = matcher.group();
                    xmlLine = xmlLine.substring(0, xmlLine.indexOf(matchKey)) + matchKey.replace(entityKeyWord, "&" + entityKeyWord + ";") + xmlLine.substring(xmlLine.indexOf(matchKey) + matchKey.length(), xmlLine.length());
                } else if (xmlLine.equals(entityKeyWord)) {
                    xmlLine = xmlLine.replaceAll(entityKeyWord, "&" + entityKeyWord + ";");
                }
            }

            return this.replaceXMLEntityParameter(xmlLine);
        }
    }

    private String replaceXMLEntityParameter(String xmlLine) {
        return xmlLine.contains("!ENTITY") ? xmlLine.replaceAll("SYSTEM", "").replaceAll("NDATA.+[^>]", "") : xmlLine;
    }

    private String getEntityNameByEntityBlock(String entityBlock) {
        return entityBlock.substring(entityBlock.indexOf("!ENTITY") + "!ENTITY".length(), entityBlock.indexOf("SYSTEM")).trim();
    }
}
