package gov.archives.agent.domain.vo;

import gov.archives.core.domain.vo.SignInMeta;

public class ConfirmParams {
    private SignInMeta signInMeta;
    private SignHashPackage hashPackage;

    public ConfirmParams() {
    }

    public SignInMeta getSignInMeta() {
        return this.signInMeta;
    }

    public void setSignInMeta(SignInMeta signInMeta) {
        this.signInMeta = signInMeta;
    }

    public SignHashPackage getHashPackage() {
        return this.hashPackage;
    }

    public void setHashPackage(SignHashPackage hashPackage) {
        this.hashPackage = hashPackage;
    }

    public static final class Builder {
        private SignInMeta signInMeta;
        private SignHashPackage hashPackage;

        private Builder() {
        }

        public static ConfirmParams.Builder create() {
            return new ConfirmParams.Builder();
        }

        public ConfirmParams build() {
            ConfirmParams params = new ConfirmParams();
            params.setSignInMeta(this.signInMeta);
            params.setHashPackage(this.hashPackage);
            return params;
        }

        public ConfirmParams.Builder setSignInMeta(SignInMeta signInMeta) {
            this.signInMeta = signInMeta;
            return this;
        }

        public ConfirmParams.Builder setSignature(SignHashPackage hashPackage) {
            this.hashPackage = hashPackage;
            return this;
        }
    }
}

