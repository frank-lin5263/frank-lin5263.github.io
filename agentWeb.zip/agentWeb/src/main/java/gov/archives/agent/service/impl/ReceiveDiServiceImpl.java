package gov.archives.agent.service.impl;

import gov.archives.agent.Utils.ROCDateUtils;
import gov.archives.agent.accessor.XmlDtdAccessor;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.mapper.query.ReceiveInfoQueryMapper;
import gov.archives.core.conf.AgentConf;
import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Entity;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

@Service
public class ReceiveDiServiceImpl extends DefaultHandler {
    private static final String TAG_FIND = "true";
    @Autowired
    private XmlDtdAccessor dtdAccessor;
    @Autowired
    private ReceiveInfoQueryMapper queryMapper;
    private ReceiveDocumentEntity entity;
    private UUID documentId;
    private boolean isSend = false;
    private boolean isContract = false;
    private boolean isReceive = false;
    private boolean isDocSerial = false;
    private boolean isDocDate = false;
    private boolean isSubject = false;

    public ReceiveDiServiceImpl() {
    }

    private void emptyEntity() {
        this.entity = (ReceiveDocumentEntity)this.queryMapper.findOne(this.documentId);
        this.entity.setSendOrgId("");
        this.entity.setSendUnitId("");
        this.entity.setSendOrgName("");
        this.entity.setContractInfo("");
        this.entity.setDocWord("");
        this.entity.setApplicationId("");
        this.entity.setDocSpeed("");
        this.entity.setDocSubject("");
        this.entity.setDocDate(AgentConf.getDefaultTime());
    }

    public void setDocumentId(UUID documentId) {
        this.documentId = documentId;
    }

    public ReceiveDocumentEntity getEntity(String documentId) {
        return this.entity;
    }

    public String[] getAppendixFileName(File di, String[] appendix) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(this);
            DocumentType docType = builder.parse(di).getDoctype();

            for(int i = 0; i < appendix.length; ++i) {
                Entity entity = (Entity)docType.getEntities().getNamedItem(appendix[i]);
                appendix[i] = entity.getSystemId();
            }

            return appendix;
        } catch (SAXException | IOException | ParserConfigurationException var8) {
            throw new ArchivesException(var8.getMessage(), var8.getCause());
        }
    }

    public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
        String filePath = this.dtdAccessor.getDTDResourcePath(FilenameUtils.getName(systemId));
        return new InputSource(filePath);
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("函")) {
            this.emptyEntity();
        } else if (qName.equalsIgnoreCase("發文機關")) {
            this.isSend = true;
        } else if (this.isSend && qName.equalsIgnoreCase("全銜")) {
            this.entity.setSendOrgName("true");
        } else if (this.isSend && qName.equalsIgnoreCase("機關代碼")) {
            this.entity.setSendOrgId("true");
        } else {
            String speed;
            if (qName.equalsIgnoreCase("函類別")) {
                speed = attributes.getValue("代碼");
                this.entity.setDocCatalog(speed);
            } else if (qName.equalsIgnoreCase("聯絡方式")) {
                this.isContract = true;
            } else if (qName.equalsIgnoreCase("年月日")) {
                this.isDocDate = true;
            } else if (qName.equalsIgnoreCase("字")) {
                this.entity.setDocWord("true");
            } else if (qName.equalsIgnoreCase("文號")) {
                this.isDocSerial = true;
            } else if (qName.equalsIgnoreCase("速別")) {
                speed = attributes.getValue("代碼");
                this.entity.setDocSpeed(speed);
            } else if (qName.equalsIgnoreCase("附件檔名")) {
                String[] appendix = attributes.getValue("附件名").split(" ");
                this.entity.setAppendixFile(appendix);
            } else if (qName.equalsIgnoreCase("主旨")) {
                this.isSubject = true;
            } else if (this.isSubject && qName.equals("文字")) {
                this.isSubject = false;
                this.entity.setDocSubject("true");
            }
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equalsIgnoreCase("發文機關")) {
            this.isSend = false;
        } else if (qName.equalsIgnoreCase("受文者")) {
            this.isReceive = false;
        } else if (qName.equalsIgnoreCase("文號")) {
            this.isDocSerial = false;
        } else if (qName.equalsIgnoreCase("年月日")) {
            this.isDocDate = false;
        } else if (qName.equalsIgnoreCase("聯絡方式")) {
            this.isContract = false;
        }

    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        if (this.entity.getSendOrgName().equals("true")) {
            this.entity.setSendOrgName(new String(ch, start, length));
        } else {
            String docNumber;
            if (this.entity.getSendOrgId().equals("true")) {
                if (length > 10) {
                    docNumber = new String(ch, start, length);
                    this.entity.setSendOrgId(docNumber.substring(0, 10));
                    this.entity.setSendUnitId(docNumber.substring(11));
                } else {
                    this.entity.setSendOrgId(new String(ch, start, length));
                    this.entity.setSendUnitId("");
                }
            } else if (this.isDocDate) {
                docNumber = new String(ch, start, length);
                this.entity.setDocDate(ROCDateUtils.convertTwnTime(docNumber));
            } else if (this.entity.getDocWord().equals("true")) {
                this.entity.setDocWord(new String(ch, start, length));
            } else if (this.entity.getDocSubject().equals("true")) {
                this.entity.setDocSubject(new String(ch, start, length));
            } else if (this.isContract) {
                docNumber = this.entity.getContractInfo().concat(" " + new String(ch, start, length));
                this.entity.setContractInfo(docNumber);
            } else if (this.isDocSerial) {
                docNumber = this.entity.getApplicationId().concat(new String(ch, start, length));
                this.entity.setApplicationId(docNumber);
            }
        }

    }
}
