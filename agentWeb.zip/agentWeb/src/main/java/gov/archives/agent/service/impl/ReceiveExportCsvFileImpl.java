package gov.archives.agent.service.impl;

import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.service.ExportCsvFileApi;
import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ReceiveExportCsvFileImpl extends ExportCsvFile implements ExportCsvFileApi {
    private final List<String> headers = Arrays.asList("documentId", "processId", "sendOrgUnitId", "sendOrgUnitName", "receiveTime", "word", "docCatalog", "docNumber", "subject", "documentDate", "recOrgUnitName", "receiveStatus", "appendixFileName");

    public ReceiveExportCsvFileImpl() {
    }

    public File exportCsvFile(String account, List<?> list, Class<?> classType) {
        List<ReceiveDocumentEntity> lists = (List<ReceiveDocumentEntity>) list;
        File csvTemp = this.getCsvTempFile(account);

        try {
            CsvSchema schema = this.buildCsvSchema(this.headers);
            SequenceWriter csvWriter = this.createSequenceWriter(schema, csvTemp, classType);
            Iterator var8 = lists.iterator();

            while(var8.hasNext()) {
                ReceiveDocumentEntity nextRow = (ReceiveDocumentEntity)var8.next();
                csvWriter.write(nextRow);
            }

            if (list.isEmpty()) {
                csvWriter.write(Arrays.asList());
            }

            return csvTemp;
        } catch (IOException var10) {
            throw new ArchivesException(var10.getMessage(), var10.getCause());
        }
    }
}
