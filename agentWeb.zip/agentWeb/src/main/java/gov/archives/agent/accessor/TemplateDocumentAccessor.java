package gov.archives.agent.accessor;

import gov.archives.agent.domain.entity.StoredFileEntity;
import gov.archives.agent.domain.vo.ZipParams;
import gov.archives.agent.domain.vo.ZipParams.Builder;
import gov.archives.agent.mapper.query.StoredFileQueryMapper;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.UserInfoUtil;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import org.apache.commons.io.FileUtils;
import org.iii.common.conf.CommonConfig;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.security.hash.HashGenerators;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TemplateDocumentAccessor implements MessageListener {
    private static final String USER_HOME = "user.home";
    private static final String SYSTEM_NAME = "agentWeb";
    private Queue<File> pullFileQueue = new ConcurrentLinkedQueue();
    @Autowired
    private StoredFileQueryMapper queryMapper;
    @Autowired
    private FileAccessor fileAccessor;

    public TemplateDocumentAccessor() {
    }

    public synchronized void addPullFileQueue(UUID documentId) {
        this.pullFileQueue.add(this.getTempPath("ReceiveTemp").resolve(documentId.toString()).toFile());
    }

    public synchronized void addPullFileQueue(String fileHash) {
        this.pullFileQueue.add(this.getTempPath("SendList").resolve(fileHash + ".zip").toFile());
    }

    public synchronized void onMessage(Message message) {
        try {
            File receiveFile = (File)this.pullFileQueue.peek();
            BytesMessage fileMessage = (BytesMessage)message;
            int length = (int)fileMessage.getBodyLength();
            byte[] body = new byte[length];
            int read = fileMessage.readBytes(body);
            if (read != length) {
                this.pullFileQueue.remove(receiveFile);
                throw new ArchivesException("FU0001");
            } else {
                IOUtils.exportBytesToFile(body, receiveFile);
                this.pullFileQueue.remove(receiveFile);
            }
        } catch (IOException | JMSException var7) {
            throw new ArchivesException(var7.getMessage(), var7.getCause());
        }
    }

    public String getFileHash(File file) {
        try {
            byte[] fileContent = FileUtils.readFileToByteArray(file);
            String fileHash = HashGenerators.getInstanceByAlgorithm("SHA-256").getHashByBytes(fileContent);
            return fileHash;
        } catch (IOException var4) {
            throw new ArchivesException("產生 Hash 失敗");
        }
    }

    public File renameFile(File sourceFile, String newFileName) {
        IOUtils.isFileExist(sourceFile);
        Path filePath = sourceFile.toPath().getParent().resolve(newFileName);
        boolean result = sourceFile.renameTo(filePath.toFile());
        if (!result) {
            throw new ArchivesException("檔案更名錯誤");
        } else {
            return filePath.toFile();
        }
    }

    public File uncompressZipFile(File file, String account, String password, String fileName) {
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(file, password);
        Path accountPath = this.getTempPath("ReceiveTemp").resolve(account);
        FileSystemUtils.checkFolder(accountPath);
        File[] targetFile = new File[1];
        fileMap.entrySet().forEach((entry) -> {
            if (fileName.endsWith((String)entry.getKey())) {
                try {
                    byte[] fileData = (byte[])entry.getValue();
                    targetFile[0] = accountPath.resolve(fileName).toFile();
                    FileUtils.writeByteArrayToFile(targetFile[0], fileData);
                } catch (IOException var5) {
                    throw new ArchivesException(var5.getMessage(), var5.getCause());
                }
            }

        });
        return targetFile[0];
    }

    public List<File> uncompressZipFile(File file, String account, String password) {
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(file, password);
        List<File> sourceFiles = new ArrayList();
        Path accountPath = this.getTempPath("ReceiveTemp").resolve(account);
        FileSystemUtils.checkFolder(accountPath);
        fileMap.entrySet().forEach((entry) -> {
            String fileName = (String)entry.getKey();
            byte[] fileData = (byte[])entry.getValue();
            File tempFile = accountPath.resolve(fileName).toFile();

            try {
                FileUtils.writeByteArrayToFile(tempFile, fileData);
                sourceFiles.add(tempFile);
            } catch (IOException var7) {
                throw new ArchivesException(var7.getMessage(), var7.getCause());
            }
        });
        return sourceFiles;
    }

    public File getHtmlTempFile(String htmlTemp) {
        Path dtdPath = buildFilePath("src", "main", "webapp", "archivesapps", "views", "Template", htmlTemp);
        return dtdPath.toFile();
    }

    private static Path buildFilePath(String... paths) {
        Path rootPath = CommonConfig.getRuntimeRoot(TemplateDocumentAccessor.class);
        String[] var2 = paths;
        int var3 = paths.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            String pathName = var2[var4];
            rootPath = rootPath.resolve(pathName);
        }

        return rootPath;
    }

    public Path getTempPath(String tempFolder) {
        return this.buildTempFilePath(System.getProperty("user.home"), "agentWeb", tempFolder);
    }

    public Path getAccountTempPath() {
        String account = UserInfoUtil.getCurrentAccount();
        return this.buildTempFilePath(System.getProperty("user.home"), "agentWeb", "TempFiles", account);
    }

    public File uncompressSendZipFile(String account, UUID doucmentId) {
        ZipParams params = this.buildZipParams(doucmentId);
        File file = this.getTempPath("TempFiles").resolve(account).resolve(params.getFileHash() + ".zip").toFile();
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(file, params.getDecryptedToken());
        return this.traversalDiFile(fileMap, account);
    }

    private ZipParams buildZipParams(UUID doucmentId) {
        StoredFileEntity entity = (StoredFileEntity)this.queryMapper.findOne(doucmentId);
        ZipParams params = Builder.create().setFileHash(entity.getFileHash()).setDecryptedToken(entity.getFilePassword()).build();
        return params;
    }

    private File traversalDiFile(Map<String, byte[]> fileMap, String account) {
        File diFile = null;
        Iterator var4 = fileMap.keySet().iterator();

        String name;
        do {
            if (!var4.hasNext()) {
                return diFile;
            }

            name = (String)var4.next();
        } while(!name.endsWith(".di"));

        diFile = this.getTempPath("TempFiles").resolve(account).resolve(name).toFile();

        try {
            FileUtils.writeByteArrayToFile(diFile, (byte[])fileMap.get(name));
            return diFile;
        } catch (IOException var7) {
            throw new ArchivesException(var7.getMessage(), var7.getCause());
        }
    }

    public File uncompressDiFile(String documentId, String password) {
        File file = this.getTempPath("ReceiveTemp").resolve(documentId).toFile();
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(file, password);
        Set<String> keySet = fileMap.keySet();
        Iterator var6 = keySet.iterator();

        String name;
        do {
            if (!var6.hasNext()) {
                return null;
            }

            name = (String)var6.next();
        } while(!name.equals("print.di"));

        File printDi = this.getTempPath("TempFiles").resolve(name).toFile();

        try {
            FileUtils.writeByteArrayToFile(printDi, (byte[])fileMap.get(name));
            return printDi;
        } catch (IOException var10) {
            throw new ArchivesException(var10.getMessage(), var10.getCause());
        }
    }

    private Path buildTempFilePath(String... filePath) {
        String paths = "";
        String[] var3 = filePath;
        int var4 = filePath.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            String path = var3[var5];
            paths = paths + path;
            paths = paths + "/";
            FileSystemUtils.checkFolder(Paths.get(paths));
        }

        return Paths.get(paths);
    }
}
