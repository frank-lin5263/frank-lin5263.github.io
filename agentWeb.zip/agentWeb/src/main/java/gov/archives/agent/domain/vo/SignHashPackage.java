package gov.archives.agent.domain.vo;

import java.io.Serializable;

public class SignHashPackage implements Serializable {
    public static final String PARAM_SIGNATURE = "signature";
    public static final String PARAM_SIGCERT = "sigCert";
    public static final String PARAM_ENCCERT = "encCert";
    private String signature;
    private String sigCert;
    private String encCert;

    public SignHashPackage() {
    }

    public String getSignature() {
        return this.signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getSigCert() {
        return this.sigCert;
    }

    public void setSigCert(String sigCert) {
        this.sigCert = sigCert;
    }

    public String getEncCert() {
        return this.encCert;
    }

    public void setEncCert(String encCert) {
        this.encCert = encCert;
    }

    public static final class Builder {
        private String signature;
        private String sigCert;
        private String encCert;

        private Builder() {
        }

        public static SignHashPackage.Builder create() {
            return new SignHashPackage.Builder();
        }

        public SignHashPackage build() {
            SignHashPackage hashPackage = new SignHashPackage();
            hashPackage.setSignature(this.signature);
            hashPackage.setSigCert(this.sigCert);
            hashPackage.setEncCert(this.encCert);
            return hashPackage;
        }

        public SignHashPackage.Builder setSignature(String signature) {
            this.signature = signature;
            return this;
        }

        public SignHashPackage.Builder setSigCert(String sigCert) {
            this.sigCert = sigCert;
            return this;
        }

        public SignHashPackage.Builder setEncCert(String encCert) {
            this.encCert = encCert;
            return this;
        }
    }
}

