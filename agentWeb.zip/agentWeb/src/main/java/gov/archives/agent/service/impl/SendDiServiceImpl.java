package gov.archives.agent.service.impl;

import gov.archives.agent.Utils.ROCDateUtils;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.accessor.XmlDtdAccessor;
import gov.archives.agent.conf.SendStatus;
import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.entity.SendDocumentEntity.Builder;
import gov.archives.core.conf.AgentConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.UserInfoUtil;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Entity;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

@Service
public class SendDiServiceImpl extends DefaultHandler {
    private static final String TAG_FIND = "true";
    private static final UUID DEFAULT_SYS_ID = UUID.fromString("00000000-0000-0000-0000-000000000000");
    @Autowired
    private XmlDtdAccessor dtdAccessor;
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    private SendDocumentEntity entity;
    private String exchangeForm;
    private boolean isDocSerial = false;
    private boolean isDocDate = false;
    private boolean isContract = false;
    private boolean isSubject = false;

    public SendDiServiceImpl() {
    }

    public String getExchangeForm() {
        return this.exchangeForm;
    }

    private void buildEmptyEntity() {
        this.entity = Builder.create().setDocDate(AgentConf.getDefaultTime()).setExchangeId("").setSendOrgId("").setSendUnitId("").setSendOrgName("").setContractInfo("").setReceiverCount(0).setSendOutTime(AgentConf.getNowTime()).setDocWord("").setDocCatalog("").setApplicationId("").setDocSpeed("").setSubject("").setDocDate(AgentConf.getDefaultTime()).setStatusCode(SendStatus.START).setAppendixFile((String[])null).build();
        String account = UserInfoUtil.getCurrentAccount();
        this.entity.initSave(account, DEFAULT_SYS_ID);
    }

    public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
        String filePath = this.dtdAccessor.getDTDResourcePath(FilenameUtils.getName(systemId));
        return new InputSource(filePath);
    }

    public File getExchangeFormFile(File di, String formName) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(this);
            DocumentType docType = builder.parse(di).getDoctype();
            if (formName != null) {
                Entity entity = (Entity)docType.getEntities().getNamedItem(formName);
                return this.documentAccessor.getTempPath("TempFiles").resolve(entity.getSystemId()).toFile();
            } else {
                return null;
            }
        } catch (SAXException | IOException | ParserConfigurationException var7) {
            throw new ArchivesException(var7.getMessage(), var7.getCause());
        }
    }

    public SendDocumentEntity postEntityProcess(File di) {
        String[] appendFile = this.getAppendixFileName(di, this.entity.getAppendixFile());
        this.entity.setAppendixFile(appendFile);
        return this.entity;
    }

    private String[] getAppendixFileName(File di, String[] appendix) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setEntityResolver(this);
            DocumentType docType = builder.parse(di).getDoctype();

            for(int i = 0; i < appendix.length; ++i) {
                Entity entity = (Entity)docType.getEntities().getNamedItem(appendix[i]);
                appendix[i] = entity.getSystemId();
            }

            return appendix;
        } catch (SAXException | IOException | ParserConfigurationException var8) {
            throw new ArchivesException(var8.getMessage(), var8.getCause());
        }
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("函")) {
            this.buildEmptyEntity();
        } else if (qName.equalsIgnoreCase("全銜")) {
            this.entity.setSendOrgName("true");
        } else if (qName.equalsIgnoreCase("機關代碼")) {
            this.entity.setSendOrgId("true");
        } else {
            String speed;
            if (qName.equalsIgnoreCase("函類別")) {
                speed = attributes.getValue("代碼");
                this.entity.setDocCatalog(speed);
            } else if (qName.equalsIgnoreCase("速別")) {
                speed = attributes.getValue("代碼");
                this.entity.setDocSpeed(speed);
            } else if (qName.equalsIgnoreCase("聯絡方式")) {
                this.isContract = true;
            } else if (qName.equalsIgnoreCase("交換表")) {
                this.exchangeForm = attributes.getValue("交換表單");
            } else if (qName.equalsIgnoreCase("年月日")) {
                this.isDocDate = true;
            } else if (qName.equalsIgnoreCase("字")) {
                this.entity.setDocWord("true");
            } else if (qName.equalsIgnoreCase("文號")) {
                this.isDocSerial = true;
            } else if (qName.equalsIgnoreCase("附件檔名")) {
                String[] appendix = attributes.getValue("附件名").split(" ");
                this.entity.setAppendixFile(appendix);
            } else if (qName.equalsIgnoreCase("主旨")) {
                this.isSubject = true;
            } else if (this.isSubject && qName.equals("文字")) {
                this.isSubject = false;
                this.entity.setSubject("true");
            }
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equalsIgnoreCase("文號")) {
            this.isDocSerial = false;
        } else if (qName.equalsIgnoreCase("聯絡方式")) {
            this.isContract = false;
        } else if (qName.equalsIgnoreCase("年月日")) {
            this.isDocDate = false;
        }

    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        if (this.entity.getSendOrgName().equals("true")) {
            this.entity.setSendOrgName(new String(ch, start, length));
        } else {
            String textNumber;
            if (this.entity.getSendOrgId().equals("true")) {
                if (length > 10) {
                    textNumber = new String(ch, start, length);
                    this.entity.setSendOrgId(textNumber.substring(0, 10));
                    this.entity.setSendUnitId(textNumber.substring(11));
                } else {
                    this.entity.setSendOrgId(new String(ch, start, length));
                    this.entity.setSendUnitId("");
                }
            } else if (this.isDocDate) {
                textNumber = new String(ch, start, length);
                this.entity.setDocDate(ROCDateUtils.convertTwnTime(textNumber));
            } else if (this.entity.getDocWord().equals("true")) {
                this.entity.setDocWord(new String(ch, start, length));
            } else if (this.entity.getSubject().equals("true")) {
                this.entity.setSubject(new String(ch, start, length));
            } else if (this.isContract) {
                textNumber = this.entity.getContractInfo().concat(" " + new String(ch, start, length));
                this.entity.setContractInfo(textNumber);
            } else if (this.isDocSerial) {
                textNumber = this.entity.getApplicationId().concat(new String(ch, start, length));
                this.entity.setApplicationId(textNumber);
            }
        }

    }
}
