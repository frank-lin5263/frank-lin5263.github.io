package gov.archives.agent.mapper;

import java.io.Serializable;

public interface Repository<T, ID extends Serializable> {
}

