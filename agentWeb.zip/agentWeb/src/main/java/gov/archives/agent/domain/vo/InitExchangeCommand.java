package gov.archives.agent.domain.vo;

import java.util.UUID;

public class InitExchangeCommand<P> {
    private UUID id;
    private String name;
    private P parameters;

    public InitExchangeCommand() {
    }

    public UUID getId() {
        return this.id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public P getParameters() {
        return this.parameters;
    }

    public void setParameters(P parameters) {
        this.parameters = parameters;
    }

    public static final class Builder<P> {
        private UUID id;
        private String name;
        private P parameters;

        public static <P> InitExchangeCommand.Builder<P> createParameter(P parameters) {
            return new InitExchangeCommand.Builder(parameters);
        }

        private Builder(P parameters) {
            this.parameters = parameters;
        }

        public InitExchangeCommand<P> build() {
            InitExchangeCommand<P> baseParameter = new InitExchangeCommand();
            baseParameter.setId(this.id);
            baseParameter.setName(this.name);
            baseParameter.setParameters(this.parameters);
            return baseParameter;
        }

        public InitExchangeCommand.Builder setId(UUID id) {
            this.id = id;
            return this;
        }

        public InitExchangeCommand.Builder setName(String name) {
            this.name = name;
            return this;
        }
    }
}

