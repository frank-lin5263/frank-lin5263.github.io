package gov.archives.agent.domain.vo;

public class LogoutParams {
    private String account;
    private String remoteAddress;
    private String sessionId;
    private String signedToken;

    public LogoutParams() {
    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getRemoteAddress() {
        return this.remoteAddress;
    }

    public void setRemoteAddress(String remoteAddress) {
        this.remoteAddress = remoteAddress;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSignedToken() {
        return this.signedToken;
    }

    public void setSignedToken(String signedToken) {
        this.signedToken = signedToken;
    }
}

