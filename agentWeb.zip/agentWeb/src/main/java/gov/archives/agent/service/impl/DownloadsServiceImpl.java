package gov.archives.agent.service.impl;

import gov.archives.agent.Utils.CompressUtils;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.domain.entity.StoredFileEntity;
import gov.archives.agent.mapper.query.StoredFileQueryMapper;
import gov.archives.agent.service.DownloadsService;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.UserInfoUtil;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.io.FilenameUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

@Service
public class DownloadsServiceImpl implements DownloadsService {
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    @Autowired
    private StoredFileQueryMapper fileQueryMapper;

    public DownloadsServiceImpl() {
    }

    public File getUncompressFile(String fileName, String documentId) {
        StoredFileEntity entity = (StoredFileEntity)this.fileQueryMapper.findOne(UUID.fromString(documentId));
        String account = UserInfoUtil.getCurrentAccount();
        File file = this.documentAccessor.getTempPath("TempFiles").resolve(entity.getOrgUnitId()).resolve(entity.getFileHash() + ".zip").toFile();
        return this.documentAccessor.uncompressZipFile(file, account, entity.getFilePassword(), fileName);
    }

    public File buildAllDownload(String documentId) {
        StoredFileEntity entity = (StoredFileEntity)this.fileQueryMapper.findOne(UUID.fromString(documentId));
        String account = UserInfoUtil.getCurrentAccount();
        File file = this.documentAccessor.getTempPath("TempFiles").resolve(entity.getOrgUnitId()).resolve(entity.getFileHash() + ".zip").toFile();
        List<File> sourceFiles = this.documentAccessor.uncompressZipFile(file, account, entity.getFilePassword());
        return this.saveDownloadZip(sourceFiles, account, documentId);
    }

    public File buildDownloadZip(String documentId, String decryptedToken) {
        String password = new String(DatatypeConverter.parseBase64Binary(decryptedToken));
        String account = UserInfoUtil.getCurrentAccount();
        File file = this.documentAccessor.getTempPath("ReceiveTemp").resolve(documentId).toFile();
        List<File> sourceFiles = this.documentAccessor.uncompressZipFile(file, account, password);
        return this.saveDownloadZip(sourceFiles, account, documentId);
    }

    public File getReceiveDi(String documentId, String decryptedToken) {
        String password = new String(DatatypeConverter.parseBase64Binary(decryptedToken));
        String account = UserInfoUtil.getCurrentAccount();
        File tempFile = this.documentAccessor.getTempPath("ReceiveTemp").resolve(documentId).toFile();
        List<File> sourceFiles = this.documentAccessor.uncompressZipFile(tempFile, account, password);
        Iterator var7 = sourceFiles.iterator();

        File file;
        do {
            if (!var7.hasNext()) {
                return null;
            }

            file = (File)var7.next();
        } while(!FilenameUtils.isExtension(file.getName(), "di"));

        return file;
    }

    public void responseDownloadingFile(File file, HttpServletResponse response, String fileExt, String contentType) {
        PreconditionUtils.checkArguments(new Object[]{file});
        BufferedInputStream inputStream = null;

        try {
            String filename = file.getName().concat(fileExt);
            response.setContentType(contentType);
            response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", filename));
            response.setContentLength((int)file.length());
            inputStream = new BufferedInputStream(new FileInputStream(file));
            FileCopyUtils.copy(inputStream, response.getOutputStream());
            response.flushBuffer();
        } catch (IOException var10) {
            throw new ArchivesException(var10.getMessage(), var10.getCause());
        } finally {
            this.safeCloseInputStream(inputStream);
        }

    }

    private void safeCloseInputStream(InputStream is) {
        try {
            if (is != null) {
                is.close();
            }

        } catch (IOException var3) {
            throw new ArchivesException(var3.getMessage(), var3.getCause());
        }
    }

    private File saveDownloadZip(List<File> sourceFiles, String account, String documentId) {
        File testDocZip = this.documentAccessor.getTempPath("ReceiveTemp").resolve(account).resolve(documentId).toFile();
        CompressUtils.compressFilesToZip(sourceFiles, testDocZip);
        this.deleteTempFile(sourceFiles);
        return testDocZip;
    }

    private void deleteTempFile(List<File> sourceFiles) {
        Iterator var2 = sourceFiles.iterator();

        while(var2.hasNext()) {
            File file = (File)var2.next();
            IOUtils.deleteFile(file);
        }

        sourceFiles.clear();
    }
}
