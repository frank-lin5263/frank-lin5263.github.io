package gov.archives.agent.mapper.query;

import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.mapper.QueryRepository;
import java.util.UUID;

public interface SendInfoQueryMapper extends QueryRepository<SendDocumentEntity, UUID> {
}
