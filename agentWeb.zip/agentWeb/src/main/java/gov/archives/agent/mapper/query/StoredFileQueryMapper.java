package gov.archives.agent.mapper.query;

import gov.archives.agent.domain.entity.StoredFileEntity;
import gov.archives.agent.mapper.QueryRepository;
import java.util.UUID;

public interface StoredFileQueryMapper extends QueryRepository<StoredFileEntity, UUID> {
}