package gov.archives.agent.domain.vo;

import java.time.Instant;
import java.util.UUID;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.StringUtils;

public class ArrangeRule {
    private String moduleName;
    private UUID sysId;
    private Instant createdTime;
    private String fileHash;
    private String fileName;

    public ArrangeRule() {
    }

    public String getModuleName() {
        return this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public UUID getSysId() {
        return this.sysId;
    }

    public void setSysId(UUID sysId) {
        this.sysId = sysId;
    }

    public Instant getCreatedTime() {
        return this.createdTime;
    }

    public void setCreatedTime(Instant createdTime) {
        this.createdTime = createdTime;
    }

    public String getFileHash() {
        return this.fileHash;
    }

    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public String getFileName() {
        return !StringUtils.isEmpty(this.fileName) ? this.fileName : this.fileHash;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFolderName() {
        return this.createdTime.getEpochSecond() + "_" + this.sysId.toString();
    }

    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, new String[0]);
    }

    public boolean equals(Object obj) {
        return EqualsBuilder.reflectionEquals(this, obj, new String[0]);
    }

    public static Long getEpochSecondByFolderName(String folderName) {
        int separatorIndex = folderName.indexOf("_");
        if (separatorIndex == -1) {
            throw new ApplicationException("資料夾名稱錯誤");
        } else {
            return Long.parseLong(folderName.substring(0, separatorIndex));
        }
    }

    public static String getSysIdByFolderName(String folderName) {
        int separatorIndex = folderName.indexOf("_");
        if (separatorIndex == -1) {
            throw new ApplicationException("資料夾名稱錯誤");
        } else {
            return folderName.substring(separatorIndex + 1);
        }
    }

    public static class Builder {
        private String moduleName;
        private String fileHash;
        private String fileName;
        private UUID sysId;

        private Builder() {
        }

        public static ArrangeRule.Builder create() {
            return new ArrangeRule.Builder();
        }

        public ArrangeRule build() {
            if (null == this.sysId) {
                this.sysId = UUID.randomUUID();
            }

            ArrangeRule rule = new ArrangeRule();
            rule.setModuleName(this.moduleName);
            rule.setFileHash(this.fileHash);
            rule.setFileName(this.fileName);
            rule.setSysId(this.sysId);
            rule.setCreatedTime(Instant.now());
            return rule;
        }

        public ArrangeRule.Builder setSysId(UUID sysId) {
            this.sysId = sysId;
            return this;
        }

        public ArrangeRule.Builder setModuleName(String moduleName) {
            this.moduleName = moduleName;
            return this;
        }

        public ArrangeRule.Builder setFileHash(String fileHash) {
            this.fileHash = fileHash;
            return this;
        }

        public ArrangeRule.Builder setFileName(String fileName) {
            this.fileName = fileName;
            return this;
        }
    }
}
