package gov.archives.agent.domain.vo;

import gov.archives.agent.domain.entity.RootEntity;
import org.apache.ibatis.type.Alias;

@Alias("ReceiveQuery")
public class ReceivedQuery extends RootEntity {
    private Boolean isMark;
    private Boolean isPrint;
    private String receiveStatus;
    private String sendOrgName;
    private String contractInfo;
    private String archiveId;
    private String archiveSpeed;
    private String archiveWord;
    private String archiveCatalog;
    private String subject;
    private Integer attach;
    private String confirmOrReject;
    private String[] appendixFileName;

    public ReceivedQuery() {
    }

    public Boolean getMark() {
        return this.isMark;
    }

    public void setMark(Boolean mark) {
        this.isMark = mark;
    }

    public Boolean getPrint() {
        return this.isPrint;
    }

    public void setPrint(Boolean print) {
        this.isPrint = print;
    }

    public String getReceiveStatus() {
        return this.receiveStatus;
    }

    public void setReceiveStatus(String receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public String getSendOrgName() {
        return this.sendOrgName;
    }

    public void setSendOrgName(String sendOrgName) {
        this.sendOrgName = sendOrgName;
    }

    public String getContractInfo() {
        return this.contractInfo;
    }

    public void setContractInfo(String contractInfo) {
        this.contractInfo = contractInfo;
    }

    public String getArchiveId() {
        return this.archiveId;
    }

    public void setArchiveId(String archiveId) {
        this.archiveId = archiveId;
    }

    public String getArchiveSpeed() {
        return this.archiveSpeed;
    }

    public void setArchiveSpeed(String archiveSpeed) {
        this.archiveSpeed = archiveSpeed;
    }

    public String getArchiveWord() {
        return this.archiveWord;
    }

    public void setArchiveWord(String archiveWord) {
        this.archiveWord = archiveWord;
    }

    public String getArchiveCatalog() {
        return this.archiveCatalog;
    }

    public void setArchiveCatalog(String archiveCatalog) {
        this.archiveCatalog = archiveCatalog;
    }

    public String getSubject() {
        return this.subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Integer getAttach() {
        return this.attach;
    }

    public void setAttach(Integer attach) {
        this.attach = attach;
    }

    public String getConfirmOrReject() {
        return this.confirmOrReject;
    }

    public void setConfirmOrReject(String confirmOrReject) {
        this.confirmOrReject = confirmOrReject;
    }

    public String[] getAppendixFileName() {
        return this.appendixFileName;
    }

    public void setAppendixFileName(String[] appendixFileName) {
        this.appendixFileName = appendixFileName;
    }

    public static final class Builder {
        private Boolean isMark;
        private Boolean isPrint;
        private String receiveStatus;
        private String sendOrgName;
        private String contractInfo;
        private String archiveId;
        private String archiveSpeed;
        private String archiveWord;
        private String archiveCatalog;
        private String subject;
        private Integer attach;
        private String confirmOrReject;
        private String[] appendixFileName;

        private Builder() {
        }

        public static ReceivedQuery.Builder create() {
            return new ReceivedQuery.Builder();
        }

        public ReceivedQuery build() {
            ReceivedQuery entity = new ReceivedQuery();
            entity.setMark(this.isMark);
            entity.setPrint(this.isPrint);
            entity.setReceiveStatus(this.receiveStatus);
            entity.setSendOrgName(this.sendOrgName);
            entity.setContractInfo(this.contractInfo);
            entity.setArchiveId(this.archiveId);
            entity.setArchiveSpeed(this.archiveSpeed);
            entity.setArchiveWord(this.archiveWord);
            entity.setArchiveCatalog(this.archiveCatalog);
            entity.setSubject(this.subject);
            entity.setAttach(this.attach);
            entity.setConfirmOrReject(this.confirmOrReject);
            entity.setAppendixFileName(this.appendixFileName);
            return entity;
        }

        public ReceivedQuery.Builder setMark(Boolean mark) {
            this.isMark = mark;
            return this;
        }

        public ReceivedQuery.Builder setPrint(Boolean print) {
            this.isPrint = print;
            return this;
        }

        public ReceivedQuery.Builder setReceiveStatus(String receiveStatus) {
            this.receiveStatus = receiveStatus;
            return this;
        }

        public ReceivedQuery.Builder setSendOrgName(String sendOrgName) {
            this.sendOrgName = sendOrgName;
            return this;
        }

        public ReceivedQuery.Builder setContractInfo(String contractInfo) {
            this.contractInfo = contractInfo;
            return this;
        }

        public ReceivedQuery.Builder setArchiveId(String archiveId) {
            this.archiveId = archiveId;
            return this;
        }

        public ReceivedQuery.Builder setArchiveSpeed(String archiveSpeed) {
            this.archiveSpeed = archiveSpeed;
            return this;
        }

        public ReceivedQuery.Builder setArchiveWord(String archiveWord) {
            this.archiveWord = archiveWord;
            return this;
        }

        public ReceivedQuery.Builder setArchiveCatalog(String archiveCatalog) {
            this.archiveCatalog = archiveCatalog;
            return this;
        }

        public ReceivedQuery.Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public ReceivedQuery.Builder setAttach(Integer attach) {
            this.attach = attach;
            return this;
        }

        public ReceivedQuery.Builder setConfirmOrReject(String confirmOrReject) {
            this.confirmOrReject = confirmOrReject;
            return this;
        }

        public ReceivedQuery.Builder setAppendixFileName(String[] appendixFileName) {
            this.appendixFileName = appendixFileName;
            return this;
        }
    }
}
