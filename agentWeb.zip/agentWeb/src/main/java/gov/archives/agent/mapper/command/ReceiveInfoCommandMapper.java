package gov.archives.agent.mapper.command;

import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.mapper.CommadnRepository;
import java.util.UUID;

public interface ReceiveInfoCommandMapper extends CommadnRepository<ReceiveDocumentEntity, UUID> {
}
