package gov.archives.agent.service.impl;

import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.conf.ReceiveStatus;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.domain.entity.ReceiveDocumentEntity.Builder;
import gov.archives.agent.mapper.command.ReceiveInfoCommandMapper;
import gov.archives.agent.mapper.query.ReceiveInfoQueryMapper;
import gov.archives.agent.service.ReceiveInfoService;
import gov.archives.core.conf.AgentConf;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.UserInfoUtil;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.commons.io.FileUtils;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

@Service
public class ReceiveInfoServiceImpl implements ReceiveInfoService {
    @Autowired
    private ReceiveInfoCommandMapper commandMapper;
    @Autowired
    private ReceiveInfoQueryMapper queryMapper;
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    @Autowired
    private ReceiveDiServiceImpl receiveDiService;
    private SAXParserFactory saxParserFactory;
    private SAXParser saxParser;

    public ReceiveInfoServiceImpl() {
        try {
            this.saxParserFactory = SAXParserFactory.newInstance();
            this.saxParser = this.saxParserFactory.newSAXParser();
        } catch (SAXException | ParserConfigurationException var2) {
            throw new ArchivesException(var2.getMessage(), var2.getCause());
        }
    }

    public void saveReceiveInfo(UUID documentId) {
        ReceiveDocumentEntity entity = Builder.create().setStatusCode(ReceiveStatus.ARRIVE).setUserReceiveTime(Timestamp.from(Instant.now())).setUserConfirmTime(AgentConf.getDefaultTime()).setUserRejectTime(AgentConf.getDefaultTime()).build();
        entity.initSave(UserInfoUtil.getCurrentAccount(), documentId);
        this.commandMapper.save(entity);
    }

    public void update(ReceiveDocumentEntity entity) {
        this.commandMapper.update(entity);
    }

    public void update(ReceiveConfirmResult confirmResult, String decryptedToken) {
        ReceiveDocumentEntity entity = this.saxParserByDocumentId(confirmResult.getDocumentId().toString(), decryptedToken);
        entity.setDocumentId(confirmResult.getDocumentId());
        entity.setProcessId(confirmResult.getProcessId());
        entity.setStatusCode(ReceiveStatus.RECEIVE_FINISH);
        entity.setUserConfirmTime(Timestamp.from(Instant.now()));
        this.commandMapper.update(entity);
    }

    private ReceiveDocumentEntity saxParserByDocumentId(String documentId, String password) {
        File di = this.documentAccessor.uncompressDiFile(documentId, password);

        ReceiveDocumentEntity var5;
        try {
            this.receiveDiService.setDocumentId(UUID.fromString(documentId));
            this.saxParser.getXMLReader().setEntityResolver(this.receiveDiService);
            this.saxParser.parse(di, this.receiveDiService);
            ReceiveDocumentEntity entity = this.receiveDiService.getEntity(documentId);
            entity.setAppendixFile(this.receiveDiService.getAppendixFileName(di, entity.getAppendixFile()));
            var5 = entity;
        } catch (IOException | SAXException var9) {
            throw new ArchivesException(var9.getMessage(), var9.getCause());
        } finally {
            FileUtils.deleteQuietly(di);
        }

        return var5;
    }

    public void updateStatusCode(Integer statusCode, String documentId) {
        PreconditionUtils.checkArguments(new Object[]{statusCode, documentId});
        ReceiveDocumentEntity entity = (ReceiveDocumentEntity)this.queryMapper.findOne(UUID.fromString(documentId));
        entity.setStatusCode(statusCode);
        entity.setModifierAccount(UserInfoUtil.getCurrentAccount());
        entity.setModifiedTime(Timestamp.valueOf(Timestamp.from(Instant.now()).toLocalDateTime()));
        this.commandMapper.update(entity);
    }

    public ReceiveDocumentEntity findByDocument(UUID documentId) {
        PreconditionUtils.checkArguments(new Object[]{documentId});
        return (ReceiveDocumentEntity)this.queryMapper.findOne(documentId);
    }

    public List<ReceiveDocumentEntity> listAll() {
        return this.queryMapper.findAll();
    }
}
