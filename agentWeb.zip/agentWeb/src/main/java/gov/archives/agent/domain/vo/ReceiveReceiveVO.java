package gov.archives.agent.domain.vo;

import gov.archives.jagent.domain.result.ReceiveReceiveResult;

public class ReceiveReceiveVO {
    private String b64ConfirmHash;
    private ReceiveReceiveResult receiveResult;

    public ReceiveReceiveVO() {
    }

    public String getB64ConfirmHash() {
        return this.b64ConfirmHash;
    }

    public void setB64ConfirmHash(String b64ConfirmHash) {
        this.b64ConfirmHash = b64ConfirmHash;
    }

    public ReceiveReceiveResult getReceiveResult() {
        return this.receiveResult;
    }

    public void setReceiveResult(ReceiveReceiveResult receiveResult) {
        this.receiveResult = receiveResult;
    }
}
