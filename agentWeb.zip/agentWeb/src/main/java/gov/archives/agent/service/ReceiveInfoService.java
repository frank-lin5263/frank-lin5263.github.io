package gov.archives.agent.service;

import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import java.util.List;
import java.util.UUID;

public interface ReceiveInfoService {
    void saveReceiveInfo(UUID var1);

    void update(ReceiveDocumentEntity var1);

    void update(ReceiveConfirmResult var1, String var2);

    void updateStatusCode(Integer var1, String var2);

    ReceiveDocumentEntity findByDocument(UUID var1);

    List<ReceiveDocumentEntity> listAll();
}
