package gov.archives.agent.conf;

import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.net.URISyntaxException;
import java.security.KeyStore;
import java.util.Properties;
import java.util.UUID;
import org.iii.common.util.IOUtils;
import org.iii.security.util.KeyStoreUtils;

public class AgentApiConf {
    public static final String KEY_TRUSTSTORE_FILE = "gca.truststore.file";
    public static final String KEY_TRUSTSTORE_TYPE = "gca.truststore.type";
    public static final String KEY_TRUSTSTORE_PASS = "gca.truststore.pass";
    public static final String TYPE_JAVA_KEY_STORE = "jks";
    public static final String TYPE_PKCS12 = "pkcs12";
    public static final String CSV_CONTENT_TYPE = "text/csv";
    public static final String HTML_CONTENT_TYPE = "text/html";
    public static final String CSV_FILE_EXT = ".csv";
    public static final String ZIP_FILE_EXT = ".zip";
    public static final String HTML_FILE_EXT = ".html";
    public static final String JMS_TRANSACTION = "JmsTransactionManager";
    public static final String PROPERTIES_GCA = "gca.properties";
    public static final String FOLDER_WEB_INF = "WEB-INF/";
    public static final UUID DEFAULT_DOCUMENT_ID = UUID.fromString("00000000-0000-0000-0000-000000000000");
    public static final String MODULE_SEND_DOCUMENTS = "SendDocuments";
    private static KeyStore trustGCAStore;
    private static Properties gcaProp;

    public AgentApiConf() {
    }

    public static void setGCAProperties(Properties prop) {
        if (null == gcaProp) {
            gcaProp = prop;
        }

    }

    public static String getKeyStorePass() {
        return gcaProp.getProperty("gca.truststore.pass");
    }

    public static KeyStore getTrustStore() {
        if (null == trustGCAStore) {
            trustGCAStore = initKeyStore(gcaProp.getProperty("gca.truststore.file"), gcaProp.getProperty("gca.truststore.pass"), gcaProp.getProperty("gca.truststore.type"));
        }

        return trustGCAStore;
    }

    private static KeyStore initKeyStore(String fileName, String pass, String type) {
        try {
            File keyStoreFile = IOUtils.getFileFromPathOrClassPathElse(fileName, fileName);
            if ("jks".equals(type)) {
                return KeyStoreUtils.loadJavaKeyStore(keyStoreFile, pass);
            } else if ("pkcs12".equals(type)) {
                return KeyStoreUtils.loadPKCS12KeyStore(keyStoreFile, pass);
            } else {
                throw new ArchivesException("錯誤的 KeyStore 類型");
            }
        } catch (URISyntaxException var4) {
            throw ArchivesException.getInstanceByErrorCode(var4.getMessage(), new Object[0]);
        }
    }
}

