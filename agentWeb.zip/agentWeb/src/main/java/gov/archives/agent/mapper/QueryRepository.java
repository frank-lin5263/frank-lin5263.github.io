package gov.archives.agent.mapper;

import java.io.Serializable;
import java.util.List;

public interface QueryRepository<T, ID extends Serializable> extends Repository<T, ID> {
    T findOne(ID var1);

    List<T> findAll();
}
