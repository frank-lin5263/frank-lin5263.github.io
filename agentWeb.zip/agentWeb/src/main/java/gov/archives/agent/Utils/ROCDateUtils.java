package gov.archives.agent.Utils;

import gov.archives.core.exception.ArchivesException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.time.DateUtils;

public class ROCDateUtils {
    private static final String twnTimePattern = "中華民國(\\d+)年(\\d+)月(\\d+)日";
    private static final Pattern twnPattern = Pattern.compile("中華民國(\\d+)年(\\d+)月(\\d+)日");
    public static final String ROC_TITLE = "中華民國";
    public static final String ROC_YEAR = "年";
    public static final String ROC_MONTH = "月";
    public static final String ROC_DAY = "日";

    public ROCDateUtils() {
    }

    public static Timestamp convertTwnTime(String twnTime) {
        Matcher matcher = twnPattern.matcher(twnTime);
        if (!matcher.matches()) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
        } else {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Integer.parseInt(matcher.group(1)) + 1911, Integer.parseInt(matcher.group(2)) - 1, Integer.parseInt(matcher.group(3)));
            Calendar truncated = DateUtils.truncate(calendar, 5);
            return Timestamp.from(truncated.toInstant());
        }
    }

    public static String getROCDateNow() {
        LocalDateTime now = LocalDateTime.now();
        return String.format("中華民國%1$s年%2$s月%3$s日", now.getYear() - 1911, now.getMonthValue(), now.getDayOfMonth());
    }

    public static String getRocYearNow() {
        LocalDateTime now = LocalDateTime.now();
        return String.valueOf(now.getYear() - 1911);
    }
}

