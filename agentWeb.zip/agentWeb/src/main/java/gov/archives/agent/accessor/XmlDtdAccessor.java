package gov.archives.agent.accessor;

import gov.archives.core.exception.ArchivesException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.springframework.stereotype.Component;

@Component
public class XmlDtdAccessor {
    private static final String DTD_RESOURCE_FOLDER = "dtd/";

    public XmlDtdAccessor() {
    }

    public String getDTDResourcePath(String fileName) {
        PreconditionUtils.checkArguments(new Object[]{fileName});

        try {
            Path dtdPath = Paths.get(IOUtils.loadResourceURLInClasspath("dtd/" + fileName).toURI());
            return dtdPath.toFile().getAbsolutePath();
        } catch (URISyntaxException var3) {
            throw new ArchivesException("檔案不存在");
        }
    }
}
