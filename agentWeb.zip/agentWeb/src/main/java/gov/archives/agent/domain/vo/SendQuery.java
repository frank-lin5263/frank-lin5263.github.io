package gov.archives.agent.domain.vo;

public class SendQuery {
    private Boolean isMark;
    private Boolean isPrint;
    private Boolean isResend;
    private String documentId;
    private String exchangeId;
    private String orgUnitId;
    private String orgUnitName;
    private String sendStatus;
    private String word;
    private String archiveId;
    private String archiveCatalog;
    private String archiveSpeed;
    private Integer total;
    private Integer confirm;
    private Integer attach;
    private String sendDatTime;
    private String contractInfo;
    private String subject;
    private String[] appendixFileName;
    private String decryptedToken;
    private String fileHash;

    public SendQuery() {
    }

    public Boolean getMark() {
        return this.isMark;
    }

    public void setMark(Boolean mark) {
        this.isMark = mark;
    }

    public Boolean getPrint() {
        return this.isPrint;
    }

    public void setPrint(Boolean print) {
        this.isPrint = print;
    }

    public Boolean getResend() {
        return this.isResend;
    }

    public void setResend(Boolean resend) {
        this.isResend = resend;
    }

    public String getDocumentId() {
        return this.documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getExchangeId() {
        return this.exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getOrgUnitName() {
        return this.orgUnitName;
    }

    public void setOrgUnitName(String orgUnitName) {
        this.orgUnitName = orgUnitName;
    }

    public String getSendStatus() {
        return this.sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus;
    }

    public String getWord() {
        return this.word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getArchiveCatalog() {
        return this.archiveCatalog;
    }

    public void setArchiveCatalog(String archiveCatalog) {
        this.archiveCatalog = archiveCatalog;
    }

    public String getArchiveSpeed() {
        return this.archiveSpeed;
    }

    public void setArchiveSpeed(String archiveSpeed) {
        this.archiveSpeed = archiveSpeed;
    }

    public String getArchiveId() {
        return this.archiveId;
    }

    public void setArchiveId(String archiveId) {
        this.archiveId = archiveId;
    }

    public Integer getTotal() {
        return this.total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getConfirm() {
        return this.confirm;
    }

    public void setConfirm(Integer confirm) {
        this.confirm = confirm;
    }

    public Integer getAttach() {
        return this.attach;
    }

    public void setAttach(Integer attach) {
        this.attach = attach;
    }

    public String getSendDatTime() {
        return this.sendDatTime;
    }

    public void setSendDatTime(String sendDatTime) {
        this.sendDatTime = sendDatTime;
    }

    public String getContractInfo() {
        return this.contractInfo;
    }

    public void setContractInfo(String contractInfo) {
        this.contractInfo = contractInfo;
    }

    public String getSubject() {
        return this.subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String[] getAppendixFileName() {
        return this.appendixFileName;
    }

    public void setAppendixFileName(String[] appendixFileName) {
        this.appendixFileName = appendixFileName;
    }

    public String getDecryptedToken() {
        return this.decryptedToken;
    }

    public void setDecryptedToken(String decryptedToken) {
        this.decryptedToken = decryptedToken;
    }

    public String getFileHash() {
        return this.fileHash;
    }

    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public static final class Builder {
        private Boolean isMark;
        private Boolean isPrint;
        private Boolean isResend;
        private String documentId;
        private String exchangeId;
        private String orgUnitId;
        private String orgUnitName;
        private String sendStatus;
        private String word;
        private String archiveId;
        private String archiveCatalog;
        private String archiveSpeed;
        private Integer total;
        private Integer confirm;
        private Integer attach;
        private String sendDatTime;
        private String contractInfo;
        private String subject;
        private String[] appendixFileName;
        private String decryptedToken;
        private String fileHash;

        private Builder() {
        }

        public static SendQuery.Builder create() {
            return new SendQuery.Builder();
        }

        public SendQuery build() {
            SendQuery entity = new SendQuery();
            entity.setMark(this.isMark);
            entity.setPrint(this.isPrint);
            entity.setResend(this.isResend);
            entity.setDocumentId(this.documentId);
            entity.setExchangeId(this.exchangeId);
            entity.setOrgUnitId(this.orgUnitId);
            entity.setOrgUnitName(this.orgUnitName);
            entity.setSendStatus(this.sendStatus);
            entity.setWord(this.word);
            entity.setArchiveId(this.archiveId);
            entity.setArchiveCatalog(this.archiveCatalog);
            entity.setArchiveSpeed(this.archiveSpeed);
            entity.setTotal(this.total);
            entity.setConfirm(this.confirm);
            entity.setAttach(this.attach);
            entity.setSendDatTime(this.sendDatTime);
            entity.setContractInfo(this.contractInfo);
            entity.setSubject(this.subject);
            entity.setAppendixFileName(this.appendixFileName);
            entity.setDecryptedToken(this.decryptedToken);
            entity.setFileHash(this.fileHash);
            return entity;
        }

        public SendQuery.Builder setMark(Boolean mark) {
            this.isMark = mark;
            return this;
        }

        public SendQuery.Builder setPrint(Boolean print) {
            this.isPrint = print;
            return this;
        }

        public SendQuery.Builder setResend(Boolean resend) {
            this.isResend = resend;
            return this;
        }

        public SendQuery.Builder setDocumentId(String documentId) {
            this.documentId = documentId;
            return this;
        }

        public SendQuery.Builder setExchangeId(String exchangeId) {
            this.exchangeId = exchangeId;
            return this;
        }

        public SendQuery.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public SendQuery.Builder setOrgUnitName(String orgUnitName) {
            this.orgUnitName = orgUnitName;
            return this;
        }

        public SendQuery.Builder setSendStatus(String sendStatus) {
            this.sendStatus = sendStatus;
            return this;
        }

        public SendQuery.Builder setWord(String word) {
            this.word = word;
            return this;
        }

        public SendQuery.Builder setArchiveId(String archiveId) {
            this.archiveId = archiveId;
            return this;
        }

        public SendQuery.Builder setArchiveSpeed(String archiveSpeed) {
            this.archiveSpeed = archiveSpeed;
            return this;
        }

        public SendQuery.Builder setArchiveCatalog(String archiveCatalog) {
            this.archiveCatalog = archiveCatalog;
            return this;
        }

        public SendQuery.Builder setTotal(Integer total) {
            this.total = total;
            return this;
        }

        public SendQuery.Builder setConfirm(Integer confirm) {
            this.confirm = confirm;
            return this;
        }

        public SendQuery.Builder setAttach(Integer attach) {
            this.attach = attach;
            return this;
        }

        public SendQuery.Builder setSendDatTime(String sendDatTime) {
            this.sendDatTime = sendDatTime;
            return this;
        }

        public SendQuery.Builder setContractInfo(String contractInfo) {
            this.contractInfo = contractInfo;
            return this;
        }

        public SendQuery.Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public SendQuery.Builder setAppendixFileName(String[] appendixFileName) {
            this.appendixFileName = appendixFileName;
            return this;
        }

        public SendQuery.Builder setDecryptedToken(String decryptedToken) {
            this.decryptedToken = decryptedToken;
            return this;
        }

        public SendQuery.Builder setFileHash(String fileHash) {
            this.fileHash = fileHash;
            return this;
        }
    }
}
