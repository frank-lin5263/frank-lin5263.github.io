package gov.archives.agent.mapper;

import java.io.Serializable;

public interface CommadnRepository<T, ID extends Serializable> extends Repository<T, ID> {
    void save(T var1);

    void update(T var1);

    void remove(T var1);
}
