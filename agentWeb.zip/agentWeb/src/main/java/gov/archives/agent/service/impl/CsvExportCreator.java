package gov.archives.agent.service.impl;

import gov.archives.agent.service.ExportCsvFileApi;

public abstract class CsvExportCreator {
    public CsvExportCreator() {
    }

    public abstract <T extends ExportCsvFileApi> T createCsvReportFactory(Class<T> var1);
}
