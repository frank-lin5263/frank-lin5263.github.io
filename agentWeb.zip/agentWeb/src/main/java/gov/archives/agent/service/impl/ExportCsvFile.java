package gov.archives.agent.service.impl;

import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.fasterxml.jackson.dataformat.csv.CsvSchema.Builder;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import org.iii.common.util.FileSystemUtils;

public class ExportCsvFile {
    private int BUFFER_SIZE = 2048;
    private TemplateDocumentAccessor documentAccessor = new TemplateDocumentAccessor();

    public ExportCsvFile() {
    }

    protected SequenceWriter createSequenceWriter(CsvSchema schema, File csvTemp, Class<?> classType) throws IOException {
        BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(csvTemp), this.BUFFER_SIZE);
        OutputStreamWriter streamWriter = new OutputStreamWriter(outputStream, "UTF-8");
        return (new CsvMapper()).writerWithDefaultPrettyPrinter().with(schema).forType(classType).writeValues(streamWriter);
    }

    protected CsvSchema buildCsvSchema(List<String> headers) {
        Builder builder = CsvSchema.builder();

        String header;
        for(Iterator var3 = headers.iterator(); var3.hasNext(); builder = builder.addColumn(header)) {
            header = (String)var3.next();
        }

        CsvSchema schema = builder.setLineSeparator("\r\n").setUseHeader(true).build();
        return schema;
    }

    protected File getCsvTempFile(String account) {
        Path accountPath = this.documentAccessor.getTempPath("CsvTemp").resolve(account);
        FileSystemUtils.checkFolder(accountPath);
        File csvTemp = accountPath.resolve("temp.csv").toFile();
        return csvTemp;
    }
}
