package gov.archives.agent.domain.vo;

public class CommandParams {
    private String name;
    private String sessionId;
    private String signToken;

    public CommandParams() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSignToken() {
        return this.signToken;
    }

    public void setSignToken(String signToken) {
        this.signToken = signToken;
    }
}

