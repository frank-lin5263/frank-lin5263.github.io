package gov.archives.agent.message;

public class ErrorCode {
    public static final String FILE_FORMAT_NOT_SUPPORT = "AG0000";
    public static final String SESSION_TIME_OUT = "AG0001";
    public static final String CODE_DATA_VALIDATION_ERROR = "AG0002";

    public ErrorCode() {
    }
}
