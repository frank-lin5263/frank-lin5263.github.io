package gov.archives.agent.message;

import java.util.HashMap;
import java.util.Map;

public class ErrorMessage {
    private static Map<String, String> messages = new HashMap();
    public static final String MESSAGE_GEN_HASH_FROM_FILE_ERROR = "產生 Hash 失敗";
    public static final String MESSAGE_FILE_RENAME_ERROR = "檔案更名錯誤";
    public static final String MESSAGE_FILE_IS_NOT_EXIXT_ERROR = "檔案不存在";
    public static final String MESSAGE_DATA_VALIDATION_ERROR = "資料格式驗證錯誤";

    public ErrorMessage() {
    }

    public static String findByCode(String errorCode) {
        return messages.containsKey(errorCode) ? (String)messages.get(errorCode) : "未定義訊息";
    }

    static {
        messages.put("AG0000", "[%s]檔案格式不支援");
        messages.put("AG0001", "[%s]連線逾時");
        messages.put("AG0002", "資料格式驗證錯誤");
    }
}
