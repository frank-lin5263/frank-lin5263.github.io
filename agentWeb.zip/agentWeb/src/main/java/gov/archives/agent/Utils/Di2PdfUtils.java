package gov.archives.agent.Utils;

import gov.archives.agent.bean.SchroDInger;
import java.io.File;
import java.nio.file.Path;
import org.apache.commons.lang3.StringUtils;
import org.iii.common.conf.CommonConfig;
import org.iii.common.util.PreconditionUtils;

public abstract class Di2PdfUtils {
    private static final String DTD_HEADLINE = "<!DOCTYPE";

    private Di2PdfUtils() {
    }

    public static String getXslName(String dtdPath) {
        return dtdPath.replace(".dtd", ".xsl");
    }

    public static boolean isHeadLine(String diStream) {
        return StringUtils.trimToEmpty(diStream).contains("<!DOCTYPE");
    }

    public static File getKAIUFontFile() {
        return buildFilePath("font", "kaiu.ttf").toFile();
    }

    public static File getTemplateFile(String fileName) {
        PreconditionUtils.checkArguments(new Object[]{fileName});
        return buildFilePath("dtd", fileName).toFile();
    }

    public static File getTemplateFile(String folder, String fileName) {
        PreconditionUtils.checkArguments(new Object[]{folder, fileName});
        return buildFilePath("dtd", folder, fileName).toFile();
    }

    public static File getTemplateFile(SchroDInger schroDInger) {
        PreconditionUtils.checkArguments(new Object[]{schroDInger.getXslYear(), schroDInger.getXslName()});
        return getTemplateFile(schroDInger.getXslYear(), schroDInger.getXslName());
    }

    public static File getExchangeImage() {
        return getTemplateFile("ExchangeH.png");
    }

    public static File createTempFile(String tempName) {
        PreconditionUtils.checkArguments(new Object[]{tempName});
        File tempFile = buildFilePath("tmp", tempName).toFile();
        if (tempFile.exists()) {
            tempFile.deleteOnExit();
        }

        return tempFile;
    }

    private static Path buildFilePath(String... paths) {
        Path rootPath = CommonConfig.getRuntimeRoot(Di2PdfUtils.class);
        String[] var2 = paths;
        int var3 = paths.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            String pathName = var2[var4];
            rootPath = rootPath.resolve(pathName);
        }

        return rootPath;
    }
}

