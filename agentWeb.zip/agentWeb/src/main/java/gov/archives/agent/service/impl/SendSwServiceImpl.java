package gov.archives.agent.service.impl;

import gov.archives.agent.accessor.XmlDtdAccessor;
import gov.archives.agent.domain.entity.ReceiveEntity;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

@Service
public class SendSwServiceImpl extends DefaultHandler {
    private static final String TAG_FIND = "true";
    @Autowired
    private XmlDtdAccessor dtdAccessor;
    private List<ReceiveEntity> formEntities = new ArrayList();

    public SendSwServiceImpl() {
    }

    private void addEntity() {
        this.formEntities.add(new ReceiveEntity());
    }

    private ReceiveEntity getEntity() {
        return (ReceiveEntity)this.formEntities.get(this.formEntities.size() - 1);
    }

    public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
        String filePath = this.dtdAccessor.getDTDResourcePath(FilenameUtils.getName(systemId));
        return new InputSource(filePath);
    }

    public ReceiveEntity[] getFormEntity() {
        this.formEntities.remove(this.formEntities.size() - 1);
        return (ReceiveEntity[])this.formEntities.toArray(new ReceiveEntity[this.formEntities.size()]);
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("交換表單")) {
            this.addEntity();
        } else if (qName.equalsIgnoreCase("全銜")) {
            this.getEntity().setOrgUnitName("true");
        } else if (qName.equalsIgnoreCase("機關代碼")) {
            this.getEntity().setOrgId("true");
        } else if (qName.equalsIgnoreCase("含附件")) {
            this.getEntity().setAppendFile(true);
        }

    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equalsIgnoreCase("含附件")) {
            this.addEntity();
        }

    }

    public void characters(char[] ch, int start, int length) throws SAXException {
        if (this.getEntity().getOrgUnitName().equals("true")) {
            this.getEntity().setOrgUnitName(new String(ch, start, length));
        } else if (this.getEntity().getOrgId().equals("true")) {
            if (length > 10) {
                String orgUnitId = new String(ch, start, length);
                this.getEntity().setOrgId(orgUnitId.substring(0, 10));
                this.getEntity().setUnitId(orgUnitId.substring(11));
            } else {
                this.getEntity().setOrgId(new String(ch, start, length));
                this.getEntity().setUnitId("");
            }
        }

    }
}
