package gov.archives.agent.domain.vo;

public class ConfirmSignHashPackage {
    private String documentId;
    private String signature;

    public ConfirmSignHashPackage() {
    }

    public String getDocumentId() {
        return this.documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getSignature() {
        return this.signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
}
