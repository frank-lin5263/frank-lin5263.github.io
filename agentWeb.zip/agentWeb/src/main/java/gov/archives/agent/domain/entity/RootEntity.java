package gov.archives.agent.domain.entity;

import java.sql.Timestamp;
import java.util.UUID;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RootEntity {
    private UUID documentId;
    private Timestamp createdTime;
    private Timestamp modifiedTime;
    private String creatorAccount;
    private String modifierAccount;

    public RootEntity() {
    }

    public UUID getDocumentId() {
        return this.documentId;
    }

    public void setDocumentId(UUID documentId) {
        this.documentId = documentId;
    }

    public Timestamp getCreatedTime() {
        return this.createdTime;
    }

    public void setCreatedTime(Timestamp createdTime) {
        this.createdTime = createdTime;
    }

    public Timestamp getModifiedTime() {
        return this.modifiedTime;
    }

    public void setModifiedTime(Timestamp modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getCreatorAccount() {
        return this.creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }

    public String getModifierAccount() {
        return this.modifierAccount;
    }

    public void setModifierAccount(String modifierAccount) {
        this.modifierAccount = modifierAccount;
    }

    public void initDocumentId() {
        this.documentId = UUID.randomUUID();
    }

    public void initSave(String creator, UUID documentId) {
        this.initSave(creator);
        this.documentId = documentId;
    }

    public void initSave(String creator) {
        this.creatorAccount = creator;
        this.modifierAccount = creator;
        this.createdTime = new Timestamp(System.currentTimeMillis());
        this.modifiedTime = new Timestamp(System.currentTimeMillis());
        this.documentId = UUID.randomUUID();
    }

    public void initUpdate(String modifier) {
        this.modifierAccount = modifier;
        this.modifiedTime = new Timestamp(System.currentTimeMillis());
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}

