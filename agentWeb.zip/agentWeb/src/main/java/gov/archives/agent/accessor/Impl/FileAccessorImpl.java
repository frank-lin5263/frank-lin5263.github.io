package gov.archives.agent.accessor.Impl;

import gov.archives.agent.accessor.FileAccessor;
import java.io.File;
import java.util.Map;
import org.iii.common.util.ZipUncompressor;
import org.springframework.stereotype.Component;

@Component
public class FileAccessorImpl implements FileAccessor {
    public FileAccessorImpl() {
    }

    public Map<String, byte[]> uncompressZipFile(File zipFile) {
        return ZipUncompressor.uncompressZipToData(zipFile).setCharset("utf-8").commit();
    }

    public Map<String, byte[]> uncompressZipFile(File sendZip, String password) {
        return ZipUncompressor.uncompressZipToData(sendZip).setCharset("utf-8").setPassword(password).commit();
    }
}
