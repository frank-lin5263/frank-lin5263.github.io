package gov.archives.agent.Utils;

import java.io.File;
import java.util.List;
import org.iii.common.util.FileCompressor;

public class CompressUtils {
    public CompressUtils() {
    }

    public static void compressFilesToZip(List<File> sourceFiles, File outputZipFile, String psw) {
        FileCompressor.createCompressFile().addAllSourceFiles(sourceFiles).setTargetFile(outputZipFile).setPassword(psw).setCharset("UTF-8").compress();
    }

    public static void compressFilesToZip(List<File> sourceFiles, File outputZipFile) {
        FileCompressor.createCompressFile().addAllSourceFiles(sourceFiles).setTargetFile(outputZipFile).setCharset("UTF-8").compress();
    }

    public static void compressFileToZip(File targetFile, File outputZipFile, String psw) {
        FileCompressor.createCompressFile().addSourceFile(targetFile).setTargetFile(outputZipFile).setPassword(psw).setCharset("UTF-8").compress();
    }
}
