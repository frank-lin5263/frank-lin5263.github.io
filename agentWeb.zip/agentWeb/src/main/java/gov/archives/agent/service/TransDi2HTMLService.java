package gov.archives.agent.service;

import java.io.File;

public interface TransDi2HTMLService {
    File transDi2HTML(File var1, String var2);
}
