package gov.archives.agent.service.impl;

import gov.archives.agent.messaging.MessageReceiver;
import gov.archives.agent.messaging.MessageSender;
import gov.archives.core.exception.ArchivesException;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.InitConfirmResult;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public abstract class CommandServiceImpl {
    @Autowired
    private MessageSender messageSender;
    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private ActiveMQQueue commandDestination;
    @Autowired
    private ActiveMQQueue resultDestination;

    public CommandServiceImpl() {
    }

    public MessageSender getMessageSender() {
        return this.messageSender;
    }

    public abstract <R> CommandResult<R> execute(Object var1, String var2, InitConfirmResult var3, String var4);

    protected void sendCommand(Object command) {
        this.messageSender.sendMessage(this.commandDestination, command);
    }

    protected <R> CommandResult<R> receiveCommand() {
        CommandResult<R> receiveResult = (CommandResult)this.messageReceiver.receiveMessage(this.resultDestination);
        if (receiveResult == null) {
            throw new ArchivesException("receiveMessage exception");
        } else {
            return receiveResult;
        }
    }
}
