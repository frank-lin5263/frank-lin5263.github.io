package gov.archives.agent.domain.vo;

import java.util.UUID;

public class SystemCommand<P> {
    private String name;
    private UUID id;
    private String sessionId;
    private String tokenSig;
    private P parameters;

    public SystemCommand() {
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return this.id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getTokenSig() {
        return this.tokenSig;
    }

    public void setTokenSig(String tokenSig) {
        this.tokenSig = tokenSig;
    }

    public P getParameters() {
        return this.parameters;
    }

    public void setParameters(P parameters) {
        this.parameters = parameters;
    }

    public static final class Builder<P> {
        private String name;
        private UUID id;
        private String sessionId;
        private String tokenSig;
        private P parameters;

        public static <P> SystemCommand.Builder<P> createParameter(P parameters) {
            return new SystemCommand.Builder(parameters);
        }

        private Builder(P parameters) {
            this.parameters = parameters;
        }

        public SystemCommand<P> build() {
            SystemCommand<P> baseParameter = new SystemCommand();
            baseParameter.setName(this.name);
            baseParameter.setId(this.id);
            baseParameter.setSessionId(this.sessionId);
            baseParameter.setTokenSig(this.tokenSig);
            baseParameter.setParameters(this.parameters);
            return baseParameter;
        }

        public SystemCommand.Builder setName(String name) {
            this.name = name;
            return this;
        }

        public SystemCommand.Builder setId(UUID id) {
            this.id = id;
            return this;
        }

        public SystemCommand.Builder setSessionId(String sessionId) {
            this.sessionId = sessionId;
            return this;
        }

        public SystemCommand.Builder setTokenSig(String tokenSig) {
            this.tokenSig = tokenSig;
            return this;
        }
    }
}
