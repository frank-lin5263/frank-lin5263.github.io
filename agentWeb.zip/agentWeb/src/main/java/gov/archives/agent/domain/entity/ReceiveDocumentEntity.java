package gov.archives.agent.domain.entity;

import java.sql.Timestamp;
import org.apache.ibatis.type.Alias;

@Alias("ReceiveDocInfo")
public class ReceiveDocumentEntity extends RootEntity {
    private String processId;
    private String sendOrgId;
    private String sendUnitId;
    private String sendOrgName;
    private Integer statusCode;
    private String docWord;
    private String applicationId;
    private String docSpeed;
    private String docSubject;
    private String docCatalog;
    private String contractInfo;
    private Timestamp docDate;
    private Timestamp userReceiveTime;
    private Timestamp userConfirmTime;
    private Timestamp userRejectTime;
    private String rejectReason;
    private String[] appendixFile;

    public ReceiveDocumentEntity() {
    }

    public String getProcessId() {
        return this.processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public String getSendOrgId() {
        return this.sendOrgId;
    }

    public void setSendOrgId(String sendOrgId) {
        this.sendOrgId = sendOrgId;
    }

    public String getSendUnitId() {
        return this.sendUnitId;
    }

    public void setSendUnitId(String sendUnitId) {
        this.sendUnitId = sendUnitId;
    }

    public String getSendOrgName() {
        return this.sendOrgName;
    }

    public void setSendOrgName(String sendOrgName) {
        this.sendOrgName = sendOrgName;
    }

    public Integer getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getDocWord() {
        return this.docWord;
    }

    public void setDocWord(String docWord) {
        this.docWord = docWord;
    }

    public String getApplicationId() {
        return this.applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getDocSpeed() {
        return this.docSpeed;
    }

    public void setDocSpeed(String docSpeed) {
        this.docSpeed = docSpeed;
    }

    public String getDocSubject() {
        return this.docSubject;
    }

    public void setDocSubject(String docSubject) {
        this.docSubject = docSubject;
    }

    public String getDocCatalog() {
        return this.docCatalog;
    }

    public void setDocCatalog(String docCatalog) {
        this.docCatalog = docCatalog;
    }

    public String getContractInfo() {
        return this.contractInfo;
    }

    public void setContractInfo(String contractInfo) {
        this.contractInfo = contractInfo;
    }

    public Timestamp getDocDate() {
        return this.docDate;
    }

    public void setDocDate(Timestamp docDate) {
        this.docDate = docDate;
    }

    public Timestamp getUserReceiveTime() {
        return this.userReceiveTime;
    }

    public void setUserReceiveTime(Timestamp userReceiveTime) {
        this.userReceiveTime = userReceiveTime;
    }

    public Timestamp getUserConfirmTime() {
        return this.userConfirmTime;
    }

    public void setUserConfirmTime(Timestamp userConfirmTime) {
        this.userConfirmTime = userConfirmTime;
    }

    public Timestamp getUserRejectTime() {
        return this.userRejectTime;
    }

    public void setUserRejectTime(Timestamp userRejectTime) {
        this.userRejectTime = userRejectTime;
    }

    public String getRejectReason() {
        return this.rejectReason;
    }

    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    public String[] getAppendixFile() {
        return this.appendixFile;
    }

    public void setAppendixFile(String[] appendixFile) {
        this.appendixFile = appendixFile;
    }

    public static final class Builder {
        private String processId;
        private String sendOrgId;
        private String sendUnitId;
        private String sendOrgName;
        private Integer statusCode;
        private String docWord;
        private String applicationId;
        private String docSpeed;
        private String docSubject;
        private String docCatalog;
        private String contractInfo;
        private Timestamp docDate;
        private Timestamp userReceiveTime;
        private Timestamp userConfirmTime;
        private Timestamp userRejectTime;
        private String rejectReason;
        private String[] appendixFile;

        private Builder() {
        }

        public static ReceiveDocumentEntity.Builder create() {
            return new ReceiveDocumentEntity.Builder();
        }

        public ReceiveDocumentEntity build() {
            ReceiveDocumentEntity entity = new ReceiveDocumentEntity();
            entity.setProcessId(this.processId);
            entity.setSendOrgId(this.sendOrgId);
            entity.setSendUnitId(this.sendUnitId);
            entity.setSendOrgName(this.sendOrgName);
            entity.setStatusCode(this.statusCode);
            entity.setDocWord(this.docWord);
            entity.setApplicationId(this.applicationId);
            entity.setDocSpeed(this.docSpeed);
            entity.setDocSubject(this.docSubject);
            entity.setDocCatalog(this.docCatalog);
            entity.setContractInfo(this.contractInfo);
            entity.setDocDate(this.docDate);
            entity.setUserReceiveTime(this.userReceiveTime);
            entity.setUserConfirmTime(this.userConfirmTime);
            entity.setUserRejectTime(this.userRejectTime);
            entity.setRejectReason(this.rejectReason);
            entity.setAppendixFile(this.appendixFile);
            return entity;
        }

        public ReceiveDocumentEntity.Builder setProcessId(String processId) {
            this.processId = processId;
            return this;
        }

        public ReceiveDocumentEntity.Builder setSendOrgId(String sendOrgId) {
            this.sendOrgId = sendOrgId;
            return this;
        }

        public ReceiveDocumentEntity.Builder setSendUnitId(String sendUnitId) {
            this.sendUnitId = sendUnitId;
            return this;
        }

        public ReceiveDocumentEntity.Builder setSendOrgName(String sendOrgName) {
            this.sendOrgName = sendOrgName;
            return this;
        }

        public ReceiveDocumentEntity.Builder setStatusCode(Integer statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        public ReceiveDocumentEntity.Builder setDocWord(String docWord) {
            this.docWord = docWord;
            return this;
        }

        public ReceiveDocumentEntity.Builder setApplicationId(String applicationId) {
            this.applicationId = applicationId;
            return this;
        }

        public ReceiveDocumentEntity.Builder setDocSpeed(String docSpeed) {
            this.docSpeed = docSpeed;
            return this;
        }

        public ReceiveDocumentEntity.Builder setDocSubject(String docSubject) {
            this.docSubject = docSubject;
            return this;
        }

        public ReceiveDocumentEntity.Builder setDocCatalog(String docCatalog) {
            this.docCatalog = docCatalog;
            return this;
        }

        public ReceiveDocumentEntity.Builder setContractInfo(String contractInfo) {
            this.contractInfo = contractInfo;
            return this;
        }

        public ReceiveDocumentEntity.Builder setDocDate(Timestamp docDate) {
            this.docDate = docDate;
            return this;
        }

        public ReceiveDocumentEntity.Builder setUserReceiveTime(Timestamp userReceiveTime) {
            this.userReceiveTime = userReceiveTime;
            return this;
        }

        public ReceiveDocumentEntity.Builder setUserConfirmTime(Timestamp userConfirmTime) {
            this.userConfirmTime = userConfirmTime;
            return this;
        }

        public ReceiveDocumentEntity.Builder setUserRejectTime(Timestamp userRejectTime) {
            this.userRejectTime = userRejectTime;
            return this;
        }

        public ReceiveDocumentEntity.Builder setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
            return this;
        }

        public ReceiveDocumentEntity.Builder setAppendixFile(String[] appendixFile) {
            this.appendixFile = appendixFile;
            return this;
        }
    }
}

