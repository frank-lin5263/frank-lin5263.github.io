package gov.archives.agent.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("StoredFile")
public class StoredFileEntity extends RootEntity {
    private String orgUnitId;
    private String fileHash;
    private String filePassword;

    public StoredFileEntity() {
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getFileHash() {
        return this.fileHash;
    }

    public void setFileHash(String fileHash) {
        this.fileHash = fileHash;
    }

    public String getFilePassword() {
        return this.filePassword;
    }

    public void setFilePassword(String filePassword) {
        this.filePassword = filePassword;
    }

    public static final class Builder {
        private String orgUnitId;
        private String fileHash;
        private String filePassword;

        private Builder() {
        }

        public static StoredFileEntity.Builder create() {
            return new StoredFileEntity.Builder();
        }

        public StoredFileEntity build() {
            StoredFileEntity entity = new StoredFileEntity();
            entity.setOrgUnitId(this.orgUnitId);
            entity.setFileHash(this.fileHash);
            entity.setFilePassword(this.filePassword);
            return entity;
        }

        public StoredFileEntity.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public StoredFileEntity.Builder setFileHash(String fileHash) {
            this.fileHash = fileHash;
            return this;
        }

        public StoredFileEntity.Builder setFilePassword(String filePassword) {
            this.filePassword = filePassword;
            return this;
        }
    }
}

