package gov.archives.agent.conf;

public class CommandNameList {
    public static final String SYSTEM_SHUTDOWN = "System#Shutdown";
    public static final String INIT_SIGN_IN = "InitExchange#SignIn";
    public static final String INIT_CONFIRM = "InitExchange#Confirm";
    public static final String SEND_PROCESS = "SendDocument#Process";
    public static final String SEND_MSREQUEST = "SendDocument#MSRequest";
    public static final String SEND_MHREQUEST = "SendDocument#MHRequest";
    public static final String SEND_MSENCRYPTED = "SendDocument#MSEncrypted";
    public static final String SEND_MHENCRYPTED = "SendDocument#MHEncrypted";
    public static final String SEND_MSREQUEST_AGENT = "SendDocument#MSRequestAgent";
    public static final String SEND_MSENCRYPTED_AGENT = "SendDocument#MSEncryptedAgent";
    public static final String SEND_OUT = "SendDocument#SendOut";
    public static final String SEND_QUERY = "SendDocument#Query";
    public static final String SEND_SUBROGATIONS_QUERY = "SendDocument#SubrogationQuery";
    public static final String SEND_CHECKLIST = "SendDocument#CheckList";
    public static final String RECEIVE_REQUEST = "ReceiveDocument#Request";
    public static final String RECEIVE_MSREQUEST = "ReceiveDocument#MSRequest";
    public static final String RECEIVE_MHREQUEST = "ReceiveDocument#MHRequest";
    public static final String RECEIVE_MSDECRYPTED = "ReceiveDocument#MSDecrypted";
    public static final String RECEIVE_MHDECRYPTED = "ReceiveDocument#MHDecrypted";
    public static final String RECEIVE_MSREQUEST_AGENT = "ReceiveDocument#MSRequestAgent";
    public static final String RECEIVE_MSDECRYPTED_AGENT = "ReceiveDocument#MSDecryptedAgent";
    public static final String RECEIVE_RECEIVE = "ReceiveDocument#Receive";
    public static final String RECEIVE_CONFIRM = "ReceiveDocument#Confirm";
    public static final String RECEIVE_REJECT_REQUEST = "ReceiveDocument#RejectRequest";
    public static final String RECEIVE_REJECT = "ReceiveDocument#Reject";
    public static final String RECEIVE_QUERY = "ReceiveDocument#Query";
    public static final String RECEIVE_CHECKLIST = "ReceiveDocument#CheckList";
    public static final String DIST_SEND_PROCESS = "SendDistribution#Process";
    public static final String DIST_SEND_MS_ENCRYPTED_AGENT = "SendDistribution#MSEncryptedAgent";
    public static final String DIST_SEND_OUT = "SendDistribution#SendOut";
    public static final String DIST_SEND_QUERY = "SendDistribution#Query";
    public static final String DIST_SEND_UNITS_QUERY = "SendDistribution#UnitsQuery";
    public static final String DIST_SEND_CHECKLIST = "SendDistribution#CheckList";
    public static final String DIST_RECEIVE_REQUEST = "ReceiveDistribution#Request";
    public static final String DIST_RECEIVE_RECEIVE = "ReceiveDistribution#Receive";
    public static final String DIST_RECEIVE_CONFIRM = "ReceiveDistribution#Confirm";
    public static final String DIST_RECEIVE_MSDECRYPTED_AGENT = "ReceiveDistribution#MSDecryptedAgent";
    public static final String DIST_RECEIVE_REJECT_REQUEST = "ReceiveDistribution#RejectRequest";
    public static final String DIST_RECEIVE_REJECT = "ReceiveDistribution#Reject";
    public static final String DIST_RECEIVE_CHECKLIST = "ReceiveDistribution#CheckList";
    public static final String SYSTEM_LOGOUT = "System#Logout";
    public static final String KEY_ID = "id";
    public static final String KEY_NAME = "name";
    public static final String KEY_ORGID = "orgId";
    public static final String KEY_SESSION_ID = "sessionId";
    public static final String KEY_TOKEN = "token";
    public static final String KEY_TOKENSIG = "tokenSig";
    public static final String KEY_PARAMETERS = "parameters";
    public static final String TEST_ECHO = "Test#Echo";

    public CommandNameList() {
    }
}

