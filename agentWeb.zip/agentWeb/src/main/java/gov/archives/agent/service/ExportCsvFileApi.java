package gov.archives.agent.service;

import java.io.File;
import java.util.List;

public interface ExportCsvFileApi {
    File exportCsvFile(String var1, List<?> var2, Class<?> var3);
}
