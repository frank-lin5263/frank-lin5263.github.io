package gov.archives.agent.service.impl;

import gov.archives.agent.html.DiMapper;
import gov.archives.agent.service.TransDi2HTMLService;
import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.IOException;
import javax.xml.transform.TransformerException;
import org.springframework.stereotype.Service;

@Service
public class TransDi2HTMLServiceImpl implements TransDi2HTMLService {
    public TransDi2HTMLServiceImpl() {
    }

    public File transDi2HTML(File diFile, String htmlTemp) {
        try {
            return DiMapper.getInstance().transDiToHtml(diFile, "TEST", htmlTemp);
        } catch (TransformerException | IOException var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }
}

