package gov.archives.agent.conf;

import java.util.HashMap;
import java.util.Map;

public class ReceiveStatus {
    private static Map<Integer, String> receiveStatus = new HashMap();
    public static final Integer ARRIVE = 0;
    public static final String DOC_ARRIVE = "公文到達";
    public static final Integer DOWMLOAD_PROCESS = 1;
    public static final String DOC_DOWNLOAD_PROCESS = "收文下載處理中";
    public static final Integer RECEIVE_FINISH = 2;
    public static final String DOC_RECEIVE_FINISH = "收文完成";
    public static final Integer CHECK_FAILED = -1;
    public static final String DOC_CHECK_FAILED = "收文異常";
    public static final String SYSTEM_CONFIRM = "系統確認";
    public static final String CLIENT_CONFIRM = "用戶確認";
    public static final String CLIENT_REJECT = "用戶退文";

    public ReceiveStatus() {
    }

    public static String findByCode(Integer statusCode) {
        return receiveStatus.containsKey(statusCode) ? (String)receiveStatus.get(statusCode) : "未定義訊息";
    }

    static {
        receiveStatus.put(ARRIVE, "公文到達");
        receiveStatus.put(DOWMLOAD_PROCESS, "收文下載處理中");
        receiveStatus.put(RECEIVE_FINISH, "收文完成");
        receiveStatus.put(CHECK_FAILED, "收文異常");
    }
}

