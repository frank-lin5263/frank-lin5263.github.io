package gov.archives.agent.controller;

import gov.archives.agent.domain.vo.ConfirmParams;
import gov.archives.agent.domain.vo.SignHashPackage;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.SignInMeta;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import gov.archives.jagent.domain.result.InitConfirmResult;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/initExchange"})
public class InitExchangeController {
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public InitExchangeController() {
    }

    @RequestMapping(
            value = {"/signIn"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<String>> signInCommand(@RequestBody SignInMeta signInMeta) {
        try {
            String b64Hash = this.commandInvokerFacade.singInCommand(signInMeta.getOrgUnitId(), signInMeta.getCardNumber());
            RestResponse<String> restResponse = ResponseBuilder.createResponseByData(b64Hash).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/confirm"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<InitConfirmResult>> confirmCommand(@RequestBody ConfirmParams params) {
        try {
            SignHashPackage hashPackage = params.getHashPackage();
            PreconditionUtils.checkArguments(new Object[]{hashPackage});
            SignInMeta signInMeta = params.getSignInMeta();
            PreconditionUtils.checkArguments(new Object[]{signInMeta});
            InitConfirmResult confirmResult = this.commandInvokerFacade.confirmCommand(hashPackage, signInMeta.getOrgUnitId(), signInMeta.getCardNumber());
            RestResponse<InitConfirmResult> restResponse = ResponseBuilder.createResponseByData(confirmResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var6) {
            throw new ArchivesException(var6.getMessage(), var6.getCause());
        }
    }

    @RequestMapping(
            value = {"/uuidHash"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<String>> getb64KeyHash(@RequestBody String b64DecryptedToken) {
        try {
            String b64Token = this.commandInvokerFacade.getSignToken(b64DecryptedToken);
            RestResponse<String> restResponse = ResponseBuilder.createResponseByData(b64Token).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }
}
