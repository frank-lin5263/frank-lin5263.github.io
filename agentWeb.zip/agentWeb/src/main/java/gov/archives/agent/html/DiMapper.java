package gov.archives.agent.html;

import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.accessor.XmlDtdAccessor;
import gov.archives.agent.bean.SchroDInger;
import gov.archives.xmldoc.domain.BaseDocument;
import gov.archives.xmldoc.processor.XmlDocumentReader;
import gov.archives.xmldoc.processor.XmlDocumentReaders;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.dom4j.io.DocumentSource;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.UniversalCharsetUtils;

public class DiMapper {
    private static final String DOC_SEAL_TAG = "id=\"doc-seal-tag\"";
    private static DiMapper diMapper = null;
    private TemplateDocumentAccessor documentAccessor = new TemplateDocumentAccessor();
    private XmlDtdAccessor xmlDtdAccessor = new XmlDtdAccessor();

    public DiMapper() {
    }

    public static synchronized DiMapper getInstance() {
        if (null == diMapper) {
            diMapper = new DiMapper();
        }

        return diMapper;
    }

    public File transDiToHtml(File diFile, String encodeImg, String htmlTemp) throws IOException, TransformerException {
        PreconditionUtils.checkArguments(new Object[]{diFile, encodeImg});
        File tempHTML = this.documentAccessor.getHtmlTempFile(htmlTemp);
        this.transform(diFile, tempHTML);
        this.addSealImage(tempHTML, encodeImg);
        return tempHTML;
    }

    private void transform(File diFile, File tempHTML) throws IOException, TransformerException {
        TransformerFactory tFactory = TransformerFactory.newInstance();

        try {
            SchroDInger schroDInger = SchroDInger.build(diFile);
            File dtdFile = new File(this.xmlDtdAccessor.getDTDResourcePath(schroDInger.getXslName()));
            Transformer transformer = tFactory.newTransformer(new StreamSource(dtdFile));
            transformer.transform(this.getDOMSourceFromDiFile(schroDInger.getFormatDiFile()), new StreamResult(new FileOutputStream(tempHTML)));
        } catch (TransformerException var7) {
            throw new TransformerException("Di -> HTML 時發生異常", var7);
        }
    }

    private DocumentSource getDOMSourceFromDiFile(File diFile) {
        XmlDocumentReader<BaseDocument> diReader = XmlDocumentReaders.getDocumentReaderByDocumentType(BaseDocument.class);
        BaseDocument diDOM = (BaseDocument)diReader.readDocumentFromFile(diFile);
        return new DocumentSource(diDOM.getContent());
    }

    private void addSealImage(File tempHTML, String encodeImg) throws IOException {
        FileInputStream fis = null;
        BufferedReader br = null;
        FileOutputStream fos = null;
        BufferedWriter bw = null;

        try {
            fis = new FileInputStream(tempHTML);
            br = new BufferedReader(UniversalCharsetUtils.getUniversalReaderFromInputStream(fis));
            String tmp = IOUtils.readByReader(br, false);
            fos = new FileOutputStream(tempHTML);
            bw = new BufferedWriter(new OutputStreamWriter(fos, "UTF-8"));
            bw.write(tmp.replace("id=\"doc-seal-tag\"", "id=\"doc-seal-tag\" src=\"data:image/png;base64," + encodeImg + "\" "));
        } catch (IOException var11) {
            throw new IOException("插入電子交換印象時發生異常", var11);
        } finally {
            IOUtils.closeWriter(bw);
            IOUtils.closeOutputStream(fos);
            IOUtils.closeReader(br);
            IOUtils.closeInputStream(fis);
        }

    }
}
