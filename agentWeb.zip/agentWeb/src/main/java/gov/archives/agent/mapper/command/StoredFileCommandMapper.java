package gov.archives.agent.mapper.command;

import gov.archives.agent.domain.entity.StoredFileEntity;
import gov.archives.agent.mapper.CommadnRepository;
import java.util.UUID;

public interface StoredFileCommandMapper extends CommadnRepository<StoredFileEntity, UUID> {
}
