package gov.archives.agent.messaging;

import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.jms.BytesMessage;
import javax.jms.MessageProducer;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessageSender {
    @Autowired
    private JmsTemplate jmsTemplate;

    public MessageSender() {
    }

    public void sendMessage(ActiveMQQueue destination, Object command) {
        this.jmsTemplate.convertAndSend(destination, command);
    }

    public void sendFileByByteMessage(ActiveMQQueue destination, File file) {
        this.jmsTemplate.send(destination, (session) -> {
            MessageProducer producer = session.createProducer(destination);
            producer.setDeliveryMode(2);
            BytesMessage message = session.createBytesMessage();

            try {
                InputStream in = new FileInputStream(file);
                byte[] buffer = new byte[2048];

                int count;
                while((count = in.read(buffer)) > 0) {
                    message.writeBytes(buffer, 0, count);
                }

                producer.send(message);
                in.close();
                return message;
            } catch (IOException var8) {
                throw new ArchivesException(var8.getMessage(), var8.getCause());
            }
        });
    }
}
