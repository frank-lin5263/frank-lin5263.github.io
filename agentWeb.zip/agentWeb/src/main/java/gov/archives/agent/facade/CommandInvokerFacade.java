package gov.archives.agent.facade;

import gov.archives.agent.domain.entity.ReceiveDocumentEntity;
import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.vo.DocumentParams;
import gov.archives.agent.domain.vo.ReceiveReceiveVO;
import gov.archives.agent.domain.vo.ReceivedQuery;
import gov.archives.agent.domain.vo.SendQuery;
import gov.archives.agent.domain.vo.SignHashPackage;
import gov.archives.jagent.domain.result.InitConfirmResult;
import gov.archives.jagent.domain.result.ReceiveConfirmResult;
import gov.archives.jagent.domain.result.ReceiveMSDecryptedAgentResult;
import gov.archives.jagent.domain.result.ReceiveRequestResult;
import gov.archives.jagent.domain.result.SendMSRequestAgentResult;
import gov.archives.jagent.domain.result.SendOutResult;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartHttpServletRequest;

public interface CommandInvokerFacade {
    String singInCommand(String var1, String var2);

    InitConfirmResult confirmCommand(SignHashPackage var1, String var2, String var3);

    String getSignToken(String var1);

    ReceiveRequestResult startDocReceive(DocumentParams var1);

    Object executeCommand(DocumentParams var1, String var2);

    ReceiveMSDecryptedAgentResult receiveMSDecryptedAgent(DocumentParams var1);

    ReceiveReceiveVO receiveReceive(DocumentParams var1);

    SendMSRequestAgentResult startSendDocuments(MultipartHttpServletRequest var1);

    SendOutResult saveSendOutResult(DocumentParams var1);

    ReceiveConfirmResult saveReceiveDocumentEntity(DocumentParams var1);

    List<SendDocumentEntity> getSendDocumentEntities();

    List<ReceiveDocumentEntity> getReceiveDocumentEntities();

    List<SendQuery> getSendQueryEntities();

    List<ReceivedQuery> getReceivedQueryEntities(DocumentParams var1);

    void updateReceiveStatus(Integer var1, String var2);

    void setSendEntityStatus(Integer var1, String var2);

    void downloadCsvReport(HttpServletResponse var1, List<?> var2);

    void downloadAllZip(HttpServletResponse var1, String var2);

    void downloadFileName(String var1, String var2, HttpServletResponse var3);

    void transSendDi2HTML(String var1, HttpServletResponse var2);

    void transReceiveDi2HTML(HttpServletResponse var1, String var2, String var3);
}
