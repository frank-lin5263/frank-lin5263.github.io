package gov.archives.agent.domain.entity;

import gov.archives.core.domain.entity.BaseEntity;

public class ReceiveEntity extends BaseEntity {
    private String orgUnitName;
    private String orgId;
    private String unitId;
    private Boolean isAppendFile;

    public ReceiveEntity() {
    }

    public String getOrgUnitName() {
        return this.orgUnitName;
    }

    public void setOrgUnitName(String orgUnitName) {
        this.orgUnitName = orgUnitName;
    }

    public String getOrgId() {
        return this.orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getUnitId() {
        return this.unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public Boolean getAppendFile() {
        return this.isAppendFile;
    }

    public void setAppendFile(Boolean appendFile) {
        this.isAppendFile = appendFile;
    }

    public static final class Builder {
        private String orgUnitName;
        private String orgId;
        private String unitId;
        private Boolean isAppendFile;

        private Builder() {
        }

        public static ReceiveEntity.Builder create() {
            return new ReceiveEntity.Builder();
        }

        public ReceiveEntity build() {
            ReceiveEntity entity = new ReceiveEntity();
            entity.setOrgUnitName(this.orgUnitName);
            entity.setOrgId(this.orgId);
            entity.setUnitId(this.unitId);
            entity.setAppendFile(this.isAppendFile);
            return entity;
        }

        public ReceiveEntity.Builder setOrgUnitName(String orgUnitName) {
            this.orgUnitName = orgUnitName;
            return this;
        }

        public ReceiveEntity.Builder setOrgId(String orgId) {
            this.orgId = orgId;
            return this;
        }

        public ReceiveEntity.Builder setUnitId(String unitId) {
            this.unitId = unitId;
            return this;
        }

        public ReceiveEntity.Builder setAppendFile(Boolean isAppendFile) {
            this.isAppendFile = isAppendFile;
            return this;
        }
    }
}

