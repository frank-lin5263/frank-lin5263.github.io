//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package gov.archives.agent.controller;

import gov.archives.agent.conf.SendStatus;
import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.vo.DocumentParams;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import gov.archives.jagent.domain.result.SendMSEncryptedAgentResult;
import gov.archives.jagent.domain.result.SendMSRequestAgentResult;
import gov.archives.jagent.domain.result.SendOutResult;
import gov.archives.jagent.domain.result.SendQueryResult;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@RestController
@RequestMapping({"/v1/docExchange/sendDocument"})
public class SendDocumentController {
    private static final String PARAMS_QUERY_LIMIT = "limit";
    private static final String PARAMS_QUERY_OFFSET = "offset";
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public SendDocumentController() {
    }

    @RequestMapping(
            value = {"/report"},
            method = {RequestMethod.GET}
    )
    public void csvReport(HttpServletResponse response) {
        try {
            List<SendDocumentEntity> list = this.commandInvokerFacade.getSendDocumentEntities();
            this.commandInvokerFacade.downloadCsvReport(response, list);
        } catch (Exception var3) {
            throw new ArchivesException(var3.getMessage(), var3.getCause());
        }
    }

    @RequestMapping(
            value = {"/list"},
            method = {RequestMethod.GET}
    )
    public ResponseEntity<RestResponse<List<SendDocumentEntity>>> getSendDocumentEntitys() {
        List<SendDocumentEntity> list = this.commandInvokerFacade.getSendDocumentEntities();
        RestResponse<List<SendDocumentEntity>> restResponse = ResponseBuilder.createResponseByData(list).setResultCode(0).setResultMessage("").build();
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    @RequestMapping(
            value = {"/query"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<SendQueryResult>> getSendResults(@RequestBody DocumentParams params) {
        SendQueryResult queryResult = (SendQueryResult)this.commandInvokerFacade.executeCommand(params, "SendDocument#Query");
        RestResponse<SendQueryResult> restResponse = ResponseBuilder.createResponseByData(queryResult).setResultCode(0).setResultMessage("").build();
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    @RequestMapping(
            value = {"/zipFile"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<SendMSRequestAgentResult>> uploadZipFile(MultipartHttpServletRequest request) {
        try {
            SendMSRequestAgentResult agentResult = this.commandInvokerFacade.startSendDocuments(request);
            RestResponse<SendMSRequestAgentResult> restResponse = ResponseBuilder.createResponseByData(agentResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/MSEncrypted"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<SendMSEncryptedAgentResult>> sendMSEncryptedAgent(@RequestBody DocumentParams params) {
        try {
            SendMSEncryptedAgentResult agentResult = (SendMSEncryptedAgentResult)this.commandInvokerFacade.executeCommand(params, "SendDocument#MSEncryptedAgent");
            RestResponse<SendMSEncryptedAgentResult> restResponse = ResponseBuilder.createResponseByData(agentResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            this.commandInvokerFacade.setSendEntityStatus(SendStatus.ERROR, params.getDocumentId());
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }

    @RequestMapping(
            value = {"/sendOut"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<SendOutResult>> sendOutCommand(@RequestBody DocumentParams params) {
        try {
            SendOutResult sendOutResult = this.commandInvokerFacade.saveSendOutResult(params);
            RestResponse<SendOutResult> restResponse = ResponseBuilder.createResponseByData(sendOutResult).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            this.commandInvokerFacade.setSendEntityStatus(SendStatus.FAILED, params.getDocumentId());
            throw new ArchivesException(var4.getMessage(), var4.getCause());
        }
    }
}
