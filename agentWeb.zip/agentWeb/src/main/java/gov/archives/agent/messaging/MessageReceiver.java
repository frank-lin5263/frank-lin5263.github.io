package gov.archives.agent.messaging;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MessageReceiver {
    @Autowired
    private JmsTemplate jmsTemplate;

    public MessageReceiver() {
    }

    public Object receiveMessage(ActiveMQQueue resultDestination) {
        return this.jmsTemplate.receiveAndConvert(resultDestination);
    }
}