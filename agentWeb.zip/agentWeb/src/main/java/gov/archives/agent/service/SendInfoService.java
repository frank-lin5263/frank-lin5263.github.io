package gov.archives.agent.service;

import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.vo.ZipParams;
import gov.archives.jagent.domain.result.SendOutResult;
import java.io.File;
import java.util.List;
import java.util.UUID;

public interface SendInfoService {
    SendDocumentEntity saveSendProcess(ZipParams var1, File var2);

    void updateStatusCode(Integer var1, String var2);

    void update(SendDocumentEntity var1);

    void update(SendOutResult var1);

    SendDocumentEntity findByDocument(UUID var1);

    List<SendDocumentEntity> listAll();
}
