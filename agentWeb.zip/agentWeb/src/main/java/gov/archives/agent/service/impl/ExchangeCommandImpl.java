package gov.archives.agent.service.impl;

import gov.archives.agent.Utils.CompressUtils;
import gov.archives.agent.accessor.FileAccessor;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.message.ErrorMessage;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.security.pki.JPKISelfCASecurityUtils;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.UserInfoUtil;
import gov.archives.jagent.domain.parameter.CommandParameter;
import gov.archives.jagent.domain.parameter.CommandParameter.Builder;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.InitConfirmResult;
import gov.archives.jagent.domain.result.SendMSEncryptedAgentResult;
import gov.archives.jagent.domain.result.SendMSRequestAgentResult;
import gov.archives.jagent.domain.vo.SigningFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.xml.sax.SAXException;

@Service
public class ExchangeCommandImpl extends CommandServiceImpl {
    private static final String DOC_ZIP_FILE = "doc.zip";
    private static final Logger log = LoggerFactory.getLogger(ExchangeCommandImpl.class);
    @Autowired
    private ActiveMQQueue pushFileDestination;
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private SessionManageService sessionManageService;
    @Autowired
    private FileAccessor fileAccessor;
    private SAXParserFactory saxParserFactory;
    private SAXParser saxParser;
    private String[] supportFormat = new String[]{"di", "doc", "pdf", "ppt", "sw", "xls"};

    public ExchangeCommandImpl() {
        try {
            this.saxParserFactory = SAXParserFactory.newInstance();
            this.saxParser = this.saxParserFactory.newSAXParser();
        } catch (SAXException | ParserConfigurationException var2) {
            throw new ArchivesException(var2.getMessage(), var2.getCause());
        }
    }

    private void deleteTempFile(List<File> sourceFiles) {
        Iterator var2 = sourceFiles.iterator();

        while(var2.hasNext()) {
            File file = (File)var2.next();
            IOUtils.deleteFile(file);
        }

        sourceFiles.clear();
    }

    public File sendDocumentFile(MultipartHttpServletRequest request) {
        String decryptedToken = request.getParameter("decryptedToken");
        PreconditionUtils.checkArguments(new Object[]{decryptedToken});
        File zipFile = this.saveMultipartFile(request);
        List<File> sourceFiles = this.uncompressZipFile(zipFile);
        File sendDocZip = this.buildSendDocZip(sourceFiles, decryptedToken);
        this.getMessageSender().sendFileByByteMessage(this.pushFileDestination, sendDocZip);
        request.setAttribute("fileHash", FilenameUtils.getBaseName(sendDocZip.getName()));
        IOUtils.deleteFile(zipFile);
        this.deleteTempFile(sourceFiles);
        return sendDocZip;
    }

    private List<File> uncompressZipFile(File zipFile) {
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(zipFile);
        List<File> sourceFiles = new ArrayList();
        Path accountPath = this.documentAccessor.getTempPath("TempFiles");
        fileMap.entrySet().forEach((entry) -> {
            try {
                File tempFile = accountPath.resolve((String)entry.getKey()).toFile();
                FileUtils.writeByteArrayToFile(tempFile, (byte[])entry.getValue());
                sourceFiles.add(tempFile);
            } catch (IOException var4) {
                throw new ArchivesException(var4.getMessage(), var4.getCause());
            }
        });
        return sourceFiles;
    }

    private File buildSendDocZip(List<File> sourceFiles, String b64DecryptedToken) {
        String account = UserInfoUtil.getCurrentAccount();
        File sendDocZip = this.documentAccessor.getTempPath("TempFiles").resolve(account).resolve("doc.zip").toFile();
        String decryptedToken = new String(DatatypeConverter.parseBase64Binary(b64DecryptedToken));
        CompressUtils.compressFilesToZip(sourceFiles, sendDocZip, decryptedToken);
        String fileHash = this.documentAccessor.getFileHash(sendDocZip);
        return this.documentAccessor.renameFile(sendDocZip, fileHash + ".zip");
    }

    private File saveMultipartFile(MultipartHttpServletRequest request) {
        List<MultipartFile> fileList = new ArrayList();
        request.getFileMap().entrySet().forEach((entry) -> {
            fileList.add(entry.getValue());
        });
        MultipartFile uploadZip = (MultipartFile)fileList.get(0);
        String account = UserInfoUtil.getCurrentAccount();
        Path accountPath = this.documentAccessor.getTempPath("TempFiles").resolve(account);
        FileSystemUtils.checkFolder(accountPath);
        File tempFile = accountPath.resolve(uploadZip.getOriginalFilename()).toFile();

        try {
            FileUtils.writeByteArrayToFile(tempFile, uploadZip.getBytes());
            tempFile = (new ZipFile(tempFile)).isValidZipFile() ? tempFile : null;
        } catch (IOException | ZipException var8) {
            throw new ArchivesException(var8.getMessage(), var8.getCause());
        }

        String fileHash = this.documentAccessor.getFileHash(tempFile);
        return this.documentAccessor.renameFile(tempFile, fileHash + ".zip");
    }

    public void sendFile(File file) {
        this.getMessageSender().sendFileByByteMessage(this.pushFileDestination, file);
    }

    public void isSupportFile(String filename) {
        if (!FilenameUtils.isExtension(filename, this.supportFormat)) {
            String message = String.format(ErrorMessage.findByCode("AG0000"), filename);
            throw new ArchivesException("AG0000", new Throwable(message));
        }
    }

    private void checkSessionExpired(InitConfirmResult confirmResult) {
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        DateTime dt = formatter.parseDateTime(confirmResult.getExpireTime());
        if (dt.isBefore(System.currentTimeMillis())) {
            String message = String.format(ErrorMessage.findByCode("AG0001"), confirmResult.getSessionId());
            throw new ArchivesException("AG0001", new Throwable(message));
        }
    }

    public SendMSRequestAgentResult buildMSRequestAgentResult(SendMSRequestAgentResult agentResult) {
        agentResult.setSigningFiles(this.buildSigningFile(agentResult.getSigningFiles()));
        return agentResult;
    }

    public SendMSEncryptedAgentResult buildMSAgentResult(CommandResult<?> result) {
        SendMSEncryptedAgentResult agentResult = (SendMSEncryptedAgentResult)result.getResult();
        agentResult.setSigningFiles(this.buildSigningFile(agentResult.getSigningFiles()));
        return agentResult;
    }

    private SigningFile[] buildSigningFile(SigningFile[] signingFiles) {
        String[] b64SigningFiles = new String[signingFiles.length];

        for(int i = 0; i < b64SigningFiles.length; ++i) {
            b64SigningFiles[i] = JPKISelfCASecurityUtils.getInstance().getB64PaddingHash("SHA-256", signingFiles[i].getFileHash().getBytes());
            signingFiles[i].setFileHash(b64SigningFiles[i]);
        }

        return signingFiles;
    }

    public synchronized <R> CommandResult<R> execute(Object command, String commandName, InitConfirmResult confirmResult, String signToken) {
        PreconditionUtils.checkArguments(new Object[]{command, commandName, confirmResult, signToken});
        this.sendCommand(this.buildCommand(command, commandName, confirmResult.getSessionId(), signToken));
        CommandResult<R> result = this.receiveCommand();
        return result;
    }

    private <P> CommandParameter<P> buildCommand(P parameters, String name, String sessionId, String signToken) {
        CommandParameter<P> commandMessage = Builder.createRequestByParameter(parameters).setName(name).setId(UUID.randomUUID()).setSessionId(sessionId).setTokenSig(signToken).build();
        return commandMessage;
    }
}
