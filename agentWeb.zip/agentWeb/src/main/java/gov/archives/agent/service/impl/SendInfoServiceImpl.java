package gov.archives.agent.service.impl;

import gov.archives.agent.accessor.FileAccessor;
import gov.archives.agent.accessor.TemplateDocumentAccessor;
import gov.archives.agent.conf.SendStatus;
import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.domain.entity.StoredFileEntity;
import gov.archives.agent.domain.entity.StoredFileEntity.Builder;
import gov.archives.agent.domain.vo.ZipParams;
import gov.archives.agent.mapper.command.SendInfoCommandMapper;
import gov.archives.agent.mapper.command.StoredFileCommandMapper;
import gov.archives.agent.mapper.query.SendInfoQueryMapper;
import gov.archives.agent.service.SendInfoService;
import gov.archives.common.json.JsonUtils;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.UserInfoUtil;
import gov.archives.jagent.domain.result.SendOutResult;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.commons.io.FileUtils;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

@Service
public class SendInfoServiceImpl implements SendInfoService {
    @Autowired
    private SendInfoCommandMapper sendInfoCommandMapper;
    @Autowired
    private SendInfoQueryMapper sendInfoQueryMapper;
    @Autowired
    private StoredFileCommandMapper storedFileCommandMapper;
    @Autowired
    private FileAccessor fileAccessor;
    @Autowired
    private TemplateDocumentAccessor documentAccessor;
    @Autowired
    private SendDiServiceImpl sendDiService;
    private SAXParserFactory saxParserFactory;
    private SAXParser saxParser;

    public SendInfoServiceImpl() {
        try {
            this.saxParserFactory = SAXParserFactory.newInstance();
            this.saxParser = this.saxParserFactory.newSAXParser();
        } catch (SAXException | ParserConfigurationException var2) {
            throw new ArchivesException(var2.getMessage(), var2.getCause());
        }
    }

    public SendDocumentEntity saveSendProcess(ZipParams params, File sendZip) {
        String password = new String(DatatypeConverter.parseBase64Binary(params.getDecryptedToken()));
        params.setDecryptedToken(password);
        Map<String, byte[]> fileMap = this.fileAccessor.uncompressZipFile(sendZip, password);
        SendDocumentEntity entity = this.parserSendDiFile(fileMap);
        entity.setDocumentId(params.getDocumentId());
        this.sendInfoCommandMapper.save(entity);
        this.storedFileCommandMapper.save(this.buildStoredFileEntity(params));
        return entity;
    }

    public void updateStatusCode(Integer statusCode, String documentId) {
        SendDocumentEntity entity = this.findByDocument(UUID.fromString(documentId));
        entity.setStatusCode(statusCode);
        entity.setModifierAccount(UserInfoUtil.getCurrentAccount());
        entity.setModifiedTime(Timestamp.valueOf(Timestamp.from(Instant.now()).toLocalDateTime()));
        this.sendInfoCommandMapper.update(entity);
    }

    public void update(SendDocumentEntity entity) {
        entity.setModifierAccount(UserInfoUtil.getCurrentAccount());
        entity.setModifiedTime(Timestamp.valueOf(Timestamp.from(Instant.now()).toLocalDateTime()));
        this.sendInfoCommandMapper.update(entity);
    }

    public void update(SendOutResult sendOutResult) {
        SendDocumentEntity entity = this.findByDocument(sendOutResult.getDocumentId());
        String jsonText = JsonUtils.getJsonTextByObject(sendOutResult.getProcessIds());
        entity.setProcessId(jsonText);
        entity.setStatusCode(SendStatus.SIGN_OK);
        entity.setReceiverCount(sendOutResult.getProcessIds().length);
        entity.setExchangeId(sendOutResult.getExchangeId());
        entity.setSendOutTime(Timestamp.valueOf(Timestamp.from(Instant.now()).toLocalDateTime()));
        entity.setModifierAccount(UserInfoUtil.getCurrentAccount());
        entity.setModifiedTime(Timestamp.valueOf(Timestamp.from(Instant.now()).toLocalDateTime()));
        this.sendInfoCommandMapper.update(entity);
    }

    public SendDocumentEntity findByDocument(UUID documentId) {
        PreconditionUtils.checkArguments(new Object[]{documentId});
        return (SendDocumentEntity)this.sendInfoQueryMapper.findOne(documentId);
    }

    public List<SendDocumentEntity> listAll() {
        return this.sendInfoQueryMapper.findAll();
    }

    private SendDocumentEntity parserSendDiFile(Map<String, byte[]> fileMap) {
        SendDocumentEntity[] entity = new SendDocumentEntity[1];
        Path accountPath = this.documentAccessor.getTempPath("TempFiles");
        fileMap.entrySet().forEach((entry) -> {
            try {
                if (((String)entry.getKey()).endsWith(".di")) {
                    File diFile = accountPath.resolve((String)entry.getKey()).toFile();
                    FileUtils.writeByteArrayToFile(diFile, (byte[])entry.getValue());
                    entity[0] = this.saxParserByDiFile(diFile);
                }

            } catch (IOException var5) {
                throw new ArchivesException(var5.getMessage(), var5.getCause());
            }
        });
        return entity[0];
    }

    private SendDocumentEntity saxParserByDiFile(File diFile) {
        try {
            this.saxParser.getXMLReader().setEntityResolver(this.sendDiService);
            this.saxParser.parse(diFile, this.sendDiService);
            return this.sendDiService.postEntityProcess(diFile);
        } catch (IOException | SAXException var3) {
            throw new ArchivesException(var3.getMessage(), var3.getCause());
        }
    }

    StoredFileEntity buildStoredFileEntity(ZipParams params) {
        StoredFileEntity entity = Builder.create().setFileHash(params.getFileHash()).setFilePassword(params.getDecryptedToken()).setOrgUnitId(params.getOrgUnitId()).build();
        entity.initSave(UserInfoUtil.getCurrentAccount(), params.getDocumentId());
        return entity;
    }
}
