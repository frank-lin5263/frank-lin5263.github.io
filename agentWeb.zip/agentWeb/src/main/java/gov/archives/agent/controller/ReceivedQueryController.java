package gov.archives.agent.controller;

import gov.archives.agent.domain.vo.DocumentParams;
import gov.archives.agent.domain.vo.ReceivedQuery;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/officialFolder/receivedQuery"})
public class ReceivedQueryController {
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public ReceivedQueryController() {
    }

    @RequestMapping(
            value = {"/list"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<List<ReceivedQuery>>> getReceivedQueryEntities(@RequestBody DocumentParams params) {
        List<ReceivedQuery> list = this.commandInvokerFacade.getReceivedQueryEntities(params);
        RestResponse<List<ReceivedQuery>> restResponse = ResponseBuilder.createResponseByData(list).setResultCode(0).setResultMessage("").build();
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    @RequestMapping(
            value = {"/preview"},
            method = {RequestMethod.GET}
    )
    public void preViewReceiveDi(@RequestParam("documentId") String documentId, @RequestParam("decryptedToken") String decryptedToken, HttpServletResponse response) {
        try {
            this.commandInvokerFacade.transReceiveDi2HTML(response, documentId, decryptedToken);
        } catch (Exception var5) {
            throw new ArchivesException(var5.getMessage(), var5.getCause());
        }
    }
}
