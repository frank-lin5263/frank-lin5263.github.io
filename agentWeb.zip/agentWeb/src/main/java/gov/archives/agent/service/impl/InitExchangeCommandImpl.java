package gov.archives.agent.service.impl;

import gov.archives.agent.domain.vo.InitExchangeCommand;
import gov.archives.agent.domain.vo.InitExchangeCommand.Builder;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.InitConfirmResult;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class InitExchangeCommandImpl extends CommandServiceImpl {
    public InitExchangeCommandImpl() {
    }

    public synchronized <R> CommandResult<R> execute(Object command, String commandName, InitConfirmResult confirmResult, String signToken) {
        this.sendCommand(this.buildCommand(command, commandName));
        CommandResult<R> result = this.receiveCommand();
        return result;
    }

    private <P> InitExchangeCommand buildCommand(P parameters, String name) {
        InitExchangeCommand initExchangeCommand = Builder.createParameter(parameters).setId(UUID.randomUUID()).setName(name).build();
        return initExchangeCommand;
    }
}

