package gov.archives.agent.controller;

import gov.archives.agent.domain.vo.SendQuery;
import gov.archives.agent.facade.CommandInvokerFacade;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/officialFolder/sendQuery"})
public class SendQueryController {
    @Autowired
    private CommandInvokerFacade commandInvokerFacade;

    public SendQueryController() {
    }

    @RequestMapping(
            value = {"/list"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<List<SendQuery>>> getSendQueryEntities() {
        List<SendQuery> list = this.commandInvokerFacade.getSendQueryEntities();
        RestResponse<List<SendQuery>> restResponse = ResponseBuilder.createResponseByData(list).setResultCode(0).setResultMessage("").build();
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }
}
