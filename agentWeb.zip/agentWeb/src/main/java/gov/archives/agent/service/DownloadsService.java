package gov.archives.agent.service;

import java.io.File;
import javax.servlet.http.HttpServletResponse;

public interface DownloadsService {
    File getUncompressFile(String var1, String var2);

    File buildAllDownload(String var1);

    File buildDownloadZip(String var1, String var2);

    File getReceiveDi(String var1, String var2);

    void responseDownloadingFile(File var1, HttpServletResponse var2, String var3, String var4);
}
