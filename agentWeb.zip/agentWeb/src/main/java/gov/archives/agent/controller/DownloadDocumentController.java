
package gov.archives.agent.controller;

import gov.archives.agent.service.DownloadsService;
import gov.archives.core.controller.RestControllerBase;
import gov.archives.core.exception.ArchivesException;
import java.io.File;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/download"})
public class DownloadDocumentController extends RestControllerBase {
    @Autowired
    private DownloadsService downloadsService;

    public DownloadDocumentController() {
    }

    @RequestMapping(
            value = {"/zip"},
            method = {RequestMethod.GET}
    )
    public void downloadDocument(@RequestParam("documentId") String documentId, @RequestParam("decryptedToken") String decryptedToken, HttpServletResponse response) {
        File downloadFile = null;

        try {
            downloadFile = this.downloadsService.buildDownloadZip(documentId, decryptedToken);
            this.downloadsService.responseDownloadingFile(downloadFile, response, ".zip", "application/zip");
        } catch (Exception var9) {
            throw new ArchivesException(var9.getMessage(), var9.getCause());
        } finally {
            if (downloadFile != null && downloadFile.exists()) {
                FileUtils.deleteQuietly(downloadFile);
            }

        }

    }
}
