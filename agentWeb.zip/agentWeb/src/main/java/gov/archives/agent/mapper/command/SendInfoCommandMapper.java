package gov.archives.agent.mapper.command;

import gov.archives.agent.domain.entity.SendDocumentEntity;
import gov.archives.agent.mapper.CommadnRepository;
import java.util.UUID;

public interface SendInfoCommandMapper extends CommadnRepository<SendDocumentEntity, UUID> {
}
