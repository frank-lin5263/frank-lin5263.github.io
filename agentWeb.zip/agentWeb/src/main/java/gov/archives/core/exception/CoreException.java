package gov.archives.core.exception;

import gov.archives.core.util.LogUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CoreException extends BaseException {
    private static final Logger log = LoggerFactory.getLogger(CoreException.class);
    public static final String LOG_DEFALUT_MESSAGE = "default message";
    public static final String ENABLE_SUPPRESSION = "enableSuppression";
    public static final String WRITABLE_STACKTRACE = "writableStackTrace";

    public CoreException(String errorCodeOrMessage) {
        super(LogUtils.getErrorMessage(errorCodeOrMessage));
        LogUtils.debug(LogUtils.getErrorMessage(errorCodeOrMessage));
    }

    public CoreException(Throwable cause, String errorCodeOrMessage) {
        super(cause, LogUtils.getErrorMessage(errorCodeOrMessage));
        LogUtils.debug(LogUtils.getErrorMessage(errorCodeOrMessage), cause);
    }

    public CoreException(Throwable cause) {
        super(cause);
        LogUtils.debug(cause);
    }

    public CoreException(String errorCodeOrMessage, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(LogUtils.getErrorMessage(errorCodeOrMessage), cause, enableSuppression, writableStackTrace);
        LogUtils.debug("default message:" + LogUtils.getErrorMessage(errorCodeOrMessage) + " " + "enableSuppression" + ":" + enableSuppression + " " + "writableStackTrace" + ":" + writableStackTrace, cause);
    }
}

