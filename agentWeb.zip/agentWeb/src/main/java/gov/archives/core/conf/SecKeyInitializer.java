package gov.archives.core.conf;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.util.EncryptUtils;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.commons.lang3.RandomStringUtils;
import org.iii.common.util.StringUtils;

public class SecKeyInitializer extends CommonInitializer implements BaseInitializer {
    public SecKeyInitializer() {
    }

    public void init() {
        if (checkStartInit()) {
            genRandomSeckey();
        }

    }

    public static void genRandomSeckey() {
        Properties propEn = loadPropertiesFromFile(encryptConfigFile);
        Map<Integer, String> sk_list_data = new HashMap();
        secretkey = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));
        List<String> sk_list = Arrays.asList(SECRETKEY_SEGMENT.split(","));
        String appendData = getRandomBase64Text(secretkey.length() % sk_list.size());

        Integer i;
        int segmentSecretDataLength;
        for(i = 0; i < sk_list.size(); i = i + 1) {
            segmentSecretDataLength = secretkey.length() / sk_list.size();
            if (StringUtils.isEmpty((String)sk_list.get(i))) {
                throw ArchivesException.getInstanceByErrorCode("SYS005", new Object[0]);
            }

            if (i == 0) {
                sk_list_data.put(Integer.valueOf((String)sk_list.get(i)), secretkey.substring(i, segmentSecretDataLength) + (!i.equals(sk_list.size() - 1) ? appendData : ""));
            } else if (i == sk_list.size() - 1) {
                sk_list_data.put(Integer.valueOf((String)sk_list.get(i)), secretkey.substring(i * segmentSecretDataLength, secretkey.length()));
            } else {
                sk_list_data.put(Integer.valueOf((String)sk_list.get(i)), secretkey.substring(i * segmentSecretDataLength, (i + 1) * segmentSecretDataLength) + (!i.equals(sk_list.size() - 1) ? appendData : ""));
            }
        }

        for(i = 0; i < PROPERTY_SECRETKEY_PART.length; i = i + 1) {
            segmentSecretDataLength = secretkey.length() / sk_list.size() + appendData.length();
            propEn.setProperty(PROPERTY_SECRETKEY_PART[i], getRandomBase64Text(segmentSecretDataLength));
            Iterator var6 = sk_list_data.keySet().iterator();

            while(var6.hasNext()) {
                Integer sk_list_data_key = (Integer)var6.next();
                if (sk_list_data_key.equals(i + 1)) {
                    propEn.setProperty(PROPERTY_SECRETKEY_PART[i], (String)sk_list_data.get(sk_list_data_key));
                }
            }
        }

        storePropertiesFile(encryptConfigFile, propEn);
    }

    private static String getRandomBase64Text(int size) {
        return EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true)).substring(0, size);
    }

    public static String getRandomSecKey() {
        Properties propEn = loadPropertiesFromFile(encryptConfigFile);
        Map<Integer, String> sk_list_data = new HashMap();
        String rtnSecKey = "";
        secretkey = EncryptUtils.txtToBase64(RandomStringUtils.random(24, true, true));
        List<String> sk_list = Arrays.asList(SECRETKEY_SEGMENT.split(","));
        String appendData = getRandomBase64Text(secretkey.length() % sk_list.size());

        Integer i;
        for(i = 0; i < sk_list.size(); i = i + 1) {
            sk_list_data.put(i, propEn.getProperty(PROPERTY_SECRETKEY_PART[Integer.parseInt((String)sk_list.get(i)) - 1]));
        }

        for(i = 0; i < sk_list_data.size(); i = i + 1) {
            if (i.equals(sk_list_data.size() - 1)) {
                rtnSecKey = rtnSecKey + (String)sk_list_data.get(i);
            } else {
                rtnSecKey = rtnSecKey + ((String)sk_list_data.get(i)).substring(0, ((String)sk_list_data.get(i)).length() - appendData.length());
            }
        }

        return rtnSecKey;
    }

    private static boolean checkStartInit() {
        return !checkStringsIsEmpty(new String[]{INIT_URL, INIT_COMMANDER, INIT_COMMANDER_PWD, INIT_QUERIER, INIT_QUERIER_PWD});
    }
}
