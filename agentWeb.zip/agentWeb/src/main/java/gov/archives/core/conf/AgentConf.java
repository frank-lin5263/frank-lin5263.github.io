package gov.archives.core.conf;

import java.io.File;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Properties;

public class AgentConf {
    public static final String MANAGE_WEB_PROPERTIES = "manageWeb.properties";
    public static final String PROP_CSV_UPLOAD = "upload.stored.location";
    public static final String PROP_CLIENT_LOG = "client.log.location";
    public static final String PROP_CENTER_ID = "inhub.center.id";
    public static final String PROP_SERVER_CONFIG = "server.config.location";
    public static final String DEFAULT_TIME = "1970-01-01 08:00:00";
    private static Properties prop;

    public AgentConf() {
    }

    public static Timestamp getNowTime() {
        return Timestamp.from(Instant.now());
    }

    public static Timestamp getDefaultTime() {
        return Timestamp.valueOf("1970-01-01 08:00:00");
    }

    public static void initProperty(String property) {
        if (null == prop) {
            File propFile = CommonInitializer.getFileFromConfiguredFolderOrClasspath(property);
            prop = CommonInitializer.loadPropertiesFromFile(propFile);
        }

    }

    public static String getCsvUploadLocation() {
        if (null == prop) {
            initProperty("manageWeb.properties");
        }

        return prop.getProperty("upload.stored.location");
    }

    public static String getClientLogLocation() {
        if (null == prop) {
            initProperty("manageWeb.properties");
        }

        return prop.getProperty("client.log.location");
    }

    public static String getCenterID() {
        if (null == prop) {
            initProperty("manageWeb.properties");
        }

        return prop.getProperty("inhub.center.id");
    }

    public static String getServerConfigLocation() {
        if (null == prop) {
            initProperty("manageWeb.properties");
        }

        return prop.getProperty("server.config.location");
    }
}

