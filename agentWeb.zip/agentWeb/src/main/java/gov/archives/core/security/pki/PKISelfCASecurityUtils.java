package gov.archives.core.security.pki;

import org.iii.security.domain.KeyStorePackage;
import org.iii.security.domain.SignPackage;
import org.iii.security.exception.SecurityException;

public interface PKISelfCASecurityUtils {
    byte[] SHA1_HEADER = new byte[]{48, 33, 48, 9, 6, 5, 43, 14, 3, 2, 26, 5, 0, 4, 20};
    byte[] MD5_HEADER = new byte[]{48, 32, 48, 12, 6, 8, 42, -122, 72, -122, -9, 13, 2, 5, 5, 0, 4, 16};
    byte[] SHA256_HEADER = new byte[]{48, 49, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 1, 5, 0, 4, 32};
    byte[] SHA384_HEADER = new byte[]{48, 65, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 2, 5, 0, 4, 48};
    byte[] SHA512_HEADER = new byte[]{48, 81, 48, 13, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 3, 5, 0, 4, 64};
    String ALGORITHM_SHA256 = "SHA-256";
    String ALGORITHM_SHA1 = "SHA-1";
    String ALGORITHM_MD5 = "MD5";

    boolean verifySignature(SignPackage var1) throws SecurityException;

    boolean verifySignature(String var1, SignPackage var2) throws SecurityException;

    boolean verifyHashSignature(SignPackage var1) throws SecurityException;

    boolean verifyHashSignature(String var1, SignPackage var2) throws SecurityException;

    SignPackage signContentByKeyStore(byte[] var1, KeyStorePackage var2) throws SecurityException;

    SignPackage signContentByKeyStore(String var1, byte[] var2, KeyStorePackage var3) throws SecurityException;

    SignPackage signHashedByKeyStore(byte[] var1, KeyStorePackage var2) throws SecurityException;

    SignPackage signHashedByKeyStore(String var1, byte[] var2, KeyStorePackage var3) throws SecurityException;

    byte[] encryptByCert(byte[] var1, byte[] var2) throws SecurityException;

    byte[] encryptByKeyStore(byte[] var1, KeyStorePackage var2) throws SecurityException;

    byte[] decryptByKeyStore(byte[] var1, KeyStorePackage var2) throws SecurityException;

    boolean isCertValid(byte[] var1, byte[] var2) throws SecurityException;

    byte[] paddingHashContent(String var1, byte[] var2) throws SecurityException;

    String getB64PaddingHash(String var1, byte[] var2);
}

