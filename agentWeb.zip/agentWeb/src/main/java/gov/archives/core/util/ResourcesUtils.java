package gov.archives.core.util;

import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.iii.common.util.FileSystemUtils;

public class ResourcesUtils {
    public ResourcesUtils() {
    }

    public static void writeDTDFile(String filePath) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream is = loader.getResourceAsStream(filePath);
        String name = FilenameUtils.getName(filePath);
        File file = PathUtils.getTempFolderPath().resolve(name).toFile();

        try {
            if (!file.exists()) {
                FileUtils.copyInputStreamToFile(is, file);
            }

        } catch (IOException var6) {
            throw new ArchivesException(var6.getMessage(), var6.getCause());
        }
    }

    public static void writeDTDFile(String filePath, String account) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream is = loader.getResourceAsStream(filePath);
        String name = FilenameUtils.getName(filePath);
        Path accountPath = PathUtils.getTempFolderPath().resolve(account);
        FileSystemUtils.checkFolder(accountPath);
        File file = accountPath.resolve(name).toFile();

        try {
            if (!file.exists()) {
                FileUtils.copyInputStreamToFile(is, file);
            }

        } catch (IOException var8) {
            throw new ArchivesException(var8.getMessage(), var8.getCause());
        }
    }
}

