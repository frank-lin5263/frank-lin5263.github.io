package gov.archives.core.domain.entity;

import java.io.Serializable;

public class ChangeCertEntity extends BaseEntity implements Serializable {
    private String serialNumber;
    private String certb64;
    private String account;
    private String certHash;

    public ChangeCertEntity() {
    }

    public String getSerialNumber() {
        return this.serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getCertb64() {
        return this.certb64;
    }

    public void setCertb64(String certb64) {
        this.certb64 = certb64;
    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getCertHash() {
        return this.certHash;
    }

    public void setCertHash(String certHash) {
        this.certHash = certHash;
    }
}

