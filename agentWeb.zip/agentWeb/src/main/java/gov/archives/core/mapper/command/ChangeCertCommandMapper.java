package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.UpdateCertEntity;

public interface ChangeCertCommandMapper {
    void update(UpdateCertEntity var1);
}
