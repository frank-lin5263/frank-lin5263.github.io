package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.i18n.SerializableResourceBundleMessageSource;
import gov.archives.core.service.ResourceBundleService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.AuthenticationUtil;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ResourceBundleServiceImpl implements ResourceBundleService {
    @Autowired
    protected SerializableResourceBundleMessageSource messageBundle;
    @Autowired
    private UserInfoService userInfoService;
    private final Map<Locale, Properties> localizedMap = new HashMap();

    public ResourceBundleServiceImpl() {
    }

    public Properties getAll() {
        return this.getBundleForUser();
    }

    public String get(String key) {
        return this.getBundleForUser().getProperty(key);
    }

    public boolean containsKey(String key) {
        return this.getAll().containsKey(key);
    }

    public String getFormatted(String key, Object... arguments) {
        return MessageFormat.format(this.getBundleForUser().getProperty(key), arguments);
    }

    private Properties getBundleForUser() {
        UserInfoEntity entity = this.userInfoService.getByAccount(AuthenticationUtil.getCurrentAccount());
        Locale locale = entity.getLocale();
        if (!this.localizedMap.containsKey(locale)) {
            this.localizedMap.put(locale, this.messageBundle.getAllProperties(locale));
        }

        return (Properties)this.localizedMap.get(locale);
    }
}
