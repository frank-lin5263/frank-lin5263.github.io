package gov.archives.core.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;

public class BaseEvent extends ApplicationEvent {
    private static final Logger log = LoggerFactory.getLogger(BaseEvent.class);
    private static final String EVENT_NAME = "BaseEvent";
    protected String EVENT_OCCUR = "BaseEvent is occur!";
    protected String EXCUTE_RESULT = "excute result";

    public BaseEvent(Object source) {
        super(source);
    }

    public String toString() {
        return "BaseEvent";
    }

    public void logEvent() {
        log.info(this.EVENT_OCCUR);
    }
}

