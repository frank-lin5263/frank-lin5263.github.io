package gov.archives.core.domain.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;
import org.apache.ibatis.type.Alias;

@Alias("ActionLog")
public class ActionLogEntity extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 3647233284813657927L;
    private Timestamp actionTime;
    private String remoteIp;
    private String actionItem;
    private String actorAccount;
    private String actionResult;
    private String errorCode;
    private String eventLevel;

    public ActionLogEntity() {
    }

    public Timestamp getActionTime() {
        return this.actionTime;
    }

    public static long getSerialVersionUID() {
        return 3647233284813657927L;
    }

    public String getRemoteIp() {
        return this.remoteIp;
    }

    public String getActionItem() {
        return this.actionItem;
    }

    public String getActorAccount() {
        return this.actorAccount;
    }

    public String getActionResult() {
        return this.actionResult;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public String getEventLevel() {
        return this.eventLevel;
    }

    public void setActionTime(Timestamp actionTime) {
        this.actionTime = actionTime;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public void setActionItem(String actionItem) {
        this.actionItem = actionItem;
    }

    public void setActorAccount(String actorAccount) {
        this.actorAccount = actorAccount;
    }

    public void setActionResult(String actionResult) {
        this.actionResult = actionResult;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public void setEventLevel(String eventLevel) {
        this.eventLevel = eventLevel;
    }

    public static class Builder {
        private ActionLogEntity entity = new ActionLogEntity();
        private ActionLogEntity.Builder self = this;

        public static ActionLogEntity.Builder create() {
            return new ActionLogEntity.Builder();
        }

        private Builder() {
        }

        public ActionLogEntity.Builder setActionTime(Timestamp actionTime) {
            this.entity.actionTime = actionTime;
            return this.self;
        }

        public ActionLogEntity.Builder setRemoteIp(String remoteIp) {
            this.entity.remoteIp = remoteIp;
            return this.self;
        }

        public ActionLogEntity.Builder setActionItem(String actionItem) {
            this.entity.actionItem = actionItem;
            return this.self;
        }

        public ActionLogEntity.Builder setActorAccount(String actorAccount) {
            this.entity.actorAccount = actorAccount;
            return this.self;
        }

        public ActionLogEntity.Builder setActionResult(String actionResult) {
            this.entity.actionResult = actionResult;
            return this.self;
        }

        public ActionLogEntity.Builder setErrorCode(String errorCode) {
            this.entity.errorCode = errorCode;
            return this.self;
        }

        public ActionLogEntity.Builder setEventLevel(String eventLevel) {
            this.entity.eventLevel = eventLevel;
            return this.self;
        }

        public ActionLogEntity build() {
            this.entity.setSysId(UUID.randomUUID());
            return this.entity;
        }
    }
}

