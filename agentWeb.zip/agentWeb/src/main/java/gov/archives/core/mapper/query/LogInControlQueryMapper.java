package gov.archives.core.mapper.query;

import gov.archives.core.domain.entity.LogInControlEntity;
import java.util.Map;

public interface LogInControlQueryMapper {
    String KEY_SESSION_ID = "sessionId";
    String KEY_LOGIN_ACCOUNT = "loginAccount";

    LogInControlEntity findBySessionIdAndAccount(Map<String, String> var1);

    LogInControlEntity findBySessionIdAndAccountMaxlimitTime(Map<String, String> var1);

    LogInControlEntity findByAccountMaxlimitTime(String var1);
}
