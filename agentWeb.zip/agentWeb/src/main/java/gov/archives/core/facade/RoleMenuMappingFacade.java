package gov.archives.core.facade;

import gov.archives.core.domain.entity.MenuEntity;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

public interface RoleMenuMappingFacade {
    List<MenuEntity> getRoleMenuFacade(String var1) throws UnknownHostException;

    Map getRoleMappingMenu(String var1);
}
