package gov.archives.core.domain.vo;

import org.iii.common.util.StringUtils;

public class UserInfo {
    private String account;
    private String roleName;
    private String orgUnitId;
    private String email;
    private String phoneNumber;
    private String mobileNumber;
    private String orgInfo;
    private Integer activeStatus;
    private String deputyAccount;
    private String certCardNum;
    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;
    private String mobileAreaCode;
    private String mobileLocalNumber;

    public UserInfo() {
    }

    public void composePhoneNumber() {
        this.phoneNumber = this.phoneAreaCode + "-" + this.phoneLocalNumber + (StringUtils.isEmpty(this.phoneExtNumber) ? "" : "#" + this.phoneExtNumber);
    }

    public void composeMobileNumber() {
        this.mobileNumber = (this.mobileAreaCode != null && !this.mobileAreaCode.isEmpty() ? this.mobileAreaCode : "") + (StringUtils.isEmpty(this.mobileLocalNumber) ? "" : "-" + this.mobileLocalNumber);
    }

    public void rebuildPhoneNumbers() {
        this.composePhoneNumber();
        this.composeMobileNumber();
    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileNumber() {
        return this.mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOrgInfo() {
        return this.orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public Integer getActiveStatus() {
        return this.activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getDeputyAccount() {
        return this.deputyAccount;
    }

    public void setDeputyAccount(String deputyAccount) {
        this.deputyAccount = deputyAccount;
    }

    public String getCertCardNum() {
        return this.certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getPhoneAreaCode() {
        return this.phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return this.phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return this.phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return this.mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return this.mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }
}

