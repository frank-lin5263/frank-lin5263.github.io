package gov.archives.core.service;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.TopMenuVo;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface MenuService {
    MenuEntity getByMenuCode(String var1);

    void insert(MenuEntity var1);

    void update(MenuEntity var1);

    void delete(MenuEntity var1);

    MenuEntity getBySysId(UUID var1);

    List<MenuEntity> getAllMenu();

    Map<Integer, TopMenuVo> getMenuTree();

    Map<Integer, TopMenuVo> getMenuTree(List<MenuEntity> var1);

    Map<String, String> getMenuUrlMap();
}

