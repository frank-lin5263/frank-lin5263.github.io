package gov.archives.core.facade.impl;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.facade.DocumentExchangeServiceFacade;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.PKIIdentityService;
import gov.archives.core.service.UserInfoService;
import java.util.List;
import java.util.UUID;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class DocumentExchangeServiceFacadeImpl implements DocumentExchangeServiceFacade {
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private PKIIdentityService pkiIdentityService;

    public DocumentExchangeServiceFacadeImpl() {
    }

    public void checkAccountExist(AccountForm account) {
        PreconditionUtils.checkArguments(new Object[]{account});
        UserInfoEntity user = this.userInfoService.getByAccount(account.getAccount());
        if (null != user && user.getAccount().equals(account.getAccount())) {
            throw new AuthenticationServiceException("AP0012", new Throwable(CoreErrorMessage.findByCode("AP0012")));
        }
    }

    private String checkCertRegister(String b64Cert) {
        String certHash = this.pkiIdentityService.getSHA256CertHash(b64Cert);
        List<UserInfoEntity> userList = this.userInfoService.getByCertHash(certHash);
        if (userList.size() > 0) {
            throw new AuthenticationServiceException("AP0020", new Throwable(CoreErrorMessage.findByCode("AP0020")));
        } else {
            return certHash;
        }
    }

    public void saveNewAccount(AccountForm account, Long lastAccessTime) {
        String certSHA256Hash = this.checkCertRegister(account.getB64Cert());
        UserInfoEntity user = new UserInfoEntity();
        user.setAccount(account.getAccount());
        user.setOrgUnitId(account.getOrgUnitId());
        user.setPhoneNumber(this.getPhoneNumber(account));
        user.setMobileNumber(account.getMobileLocal() + "-" + account.getMobileNum());
        user.setEmail(account.getEmail());
        user.setCertCardNum(account.getCardNo().substring(0, 16));
        user.setCertHash(certSHA256Hash);
        user.setOrgInfo("");
        user.setActiveStatus(-1);
        user.setRoleSysId(UUID.fromString("00000000-0000-0000-0000-000000000000"));
        user.setDeputyAccount("");
        user.initSave(account.getAccount());
        this.userInfoService.insert(user);
    }

    private String getPhoneNumber(AccountForm account) {
        return StringUtils.isEmpty(account.getPhoneExt()) ? account.getPhoneLocal() + "-" + account.getPhoneNum() : account.getPhoneLocal() + "-" + account.getPhoneNum() + "#" + account.getPhoneExt();
    }
}
