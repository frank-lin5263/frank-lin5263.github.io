package gov.archives.core.domain.entity;

import java.sql.Timestamp;
import java.util.UUID;
import org.apache.ibatis.type.Alias;

@Alias("LogInControl")
public class LogInControlEntity extends BaseEntity {
    private UUID logInControlSysId;
    private String sessionId;
    private String loginAccount;
    private String certCardNum;
    private Timestamp loginTime;
    private String remoteIp;
    private Integer loginCount;
    private Timestamp maxLimitLoginTime;

    public LogInControlEntity() {
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public Timestamp getMaxLimitLoginTime() {
        return this.maxLimitLoginTime;
    }

    public UUID getLogInControlSysId() {
        return this.logInControlSysId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getLoginAccount() {
        return this.loginAccount;
    }

    public void setLoginAccount(String loginAccount) {
        this.loginAccount = loginAccount;
    }

    public String getCertCardNum() {
        return this.certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public Timestamp getLoginTime() {
        return this.loginTime;
    }

    public void setLoginTime(Timestamp loginTime) {
        this.loginTime = loginTime;
    }

    public String getRemoteIp() {
        return this.remoteIp;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public Integer getLoginCount() {
        return this.loginCount;
    }

    public void setLoginCount(Integer loginCount) {
        this.loginCount = loginCount;
    }

    public void setMaxLimitLoginTime(Timestamp maxLimitLoginTime) {
        this.maxLimitLoginTime = maxLimitLoginTime;
    }

    public void setLogInControlSysId(UUID logInControlSysId) {
        this.logInControlSysId = logInControlSysId;
    }
}

