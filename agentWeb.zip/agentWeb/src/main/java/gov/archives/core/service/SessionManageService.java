package gov.archives.core.service;

import gov.archives.core.domain.vo.AccountDetail;

public interface SessionManageService {
    void setAccountDetail(AccountDetail var1);

    AccountDetail getAccountDetail();

    Boolean checkAccountSessionId();

    int removeAccountDetail(String var1);

    String executeSystemLogout(String var1, String var2);
}
