package gov.archives.core.mapper.query;

import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.entity.UserRoleInfoEntity;
import java.util.List;
import java.util.Map;

public interface UserInfoQueryMapper {
    UserInfoEntity findByAccount(String var1);

    List<UserInfoEntity> findByCertHash(String var1);

    List<UserRoleInfoEntity> list();

    List<UserRoleInfoEntity> listByKeyWord(Map<String, Object> var1);

    ModifyPersonDataEntity personDataByAccount(String var1);
}
