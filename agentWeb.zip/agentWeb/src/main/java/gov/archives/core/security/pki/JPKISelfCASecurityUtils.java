package gov.archives.core.security.pki;

import gov.archives.core.exception.ArchivesException;
import java.io.ByteArrayInputStream;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.iii.common.util.PreconditionUtils;
import org.iii.security.domain.KeyStorePackage;
import org.iii.security.domain.SignPackage;
import org.iii.security.domain.SignPackage.SignPackageBuilder;
import org.iii.security.exception.SecurityException;
import org.iii.security.util.KeyStoreUtils;
import org.springframework.security.authentication.AuthenticationServiceException;

public class JPKISelfCASecurityUtils implements PKISelfCASecurityUtils {
    private static JPKISelfCASecurityUtils instance;

    public static synchronized JPKISelfCASecurityUtils getInstance() {
        if (null == instance) {
            instance = new JPKISelfCASecurityUtils();
        }

        return instance;
    }

    private JPKISelfCASecurityUtils() {
    }

    public boolean verifySignature(SignPackage sigPack) throws SecurityException {
        return this.verifySignature("SHA-1", sigPack);
    }

    public boolean verifySignature(String algorithm, SignPackage sigPack) throws SecurityException {
        this.verifySignPackage(sigPack);

        try {
            if (null == sigPack.getHashed()) {
                sigPack.setHashed(this.getContentHashByAlgorithm(algorithm, sigPack.getContent()));
            }

            return this.verifyHashSignature(algorithm, sigPack);
        } catch (NoSuchAlgorithmException var4) {
            throw new SecurityException(var4);
        }
    }

    private X509Certificate generateCertFromByte(byte[] certRaw) throws CertificateException {
        CertificateFactory certFact = CertificateFactory.getInstance("X.509");
        return (X509Certificate)certFact.generateCertificate(new ByteArrayInputStream(certRaw));
    }

    private void verifySignPackage(SignPackage signPack) {
        if (null == signPack) {
            throw new IllegalArgumentException("傳入空參數，以致錯誤");
        } else if (null != signPack.getContent() && 0 != signPack.getContent().length) {
            if (null != signPack.getSignature() && 0 != signPack.getSignature().length) {
                if (null == signPack.getCertificate() || 0 == signPack.getCertificate().length) {
                    throw new IllegalArgumentException("請確認要驗簽的憑證檔");
                }
            } else {
                throw new IllegalArgumentException("請確認要驗簽的簽章檔");
            }
        } else {
            throw new IllegalArgumentException("請確認要簽章/驗簽的內容");
        }
    }

    public boolean verifyHashSignature(SignPackage sigPack) throws SecurityException {
        return this.verifyHashSignature("SHA-1", sigPack);
    }

    public boolean verifyHashSignature(String algorithm, SignPackage sigPack) throws SecurityException {
        this.verifyHashSignPackage(sigPack);

        try {
            X509Certificate ex = this.generateCertFromByte(sigPack.getCertificate());
            return this.verifyHashedSignature(algorithm, ex, sigPack.getHashed(), sigPack.getSignature());
        } catch (InvalidKeyException | SignatureException | CertificateException | NoSuchAlgorithmException var4) {
            throw new SecurityException(var4);
        }
    }

    private boolean verifyHashedSignature(String algorithm, X509Certificate cert, byte[] hashed, byte[] sig) throws NoSuchAlgorithmException, InvalidKeyException, SecurityException, SignatureException {
        Signature signature = Signature.getInstance("NONEwithRSA");
        signature.initVerify(cert.getPublicKey());
        signature.update(this.paddingHashContent(algorithm, hashed));
        return signature.verify(sig);
    }

    private void verifyHashSignPackage(SignPackage signPack) {
        if (null == signPack) {
            throw new IllegalArgumentException("傳入空參數，以致錯誤");
        } else if (null != signPack.getHashed() && 0 != signPack.getHashed().length) {
            if (null != signPack.getSignature() && 0 != signPack.getSignature().length) {
                if (null == signPack.getCertificate() || 0 == signPack.getCertificate().length) {
                    throw new IllegalArgumentException("請確認要驗簽的憑證檔");
                }
            } else {
                throw new IllegalArgumentException("請確認要驗簽的簽章檔");
            }
        } else {
            throw new IllegalArgumentException("請確認要簽章/驗簽的內容");
        }
    }

    public SignPackage signContentByKeyStore(byte[] content, KeyStorePackage keyStorePack) throws SecurityException {
        return this.signContentByKeyStore("SHA-1", content, keyStorePack);
    }

    public SignPackage signContentByKeyStore(String algorithm, byte[] content, KeyStorePackage keyStorePack) throws SecurityException {
        try {
            return this.signHashedByKeyStore(algorithm, this.getContentHashByAlgorithm(algorithm, content), keyStorePack);
        } catch (NoSuchAlgorithmException var5) {
            throw new SecurityException(var5);
        }
    }

    private byte[] getContentHashByAlgorithm(String algorithm, byte[] content) throws NoSuchAlgorithmException {
        if ("MD5".toLowerCase().equals(algorithm.toLowerCase())) {
            return Hex.decode(DigestUtils.md5Hex(content));
        } else if ("SHA-1".toLowerCase().equals(algorithm.toLowerCase())) {
            return Hex.decode(DigestUtils.sha1Hex(content));
        } else if ("SHA-256".toLowerCase().equals(algorithm.toLowerCase())) {
            return Hex.decode(DigestUtils.sha256Hex(content));
        } else {
            throw new NoSuchAlgorithmException();
        }
    }

    public byte[] removeHeaderByAlgorithm(String algorithm, byte[] content) {
        try {
            byte[] header = this.getHeaderByAlgorithm(algorithm);

            for(int i = 0; i < header.length; ++i) {
                content = ArrayUtils.remove(content, 0);
            }

            return content;
        } catch (NoSuchAlgorithmException var5) {
            throw new AuthenticationServiceException("AP0006");
        }
    }

    public SignPackage signHashedByKeyStore(byte[] hashed, KeyStorePackage keyStorePack) throws SecurityException {
        return this.signHashedByKeyStore("SHA-1", hashed, keyStorePack);
    }

    public SignPackage signHashedByKeyStore(String algorithm, byte[] hashed, KeyStorePackage keyStorePack) throws SecurityException {
        PreconditionUtils.checkArguments(new Object[]{keyStorePack.getKeyStoreFile(), keyStorePack.getAlias(), keyStorePack.getPassword()});

        try {
            this.settingProvider();
            KeyStore ex = KeyStoreUtils.loadPKCS12KeyStore(keyStorePack.getKeyStoreFile(), keyStorePack.getPassword());
            PrivateKey privateKey = (PrivateKey)ex.getKey(keyStorePack.getAlias(), keyStorePack.getPassword().toCharArray());
            X509Certificate cert = (X509Certificate)ex.getCertificate(keyStorePack.getAlias());
            SignPackageBuilder builder = SignPackageBuilder.createSignPackageBuilder();
            return builder.setHashed(hashed).setCertificate(cert.getEncoded()).setSignature(this.signingSignature(algorithm, hashed, privateKey)).build();
        } catch (UnrecoverableKeyException | CertificateEncodingException | SignatureException | NoSuchProviderException | InvalidKeyException | KeyStoreException | NoSuchAlgorithmException var8) {
            throw new SecurityException(var8);
        }
    }

    private byte[] signingSignature(String algorithm, byte[] hashed, PrivateKey privateKey) throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException, SecurityException, SignatureException {
        Signature signature = Signature.getInstance("NONEwithRSA", "BC");
        signature.initSign(privateKey, new SecureRandom());
        signature.update(this.paddingHashContent(algorithm, hashed));
        return signature.sign();
    }

    private void settingProvider() {
        BouncyCastleProvider secProvider = new BouncyCastleProvider();
        Security.addProvider(secProvider);
    }

    public byte[] encryptByCert(byte[] content, byte[] certFile) throws SecurityException {
        PreconditionUtils.checkArguments(new Object[]{content, certFile});

        try {
            this.settingProvider();
            X509Certificate ex = this.generateCertFromByte(certFile);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(1, ex.getPublicKey());
            return cipher.doFinal(content);
        } catch (NoSuchAlgorithmException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | CertificateException | NoSuchPaddingException var5) {
            throw new SecurityException(var5);
        }
    }

    public byte[] encryptByKeyStore(byte[] content, KeyStorePackage keyStorePack) throws SecurityException {
        this.settingProvider();

        try {
            KeyStore ex = KeyStoreUtils.loadPKCS12KeyStore(keyStorePack.getKeyStoreFile(), keyStorePack.getPassword());
            X509Certificate cert = (X509Certificate)ex.getCertificate(keyStorePack.getAlias());
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(1, cert.getPublicKey());
            return cipher.doFinal(content);
        } catch (InvalidKeyException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | KeyStoreException | NoSuchAlgorithmException var6) {
            throw new SecurityException(var6);
        }
    }

    public byte[] decryptByKeyStore(byte[] content, KeyStorePackage keyStorePack) throws SecurityException {
        this.settingProvider();

        try {
            KeyStore ex = KeyStoreUtils.loadPKCS12KeyStore(keyStorePack.getKeyStoreFile(), keyStorePack.getPassword());
            PrivateKey privateKey = (PrivateKey)ex.getKey(keyStorePack.getAlias(), keyStorePack.getPassword().toCharArray());
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(2, privateKey);
            return cipher.doFinal(content);
        } catch (UnrecoverableKeyException | InvalidKeyException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | KeyStoreException | NoSuchAlgorithmException var6) {
            throw new SecurityException(var6);
        }
    }

    public boolean isCertValid(byte[] certFile, byte[] issuerCertFile) throws SecurityException {
        this.verifyCertificate(certFile);
        this.verifyCertificate(issuerCertFile);

        try {
            X509Certificate ex = this.generateCertFromByte(certFile);
            X509Certificate issuerCert = this.generateCertFromByte(issuerCertFile);
            return this.verifyCert(ex, issuerCert);
        } catch (CertificateException var5) {
            throw new SecurityException(var5);
        }
    }

    private boolean verifyCert(X509Certificate cert, X509Certificate issuerCert) {
        try {
            cert.verify(issuerCert.getPublicKey());
            return true;
        } catch (InvalidKeyException | NoSuchProviderException | SignatureException | CertificateException | NoSuchAlgorithmException var4) {
            return false;
        }
    }

    private void verifyCertificate(byte[] cert) {
        if (null == cert || 0 == cert.length) {
            throw new IllegalArgumentException("請確認憑證內容");
        }
    }

    public byte[] paddingHashContent(String algorithm, byte[] hashed) throws SecurityException {
        try {
            byte[] ex = this.getHeaderByAlgorithm(algorithm);
            byte[] result = new byte[ex.length + hashed.length];
            System.arraycopy(hashed, 0, result, result.length - hashed.length, hashed.length);
            System.arraycopy(ex, 0, result, 0, ex.length);
            return result;
        } catch (NoSuchAlgorithmException var5) {
            throw new SecurityException(var5);
        }
    }

    public String getB64PaddingHash(String algorithm, byte[] hashed) {
        try {
            byte[] tbsArray = ArrayUtils.addAll(this.getHeaderByAlgorithm(algorithm), Hex.decode(hashed));
            return DatatypeConverter.printBase64Binary(tbsArray);
        } catch (NoSuchAlgorithmException var4) {
            throw new ArchivesException(var4.getMessage());
        }
    }

    private byte[] getHeaderByAlgorithm(String algorithm) throws NoSuchAlgorithmException {
        if ("MD5".toLowerCase().equals(algorithm.toLowerCase())) {
            return PKISelfCASecurityUtils.MD5_HEADER;
        } else if ("SHA-1".toLowerCase().equals(algorithm.toLowerCase())) {
            return PKISelfCASecurityUtils.SHA1_HEADER;
        } else if ("SHA-256".toLowerCase().equals(algorithm.toLowerCase())) {
            return PKISelfCASecurityUtils.SHA256_HEADER;
        } else {
            throw new NoSuchAlgorithmException();
        }
    }
}
