package gov.archives.core.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("PersonData")
public class ModifyPersonDataEntity extends UserInfoEntity {
    private String loginCount;
    private String loginIP;
    private String loginTime;

    public ModifyPersonDataEntity() {
    }

    public String getLoginCount() {
        return this.loginCount;
    }

    public void setLoginCount(String loginCount) {
        this.loginCount = loginCount;
    }

    public String getLoginIP() {
        return this.loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getLoginTime() {
        return this.loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
}

