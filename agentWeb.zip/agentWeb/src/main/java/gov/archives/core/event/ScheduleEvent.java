package gov.archives.core.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ScheduleEvent extends BaseEvent {
    private static final Logger log = LoggerFactory.getLogger(ScheduleEvent.class);
    private static final String EVENT_NAME = "ScheduleEvent";
    private boolean isSuccess;

    public ScheduleEvent(Object source) {
        super(source);
    }

    public ScheduleEvent(Object source, boolean isSuccess) {
        super(source);
        this.isSuccess = isSuccess;
    }

    public String toString() {
        return "ScheduleEvent";
    }

    public void logEvent() {
        log.info("ScheduleEvent: " + this.source.getClass().getSimpleName() + " " + this.EXCUTE_RESULT + ": " + (this.isSuccess ? "success" : "fail"));
    }
}
