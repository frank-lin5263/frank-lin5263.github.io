package gov.archives.core.controller;

import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.UpdateCertVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.UpdateCertFacade;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.SessionManageService;
import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(
        path = {"/v1/systemTool/userManagement"}
)
public class UserAccountModificationController extends RestControllerBase {
    private static final String UPLOAD_CERT = "/upload/cert";
    @Autowired
    private UpdateCertFacade updateCertFacade;
    @Autowired
    private SessionManageService sessionManageService;

    public UserAccountModificationController() {
    }

    @PostMapping({"/upload/cert"})
    public ResponseEntity<RestResponse<Boolean>> uploadCert(@RequestParam("file") MultipartFile uploadFile, @RequestParam("account") String account, HttpServletRequest request, HttpServletResponse response) {
        Boolean isNeedLogout = this.updateCertFacade.isSomeAccount(account);

        try {
            UpdateCertVO certVO = this.updateCertFacade.checkCertFile(uploadFile);
            certVO.setAccount(account);
            this.updateCertFacade.updateCert(certVO);
            this.insertActionLogAndRsysLog("使用者管理憑證變更作業模組", "中");
            this.sessionLogout(account, request, response);
        } catch (Exception var10) {
            this.insertActionLog(request, "使用者管理憑證變更作業模組", CoreErrorMessage.findByCode("SYS0006"), "SYS0006", "高");
            this.exceptionHandle(var10);
        } finally {
            this.safeDeleteFile(this.updateCertFacade.getTempCerFolder());
        }

        RestResponse<Boolean> restResponse = new RestResponse();
        restResponse.setResultData(isNeedLogout);
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    public void sessionLogout(String account, HttpServletRequest request, HttpServletResponse response) {
        if (this.updateCertFacade.isSomeAccount(account)) {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (null != auth) {
                (new SecurityContextLogoutHandler()).logout(request, response, auth);
            }

            this.sessionManageService.removeAccountDetail(account);
        }

    }

    private void exceptionHandle(Exception e) {
        if (e instanceof ArchivesException) {
            throw ArchivesException.getInstanceByErrorCode(e.getMessage(), new Object[0]);
        } else if (e instanceof CredentialsExpiredException) {
            throw ArchivesException.getInstanceByErrorCode("AP0022", new Object[0]);
        } else {
            throw ArchivesException.getInstanceByErrorCode("SYS0006", new Object[]{e});
        }
    }

    private void safeDeleteFile(File file) {
        try {
            if (null != file) {
                FileUtils.forceDelete(file);
            }

        } catch (IOException var3) {
            throw new ArchivesException(var3.getMessage());
        }
    }
}
