package gov.archives.core.event.handler;

import gov.archives.core.event.ArchivesExceptionEvent;
import gov.archives.core.event.ScheduleEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class GlobalEventHandler implements ApplicationListener<ApplicationEvent> {
    public GlobalEventHandler() {
    }

    public void onApplicationEvent(ApplicationEvent event) {
        if (event instanceof ScheduleEvent) {
            ((ScheduleEvent)event).logEvent();
        } else if (event instanceof ArchivesExceptionEvent) {
            ((ArchivesExceptionEvent)event).logEvent();
        }

    }
}
