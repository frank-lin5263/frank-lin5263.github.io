package gov.archives.core.domain.vo;

import java.io.Serializable;

public class SignPackageData implements Serializable {
    private static final long serialVersionUID = -4774826177817351273L;
    public static final String PARAM_TBS = "content";
    public static final String PARAM_SIGNATURE = "signature";
    public static final String PARAM_B64_CERT = "certificate";
    public static final String PARAM_LOGIN_UUID = "login_uuid";
    private String content;
    private String signature;
    private String certificate;

    public SignPackageData() {
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSignature() {
        return this.signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getCertificate() {
        return this.certificate;
    }

    public void setCertificate(String certificate) {
        this.certificate = certificate;
    }

    public static final class Builder {
        private String content;
        private String signature;
        private String certificate;

        private Builder() {
        }

        public static SignPackageData.Builder create() {
            return new SignPackageData.Builder();
        }

        public SignPackageData build() {
            SignPackageData packageData = new SignPackageData();
            packageData.setContent(this.content);
            packageData.setSignature(this.signature);
            packageData.setCertificate(this.certificate);
            return packageData;
        }

        public SignPackageData.Builder setContent(String content) {
            this.content = content;
            return this;
        }

        public SignPackageData.Builder setSignature(String signature) {
            this.signature = signature;
            return this;
        }

        public SignPackageData.Builder setCertificate(String certificate) {
            this.certificate = certificate;
            return this;
        }
    }
}

