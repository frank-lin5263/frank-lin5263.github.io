package gov.archives.core.i18n;

public class I18nKeys {
    public I18nKeys() {
    }
}
