package gov.archives.core.mapper.query;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import java.util.List;
import java.util.UUID;

public interface RoleMenuMappingQueryMapper {
    List<RoleMenuMappingEntity> findByRoleName(String var1);

    List<RoleMenuMappingEntity> findByRoleSysId(UUID var1);
}
