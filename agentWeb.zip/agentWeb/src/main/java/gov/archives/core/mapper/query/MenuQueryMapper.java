package gov.archives.core.mapper.query;

import gov.archives.core.domain.entity.MenuEntity;
import java.util.List;
import java.util.UUID;

public interface MenuQueryMapper {
    MenuEntity findByMenuCode(String var1);

    List<MenuEntity> findAllMenu();

    MenuEntity findBySysId(UUID var1);
}
