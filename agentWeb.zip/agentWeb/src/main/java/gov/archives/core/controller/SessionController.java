package gov.archives.core.controller;

import gov.archives.agent.domain.vo.LogoutParams;
import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.SessionManageService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/session"})
public class SessionController extends RestControllerBase {
    private static final String SESSION_DETAIL = "/detail";
    private static final String SESSION_CHECK = "/checkSessionId";
    private static final String SESSION_EXPIRED = "/expired";
    private static final String SESSION_LOGOUT = "/logout";
    private static final String REST_EMPTY = "";
    @Autowired
    private SessionManageService sessionManageService;

    public SessionController() {
    }

    @RequestMapping(
            value = {"/detail"},
            method = {RequestMethod.GET}
    )
    public ResponseEntity<AccountDetail> getAccountDetail() {
        AccountDetail accountDetail = this.sessionManageService.getAccountDetail();
        HttpStatus status = null != accountDetail ? HttpStatus.OK : HttpStatus.NOT_FOUND;
        return new ResponseEntity(accountDetail, status);
    }

    @RequestMapping(
            value = {"/logout"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<RestResponse<String>> sessionLogout(@RequestBody LogoutParams params, HttpServletRequest request, HttpServletResponse response) {
        PreconditionUtils.checkArguments(new Object[]{params});
        String message = this.sessionManageService.executeSystemLogout(params.getSessionId(), params.getSignedToken());
        RestResponse<String> restResponse = ResponseBuilder.createResponseByData(message).build();
        this.logoutAction(request, response, params.getAccount(), params.getRemoteAddress());
        return new ResponseEntity(restResponse, HttpStatus.OK);
    }

    @RequestMapping(
            value = {"/checkSessionId"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<String> checkSession(@RequestBody AccountDetail accountDetail, HttpServletRequest request, HttpServletResponse response) {
        PreconditionUtils.checkArguments(new Object[]{accountDetail});
        HttpStatus status = this.sessionManageService.checkAccountSessionId() ? HttpStatus.OK : HttpStatus.CONFLICT;
        if (status.is4xxClientError()) {
            this.logoutAction(request, response, accountDetail.getAccount(), accountDetail.getRemoteAddress());
        }

        return new ResponseEntity("", status);
    }

    @RequestMapping(
            value = {"/expired"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<String> sessionExpired(@RequestBody AccountDetail accountDetail, HttpServletRequest request, HttpServletResponse response) {
        PreconditionUtils.checkArguments(new Object[]{accountDetail});
        this.logoutAction(request, response, accountDetail.getAccount(), accountDetail.getRemoteAddress());
        return new ResponseEntity("", HttpStatus.OK);
    }

    private void logoutAction(HttpServletRequest request, HttpServletResponse response, String currentAccount, String currentIp) {
        try {
            PreconditionUtils.checkArguments(new Object[]{currentAccount, currentIp});
            this.securityLogoutHandler(request, response);
            if (!request.getRequestURI().endsWith("/checkSessionId")) {
                this.sessionManageService.removeAccountDetail(currentAccount);
            }

            this.insertActionLogAndRsysLog("帳號登出模組", "低");
        } catch (ArchivesException var7) {
            ActionLogEntity actionLogEntity = super.buildActionLogEntity(currentAccount, currentIp, "帳號登出模組", CoreErrorMessage.findByCode("AP0018"), "AP0018", "高");
            super.actionLogService.insert(actionLogEntity);
            throw ArchivesException.getInstanceByErrorCode("AP0018", new Object[]{var7});
        }
    }

    private void securityLogoutHandler(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (null != auth) {
            (new SecurityContextLogoutHandler()).logout(request, response, auth);
        }

    }
}
