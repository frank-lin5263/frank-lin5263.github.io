package gov.archives.core.domain.vo;

public class RoleName {
    private String roleName;

    public RoleName() {
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}

