package gov.archives.core.security;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AuthInfoVO;
import gov.archives.core.domain.vo.SignPackageData;
import gov.archives.core.domain.vo.SignPackageData.Builder;
import gov.archives.core.facade.CaptchaPKIAuthenticationFacade;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.util.EncryptUtils;
import gov.archives.core.util.LogUtils;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

public final class CaptchaPKIAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
    private static final String POST_METHOD = "POST";
    private static final String CURRENT_CAPTCHA = "captcha";
    private static final String RANDOM_CAPTCHA = "CAPTCHA";
    private static final String SESSION_AUTH = "authorization";
    @Autowired
    private ActionLogService actionLogService;
    @Autowired
    private CaptchaPKIAuthenticationFacade authFacade;
    @Autowired
    private DigitalSignHandle digitalSignHandle;

    public CaptchaPKIAuthenticationFilter() {
    }

    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        AuthInfoVO authInfo = this.buildAuthInfoByRequest(request);

        try {
            this.checkPostMethod(request);
            this.authFacade.checkTryCount(authInfo);
            UserInfoEntity userInfo = this.authFacade.getUserInfoByAccount(authInfo.getAccount());
            this.authFacade.checkAccountStatus(authInfo, userInfo);
            this.checkCaptchaSuccess(request, authInfo);
            this.verifyCertificate(request);
            this.authFacade.resetAccountTryCount();
            CaptchaPKIAuthenticationToken authRequest = this.genAuthPKIToken(request, userInfo);
            this.setTempAttribute(request, authInfo, authRequest.getPassword());
            this.insertSuccessLog();
            return super.getAuthenticationManager().authenticate(authRequest);
        } catch (AuthenticationException var6) {
            this.insertExceptionLog(authInfo);
            throw new AuthenticationServiceException(var6.getMessage(), var6.getCause());
        }
    }

    private void checkPostMethod(HttpServletRequest request) {
        if (!request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
        }
    }

    private void checkCaptchaSuccess(HttpServletRequest request, AuthInfoVO authInfo) {
        String currentCaptcha = this.getRequestParameter(request, "captcha");
        String randomCaptcha = this.getRequestSessionAttribute(request, "CAPTCHA");
        this.authFacade.checkCaptcha(randomCaptcha, currentCaptcha, authInfo);
    }

    private void setTempAttribute(HttpServletRequest request, AuthInfoVO authInfo, String password) {
        HttpSession session = request.getSession();
        String accountAndCertHash = authInfo.getAccount() + ":" + password;
        String encryptAuth = new String(Base64.getEncoder().encode(accountAndCertHash.getBytes()), StandardCharsets.UTF_8);
        session.setAttribute("authorization", "Basic " + encryptAuth);
        this.authFacade.setAccountSession(authInfo, session.getId(), session.getMaxInactiveInterval());
    }

    private CaptchaPKIAuthenticationToken genAuthPKIToken(HttpServletRequest request, UserInfoEntity userInfo) {
        String password = UUID.randomUUID().toString();
        CaptchaPKIAuthenticationToken authRequest = new CaptchaPKIAuthenticationToken(userInfo.getAccount(), password, userInfo);
        this.setDetails(request, authRequest);
        return authRequest;
    }

    private SignPackageData getSignCertByRequest(HttpServletRequest request) {
        String content = this.getRequestParameter(request, "content");
        String b64signature = this.getRequestParameter(request, "signature");
        String b64certificate = this.getRequestParameter(request, "certificate");
        return Builder.create().setContent(content).setSignature(b64signature).setCertificate(b64certificate).build();
    }

    private void verifyCertificate(HttpServletRequest request) {
        SignPackageData signPackage = this.getSignCertByRequest(request);
        if (this.digitalSignHandle.verifySignature(signPackage)) {
            String token = (String)request.getSession().getAttribute("login_uuid");
            String decryptToken = EncryptUtils.decrypt(signPackage.getContent());
            if (!token.equals(decryptToken)) {
                throw new AuthenticationServiceException("AP0006");
            }
        } else {
            throw new AuthenticationServiceException("AP0006");
        }
    }

    private AuthInfoVO buildAuthInfoByRequest(HttpServletRequest request) {
        String account = this.getRequestParameter(request, "account");
        PreconditionUtils.checkArguments(new Object[]{account});
        String cardNumber = request.getParameter("cardNo");
        String sessionId = request.getRequestedSessionId();
        String remoteAddr = request.getRemoteAddr();
        Long lastAccessTime = request.getSession().getLastAccessedTime();
        this.actionLogService.setSuccessActionLog(account, remoteAddr);
        return gov.archives.core.domain.vo.AuthInfoVO.Builder.create().setAccount(account).setCardNum(cardNumber).setSessionId(sessionId).setIpAddress(remoteAddr).setLastAccessedTime(new Timestamp(lastAccessTime)).build();
    }

    private String getRequestParameter(HttpServletRequest request, String paraKey) {
        String parameter = request.getParameter(paraKey);
        PreconditionUtils.checkArguments(new Object[]{parameter});
        return parameter;
    }

    private String getRequestSessionAttribute(HttpServletRequest request, String paraKey) {
        Object parameter = request.getSession().getAttribute(paraKey);
        PreconditionUtils.checkArguments(new Object[]{parameter});
        return parameter.toString();
    }

    private void insertSuccessLog() {
        this.actionLogService.saveSuccessActionAndRsysLog("自然人憑證簽章驗證登入模組", "低", new Timestamp(System.currentTimeMillis()));
    }

    private void insertExceptionLog(AuthInfoVO authInfo) {
        this.actionLogService.insert(gov.archives.core.domain.entity.ActionLogEntity.Builder.create().setActionItem("自然人憑證簽章驗證登入模組").setActionResult(LogUtils.getErrorMessage("SYS0012")).setErrorCode("SYS0012").setEventLevel("高").setActorAccount(authInfo.getAccount()).setRemoteIp(authInfo.getIpAddress()).setActionTime(new Timestamp(System.currentTimeMillis())).build());
    }
}
