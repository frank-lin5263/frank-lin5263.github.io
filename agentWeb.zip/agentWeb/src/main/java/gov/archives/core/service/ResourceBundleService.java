package gov.archives.core.service;

import java.util.Properties;

public interface ResourceBundleService {
    Properties getAll();

    String get(String var1);

    boolean containsKey(String var1);

    String getFormatted(String var1, Object... var2);
}
