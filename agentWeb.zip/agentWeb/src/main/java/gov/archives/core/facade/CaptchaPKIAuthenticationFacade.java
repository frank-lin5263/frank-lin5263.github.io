package gov.archives.core.facade;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AuthInfoVO;

public interface CaptchaPKIAuthenticationFacade {
    String nonICConnect = "連線成功";

    UserInfoEntity getUserInfoByAccount(String var1);

    void checkTryCount(AuthInfoVO var1);

    void checkCaptcha(String var1, String var2, AuthInfoVO var3);

    void checkAccountStatus(AuthInfoVO var1, UserInfoEntity var2);

    void resetAccountTryCount();

    void setAccountSession(AuthInfoVO var1, String var2, Integer var3);
}
