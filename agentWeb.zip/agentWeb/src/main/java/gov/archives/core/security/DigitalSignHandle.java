package gov.archives.core.security;

import gov.archives.core.domain.vo.SignPackageData;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.iii.common.util.PreconditionUtils;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

@Component
public class DigitalSignHandle {
    public DigitalSignHandle() {
    }

    public X509Certificate transBase64CertIntoX509(String b64Cert) throws AuthenticationException {
        PreconditionUtils.checkArguments(new Object[]{b64Cert});

        try {
            CertificateFactory cf = CertificateFactory.getInstance("X509");
            X509Certificate x509 = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(Base64.getDecoder().decode(b64Cert)));
            this.checkKeyUsage(x509);
            if (this.isCredentialsExpired(x509, new Date(System.currentTimeMillis()))) {
                throw new CredentialsExpiredException("AP0004");
            } else {
                return x509;
            }
        } catch (CertificateException var4) {
            throw new AuthenticationServiceException("AP0006");
        }
    }

    private void checkKeyUsage(X509Certificate signCert) throws CertificateException {
        boolean[] usage = signCert.getKeyUsage();
        if (!usage[0]) {
            throw new CertificateException();
        }
    }

    public X509Certificate readX509FromFile(File file) throws AuthenticationException {
        PreconditionUtils.checkArguments(new Object[]{file});

        try {
            byte[] data = FileUtils.readFileToByteArray(file);
            if (data == null) {
                throw new CertificateException("AP0005");
            } else {
                CertificateFactory cf = CertificateFactory.getInstance("X509");
                X509Certificate x509 = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(data));
                this.checkKeyUsage(x509);
                if (this.isCredentialsExpired(x509, new Date(System.currentTimeMillis()))) {
                    throw new CredentialsExpiredException("AP0004");
                } else {
                    return x509;
                }
            }
        } catch (IOException | CertificateException var5) {
            throw new AuthenticationServiceException("AP0005");
        }
    }

    public void saveCertFile(File saveCertFile, X509Certificate x509) throws AuthenticationException {
        PreconditionUtils.checkArguments(new Object[]{x509});

        try {
            FileUtils.writeByteArrayToFile(saveCertFile, x509.getEncoded());
        } catch (IOException | CertificateEncodingException var4) {
            throw new AuthenticationServiceException("AP0006");
        }
    }

    private boolean isCredentialsExpired(X509Certificate x509, Date lastTime) {
        return lastTime.toInstant().isAfter(x509.getNotAfter().toInstant()) | lastTime.toInstant().isBefore(x509.getNotBefore().toInstant());
    }

    public boolean verifySignature(SignPackageData certData) {
        PreconditionUtils.checkArguments(new Object[]{certData});

        boolean verify;
        try {
            Signature sign = Signature.getInstance("SHA256withRSA");
            sign.initVerify(this.transBase64CertIntoX509(certData.getCertificate()));
            sign.update(certData.getContent().getBytes());
            verify = sign.verify(Base64.getDecoder().decode(certData.getSignature()));
        } catch (InvalidKeyException | NoSuchAlgorithmException | SignatureException var4) {
            verify = false;
        }

        return verify;
    }

    private X509Certificate transCerFileIntoX509Cert(File cerFile) throws AuthenticationException {
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X509");
            X509Certificate x509 = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(FileUtils.readFileToByteArray(cerFile)));
            this.checkKeyUsage(x509);
            if (this.isCredentialsExpired(x509, new Date(System.currentTimeMillis()))) {
                throw new CredentialsExpiredException("AP0004");
            } else {
                return x509;
            }
        } catch (CertificateException | IOException var4) {
            throw new AuthenticationServiceException("AP0006");
        }
    }
}
