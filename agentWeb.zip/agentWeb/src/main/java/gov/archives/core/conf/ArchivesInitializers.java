package gov.archives.core.conf;

public class ArchivesInitializers {
    public ArchivesInitializers() {
    }

    public static synchronized PropertyInitializer getPropertyInitializer() {
        return new PropertyInitializer();
    }

    public static synchronized SecKeyInitializer getSecKeyInitializer() {
        return new SecKeyInitializer();
    }
}
