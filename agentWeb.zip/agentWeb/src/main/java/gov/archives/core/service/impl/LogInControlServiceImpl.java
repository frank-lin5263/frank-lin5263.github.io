package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.LogInControlEntity;
import gov.archives.core.mapper.command.LogInControlCommandMapper;
import gov.archives.core.mapper.query.LogInControlQueryMapper;
import gov.archives.core.service.LogInControlService;
import java.util.HashMap;
import java.util.Map;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LogInControlServiceImpl implements LogInControlService {
    @Autowired
    private LogInControlQueryMapper queryMapper;
    @Autowired
    private LogInControlCommandMapper commandMapper;

    public LogInControlServiceImpl() {
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insert(LogInControlEntity loginControlEntry) {
        PreconditionUtils.checkArguments(new Object[]{loginControlEntry});
        this.commandMapper.save(loginControlEntry);
    }

    public void update(LogInControlEntity loginCtrl) {
        PreconditionUtils.checkArguments(new Object[]{loginCtrl});
        this.commandMapper.update(loginCtrl);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void delete(LogInControlEntity loginControlEntry) {
        PreconditionUtils.checkArguments(new Object[]{loginControlEntry});
        this.commandMapper.remove(loginControlEntry);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public LogInControlEntity getBySessionIdAndAccount(String sessionId, String loginAccount) {
        PreconditionUtils.checkArguments(new Object[]{sessionId, loginAccount});
        Map<String, String> params = new HashMap();
        params.put("sessionId", sessionId);
        params.put("loginAccount", loginAccount);
        return this.queryMapper.findBySessionIdAndAccount(params);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public LogInControlEntity getBySessionIdAndAccountMaxlimitTime(String sessionId, String loginAccount) {
        PreconditionUtils.checkArguments(new Object[]{sessionId, loginAccount});
        Map<String, String> params = new HashMap();
        params.put("sessionId", sessionId);
        params.put("loginAccount", loginAccount);
        return this.queryMapper.findBySessionIdAndAccountMaxlimitTime(params);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public LogInControlEntity getByAccountMaxlimitTime(String loginAccount) {
        PreconditionUtils.checkArguments(new Object[]{loginAccount});
        return this.queryMapper.findByAccountMaxlimitTime(loginAccount);
    }
}
