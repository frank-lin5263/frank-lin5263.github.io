package gov.archives.core.security.access.intercept;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Repository;

@Repository("requestConfigMappingService")
public class CustomRequestConfigMappingService implements RequestConfigMappingService {
    private static final Logger log = LoggerFactory.getLogger(CustomRequestConfigMappingService.class);
    private RoleService roleService;
    private MenuService menuService;
    private Map<String, String> roleTypeMap;

    @Autowired
    public CustomRequestConfigMappingService(RoleService roleService, MenuService menuService) {
        this.roleService = roleService;
        this.menuService = menuService;
        this.roleTypeMap = new HashMap();
    }

    public List<RequestConfigMapping> getRequestConfigMappings() {
        this.roleTypeMap.clear();
        this.genRoleTypeMap();
        return this.roleMenuRequestUrlMap();
    }

    public Collection<? extends GrantedAuthority> createAuthorities(UserInfoEntity user) {
        RoleEntity roleEntity = this.roleService.getBySysId(user.getRoleSysId());
        if (null != roleEntity) {
            String roleName = (String)this.roleTypeMap.get(roleEntity.getRoleName());
            if (null != roleName) {
                return AuthorityUtils.createAuthorityList(new String[]{roleName});
            }
        }

        return null;
    }

    private void genRoleTypeMap() {
        if (this.roleTypeMap.isEmpty()) {
            this.roleTypeMap = (Map)this.roleService.getRoleList().stream().filter((roleEntity) -> {
                return roleEntity.getActiveStatus() >= 0;
            }).collect(Collectors.toMap(RoleEntity::getRoleName, (roleEntity) -> {
                return "ROLE_" + roleEntity.getRoleName();
            }));
        }

    }

    private List<RequestConfigMapping> defaultRequestUrlMap() {
        List<String> roleList = (List)this.roleService.getRoleList().stream().map(RoleEntity::getRoleName).collect(Collectors.toList());
        SecurityConfig allRoleConfig = this.createSecurityConfig(roleList);
        SecurityConfig permitAllConfig = new SecurityConfig("permitAll");
        List<RequestConfigMapping> requestConfigMappingList = new ArrayList();
        requestConfigMappingList.add(this.buildRequestConfigMapping("/index", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/errors/*", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/core/index", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/index#/home/not_auth", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/index.jsp", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/login", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/captcha.jpg", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/resources/**", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/core/menu", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/session/**", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/controllers/HomeController.js", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/views/home.html", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/home", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/assets/**", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/templates/**", permitAllConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/index#/home/auth_home", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/core/menu/all", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/core/rest/urlMap", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/token/**", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/logout/**", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/conflict", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/v1/cert/check", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/controllers/**", allRoleConfig));
        requestConfigMappingList.add(this.buildRequestConfigMapping("/archivesapps/views/**", allRoleConfig));
        return requestConfigMappingList;
    }

    private List<RequestConfigMapping> roleMenuRequestUrlMap() {
        List<RequestConfigMapping> requestConfigMapping = this.defaultRequestUrlMap();
        List<String> urlType = Arrays.asList("/archivesapps/controllers/", "/archivesapps/views/", "/v1/");
        Iterator var3 = urlType.iterator();

        while(var3.hasNext()) {
            String url = (String)var3.next();
            this.genRequestConfigMapping(url, requestConfigMapping);
        }

        return requestConfigMapping;
    }

    private SecurityConfig createSecurityConfig(List<String> roleList) {
        StringBuilder builder = (new StringBuilder()).append("hasAnyRole(");
        Iterator var3 = roleList.iterator();

        while(var3.hasNext()) {
            String roleName = (String)var3.next();
            if (roleList.lastIndexOf(roleName) < roleList.size() - 1) {
                builder.append("'").append(roleName).append("'").append(",");
            } else {
                builder.append("'").append(roleName).append("'").append(")");
            }
        }

        return new SecurityConfig(builder.toString());
    }

    private void genRequestConfigMapping(String url, List<RequestConfigMapping> requestConfigMapping) {
        List<RoleEntity> roleEntityList = this.roleService.getRoleList();
        Map<String, List<String>> roleMenuUrlMapping = new TreeMap();
        Iterator var5 = roleEntityList.iterator();

        while(var5.hasNext()) {
            RoleEntity entity = (RoleEntity)var5.next();
            RoleMenuMapping roleMenuMapping = this.roleService.getMenuMappingByRoleName(entity.getRoleName());
            if (null != roleMenuMapping) {
                this.genRequestUrlMap(roleMenuMapping, roleMenuUrlMapping, url);
            }
        }

        this.addRequestConfigMappingList(roleMenuUrlMapping, requestConfigMapping);
    }

    private void genRequestUrlMap(RoleMenuMapping roleMenuMapping, Map<String, List<String>> requestUrlMapping, String url) {
        RoleEntity roleEntity = roleMenuMapping.getRole();
        if (null != roleEntity && 1 == roleEntity.getActiveStatus()) {
            Iterator var5 = roleMenuMapping.getMenus().iterator();

            while(var5.hasNext()) {
                MenuEntity entity = (MenuEntity)var5.next();
                if (entity != null) {
                    UUID topMenuId = entity.getTopMenuId();
                    MenuEntity topMenu = this.menuService.getBySysId(topMenuId);
                    if (topMenu != null) {
                        String requestUrl = this.buildRequestUrl(url, topMenu, entity);
                        if (null != requestUrl) {
                            List<String> roleList = (List)requestUrlMapping.get(requestUrl);
                            if (null == roleList) {
                                roleList = new ArrayList();
                            }

                            ((List)roleList).add(roleEntity.getRoleName());
                            requestUrlMapping.put(requestUrl, roleList);
                        }
                    } else {
                        log.warn("topMenu: " + topMenu);
                    }
                } else {
                    log.warn("MenuEntity: " + entity);
                }
            }
        }

    }

    private void addRequestConfigMappingList(Map<String, List<String>> roleMenuUrlMapping, List<RequestConfigMapping> requestConfigMapping) {
        Iterator var3 = roleMenuUrlMapping.keySet().iterator();

        while(var3.hasNext()) {
            String url = (String)var3.next();
            SecurityConfig config = this.createSecurityConfig((List)roleMenuUrlMapping.get(url));
            requestConfigMapping.add(this.buildRequestConfigMapping(url, config));
        }

    }

    private String buildRequestUrl(String url, MenuEntity topMenu, MenuEntity subMenu) {
        StringBuilder requestURL = (new StringBuilder()).append(url);
        if (url.equals("/archivesapps/controllers/")) {
            requestURL.append(topMenu.getMenuCode()).append("/").append(subMenu.getMenuCode()).append("Controller.js");
        } else if (url.equals("/archivesapps/views/")) {
            requestURL.append(topMenu.getMenuCode()).append("/").append(this.toLowerCamelCase(subMenu.getMenuCode())).append(".html");
        } else if (url.equals("/v1/")) {
            requestURL.append(this.toLowerCamelCase(topMenu.getMenuCode())).append("/").append(this.toLowerCamelCase(subMenu.getMenuCode())).append("/**");
        }

        return requestURL.toString();
    }

    private RequestConfigMapping buildRequestConfigMapping(String pattern, SecurityConfig permitAllConfig) {
        return new RequestConfigMapping(new AntPathRequestMatcher(pattern), permitAllConfig);
    }

    private String toLowerCamelCase(String menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }
}
