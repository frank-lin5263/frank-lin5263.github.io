package gov.archives.core.service.impl;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.HomeService;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.ServletContext;
import org.apache.commons.io.IOUtils;
import org.iii.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;

@Service
public class HomeServiceImpl implements HomeService, ServletContextAware {
    private static final Logger log = LoggerFactory.getLogger(HomeServiceImpl.class);
    private static final String WEB_INFO_PATH = "/WEB-INF";
    private static final String VIEWS_PATH = "/views";
    private static final String OUT_PATH = "/homeout";
    private static final String HOME_OUTPUT = "auth_home";
    private static final String DEFAULT_OUTPUT_CONTENT = "無公告內容";
    private ServletContext servletContext;

    public HomeServiceImpl() {
    }

    public void setServletContext(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    public String readHomePageTextASString(String authFile) {
        FileReader fr = null;
        BufferedReader br = null;

        String outputString;
        try {
            fr = new FileReader(this.getHomePageTextPath(authFile));
            br = new BufferedReader(fr);
            outputString = IOUtils.toString(br);
        } catch (IOException var13) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var13});
        } finally {
            try {
                if (null != br) {
                    br.close();
                    fr.close();
                }
            } catch (IOException var12) {
                log.error(var12.getClass().getName() + StringUtils.stackTraceFromException(var12));
            }

        }

        return outputString;
    }

    private String getHomePageTextPath(String authFile) {
        String homeOutPutPath = this.servletContext.getRealPath("") + "/WEB-INF" + "/views" + "/homeout";
        this.initHomeOuptFolder(homeOutPutPath);
        return homeOutPutPath + "/" + authFile;
    }

    private void initHomeOuptFolder(String homeOutPutPath) {
        if (!org.iii.common.util.IOUtils.isFolderExist(homeOutPutPath)) {
            boolean isSuccess = (new File(homeOutPutPath)).mkdirs();
            if (!isSuccess) {
                throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
            }

            log.info(homeOutPutPath + " 建立成功");
        }

    }
}
