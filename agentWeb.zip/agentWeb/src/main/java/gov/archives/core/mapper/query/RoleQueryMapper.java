package gov.archives.core.mapper.query;

import gov.archives.core.domain.entity.RoleEntity;
import java.util.List;
import java.util.UUID;

public interface RoleQueryMapper {
    List<RoleEntity> getRoleByStatus(int var1);

    List<RoleEntity> findHaveSame(RoleEntity var1);

    RoleEntity findById(UUID var1);

    RoleEntity findByRoleName(String var1);

    List<RoleEntity> list();
}
