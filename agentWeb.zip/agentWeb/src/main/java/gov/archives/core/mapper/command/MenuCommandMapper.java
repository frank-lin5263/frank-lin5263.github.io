package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.MenuEntity;

public interface MenuCommandMapper {
    void save(MenuEntity var1);

    void update(MenuEntity var1);

    void remove(MenuEntity var1);
}
