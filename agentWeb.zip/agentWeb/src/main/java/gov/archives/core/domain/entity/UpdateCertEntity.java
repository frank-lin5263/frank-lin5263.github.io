package gov.archives.core.domain.entity;

import java.io.Serializable;

public class UpdateCertEntity extends BaseEntity implements Serializable {
    private String account;
    private String cardNumber;
    private String certHash;
    private Integer accountStatus;

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getCardNumber() {
        return this.cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCertHash() {
        return this.certHash;
    }

    public void setCertHash(String certHash) {
        this.certHash = certHash;
    }

    public Integer getAccountStatus() {
        return this.accountStatus;
    }

    public void setAccountStatus(Integer accountStatus) {
        this.accountStatus = accountStatus;
    }

    private UpdateCertEntity(UpdateCertEntity.Builder builder) {
        this.account = builder.account;
        this.cardNumber = builder.cardNumber;
        this.certHash = builder.certHash;
        this.accountStatus = builder.accountStatus;
        this.initUpdate(this.account);
    }

    public static UpdateCertEntity.Builder newUpdateCertEntity() {
        return new UpdateCertEntity.Builder();
    }

    public static final class Builder {
        private String account;
        private String cardNumber;
        private String certHash;
        private Integer accountStatus;

        private Builder() {
        }

        public UpdateCertEntity build() {
            return new UpdateCertEntity(this);
        }

        public UpdateCertEntity.Builder setAccount(String account) {
            this.account = account;
            return this;
        }

        public UpdateCertEntity.Builder setCardNumber(String cardNumber) {
            this.cardNumber = cardNumber;
            return this;
        }

        public UpdateCertEntity.Builder setCertHash(String certHash) {
            this.certHash = certHash;
            return this;
        }

        public UpdateCertEntity.Builder setAccountStatus(Integer accountStatus) {
            this.accountStatus = accountStatus;
            return this;
        }
    }
}

