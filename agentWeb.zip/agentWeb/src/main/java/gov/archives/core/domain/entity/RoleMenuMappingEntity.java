package gov.archives.core.domain.entity;

import java.util.UUID;
import org.apache.ibatis.type.Alias;

@Alias("RoleMenuMapping")
public class RoleMenuMappingEntity extends BaseEntity {
    private UUID roleSysId;
    private UUID menuSysId;

    public RoleMenuMappingEntity() {
    }

    public static synchronized RoleMenuMappingEntity getInstanceByRoleSysIdAndMenuSysId(UUID roleSysId, UUID menuSysId) {
        RoleMenuMappingEntity entity = new RoleMenuMappingEntity();
        entity.setRoleSysId(roleSysId);
        entity.setMenuSysId(menuSysId);
        return entity;
    }

    public UUID getRoleSysId() {
        return this.roleSysId;
    }

    public void setRoleSysId(UUID roleSysId) {
        this.roleSysId = roleSysId;
    }

    public UUID getMenuSysId() {
        return this.menuSysId;
    }

    public void setMenuSysId(UUID menuSysId) {
        this.menuSysId = menuSysId;
    }
}

