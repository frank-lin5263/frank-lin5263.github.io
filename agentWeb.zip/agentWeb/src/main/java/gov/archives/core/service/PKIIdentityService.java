package gov.archives.core.service;

import java.security.cert.X509Certificate;

public interface PKIIdentityService {
    String getSHA256CertHash(String var1);

    String getSHA256CertHash(X509Certificate var1);

    void checkDigitalSignatureCert(String var1);
}
