package gov.archives.core.exception;

import gov.archives.core.message.CoreErrorMessage;

public class ArchivesException extends RuntimeException {
    public ArchivesException(String msg) {
        super(msg);
    }

    public ArchivesException(String msg, Throwable t) {
        super(msg, t);
    }

    public static ArchivesException getInstanceByErrorCode(String errorCode, Object... objects) {
        String message = CoreErrorMessage.findByCode(errorCode);
        return new ArchivesException(errorCode, new Throwable(message));
    }
}