package gov.archives.core.controller;

import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.util.CaptchaUtils;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CaptchaController extends RestControllerBase {
    private static final String FILE_TYPE = "jpeg";
    private static final int MIN_LENGTH = 4;
    private static final int MAX_LENGTH = 6;
    private static final String SALT_CHARS = "abcdefghijklmnopqrstuvwxyz";
    private static final int EXPIRE_TIME = 0;
    private static final int MAX_AGE = 0;
    private static final int WIDTH = 140;
    private static final int HEIGHT = 50;
    private static final Color BG_COLOR = new Color(238, 241, 245);
    private static final Color FG_COLOR = new Color(15, 15, 15);
    private static final Font FONT = new Font("SansSerif", 0, 30);
    private static final int INIT_X = 0;
    private static final int INIT_Y = 0;
    private static final int DRAW_X = 16;
    private static final int DRAW_Y = 30;

    public CaptchaController() {
    }

    @RequestMapping(
            value = {"/captcha"},
            method = {RequestMethod.GET}
    )
    public void GenCaptchaPicture(HttpServletRequest request, HttpServletResponse response) {
        try {
            this.initResponse(response);
            String captchaStr = CaptchaUtils.generateCaptcha(4, 6, "abcdefghijklmnopqrstuvwxyz");
            BufferedImage captcha = this.drawCaptcha(captchaStr);
            this.setCaptcha(request, captchaStr);
            this.responseCaptcha(response, captcha);
        } catch (IOException var5) {
            this.insertActionLog(request, "圖形驗證碼模組", CoreErrorMessage.findByCode("SYS0000"), "SYS0000", "高");
        }

    }

    private void initResponse(HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0L);
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Max-Age", 0L);
    }

    private BufferedImage drawCaptcha(String captchaStr) {
        BufferedImage cpimg = new BufferedImage(140, 50, 1);
        Graphics g = cpimg.createGraphics();
        g.setFont(FONT);
        g.setColor(BG_COLOR);
        g.fillRect(0, 0, 140, 50);
        g.setColor(FG_COLOR);
        g.drawString(captchaStr, 16, 30);
        return cpimg;
    }

    private void setCaptcha(HttpServletRequest request, String captchaStr) {
        request.getSession(true).setAttribute("CAPTCHA", captchaStr);
    }

    private void responseCaptcha(HttpServletResponse response, BufferedImage captcha) throws IOException {
        OutputStream outputStream = response.getOutputStream();
        response.setContentType("image/jpeg");
        ImageIO.write(captcha, "jpeg", outputStream);
        outputStream.close();
    }
}
