package gov.archives.core.util;

import java.lang.reflect.InvocationTargetException;
import org.iii.common.exception.ApplicationException;

public abstract class BeanUtils {
    private BeanUtils() {
    }

    public static void copyProperties(Object dest, Object source) {
        try {
            org.apache.commons.beanutils.BeanUtils.copyProperties(dest, source);
        } catch (IllegalAccessException | InvocationTargetException var3) {
            throw new ApplicationException(var3);
        }
    }
}
