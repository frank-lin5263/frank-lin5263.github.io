package gov.archives.core.security;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.access.intercept.RequestConfigMappingService;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

@Component
public class DocumentUserAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    private RequestConfigMappingService requestConfigMappingService;

    public DocumentUserAuthenticationProvider() {
    }

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        CaptchaPKIAuthenticationToken token = (CaptchaPKIAuthenticationToken)authentication;
        UserInfoEntity user = token.getUser();
        Collection<? extends GrantedAuthority> authorityList = this.requestConfigMappingService.createAuthorities(user);
        if (null == authorityList) {
            throw new AuthenticationServiceException("AP0016");
        } else {
            return new CaptchaPKIAuthenticationToken(user, user.getCertHash(), authorityList);
        }
    }

    public boolean supports(Class<?> authentication) {
        return authentication.getSimpleName().equals(CaptchaPKIAuthenticationToken.class.getSimpleName());
    }
}

