package gov.archives.core.controller;

import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.ActionLogEntity.Builder;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.util.LogUtils;
import gov.archives.core.util.UserInfoUtil;
import java.sql.Timestamp;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

public class RestControllerBase {
    @Autowired
    protected ActionLogService actionLogService;

    public RestControllerBase() {
    }

    protected ActionLogEntity buildActionLogEntity(HttpServletRequest request, String actionModule, String resultMessage, String errorCode, String eventLevel) {
        return this.buildActionLogEntity(UserInfoUtil.getCurrentAccount(), request.getRemoteAddr(), actionModule, resultMessage, errorCode, eventLevel);
    }

    protected ActionLogEntity buildActionLogEntity(String account, String currentIp, String actionModule, String resultMessage, String errorCode, String eventLevel) {
        return Builder.create().setActionItem(actionModule).setActionResult(LogUtils.getErrorMessage(resultMessage)).setErrorCode(errorCode).setEventLevel(eventLevel).setActorAccount(account).setRemoteIp(currentIp).setActionTime(new Timestamp(System.currentTimeMillis())).build();
    }

    protected void insertActionLogAndRsysLog(String actionItem, String eventLevel) {
        this.actionLogService.saveSuccessActionAndRsysLog(actionItem, eventLevel, new Timestamp(System.currentTimeMillis()));
    }

    protected void insertActionLogAndRsysLog(HttpServletRequest request, String actionModule, String resultMessage, String errorCode, String eventLevel) {
        this.actionLogService.insertsAndRsysLog(this.buildActionLogEntity(request, actionModule, resultMessage, errorCode, eventLevel));
    }

    protected void insertActionLog(HttpServletRequest request, String actionModule, String resultMessage, String errorCode, String eventLevel) {
        this.actionLogService.insert(this.buildActionLogEntity(request, actionModule, resultMessage, errorCode, eventLevel));
    }

    protected String getCurrentAccount() {
        return UserInfoUtil.getCurrentAccount();
    }

    protected boolean validateFiled(String filed, String regex) {
        return null == filed || 0 >= filed.length() || Pattern.compile(regex).matcher(filed).matches();
    }
}

