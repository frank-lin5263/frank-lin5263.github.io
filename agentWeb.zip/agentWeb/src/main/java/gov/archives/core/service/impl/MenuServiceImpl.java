package gov.archives.core.service.impl;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.domain.vo.TopMenuVo.Builder;
import gov.archives.core.mapper.command.MenuCommandMapper;
import gov.archives.core.mapper.query.MenuQueryMapper;
import gov.archives.core.service.MenuService;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class MenuServiceImpl implements MenuService {
    @Autowired
    private MenuQueryMapper queryMapper;
    @Autowired
    private MenuCommandMapper commandMapper;

    public MenuServiceImpl() {
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public MenuEntity getByMenuCode(String menuCode) {
        PreconditionUtils.checkArguments(new Object[]{menuCode});
        return this.queryMapper.findByMenuCode(menuCode);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public MenuEntity getBySysId(UUID sysId) {
        PreconditionUtils.checkArguments(new Object[]{sysId});
        return this.queryMapper.findBySysId(sysId);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public List<MenuEntity> getAllMenu() {
        return this.queryMapper.findAllMenu();
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insert(MenuEntity menu) {
        PreconditionUtils.checkArguments(new Object[]{menu});
        this.commandMapper.save(menu);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void update(MenuEntity menu) {
        PreconditionUtils.checkArguments(new Object[]{menu});
        this.commandMapper.update(menu);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void delete(MenuEntity menu) {
        PreconditionUtils.checkArguments(new Object[]{menu});
        this.commandMapper.remove(menu);
    }

    public Map<Integer, TopMenuVo> getMenuTree() {
        return this.getMenuTree(this.getAllMenu());
    }

    public Map<Integer, TopMenuVo> getMenuTree(List<MenuEntity> menuEntities) {
        List<MenuEntity> allMenu = this.getAllMenu();
        if (!CollectionUtils.isEmpty(menuEntities) && !CollectionUtils.isEmpty(allMenu)) {
            Map<Integer, TopMenuVo> resultMenu = new LinkedHashMap();
            List<MenuEntity> topMenus = (List)allMenu.stream().filter((menu) -> {
                return menu.getTopMenuId().equals(CoreConf.DEFAULT_ID);
            }).collect(Collectors.toList());
            topMenus.stream().forEach((top) -> {
                Map<Integer, MenuEntity> subMenu = (Map)menuEntities.stream().filter((sub) -> {
                    return sub.getTopMenuId().equals(top.getSysId());
                }).collect(Collectors.toMap(MenuEntity::getMenuSeq, Function.identity()));
                if (!MapUtils.isEmpty(subMenu)) {
                    resultMenu.put(top.getMenuSeq(), Builder.create().setMenuCode(top.getMenuCode()).setMenuName(top.getMenuName()).setSubMenus(subMenu).build());
                }

            });
            return resultMenu;
        } else {
            return new HashMap();
        }
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public Map<String, String> getMenuUrlMap() {
        Map<String, String> menuUrlMap = new HashMap();
        List<MenuEntity> menuEntityList = this.getAllMenu();
        Iterator var3 = menuEntityList.iterator();

        while(var3.hasNext()) {
            MenuEntity subMenu = (MenuEntity)var3.next();
            MenuEntity topMenu = this.getBySysId(subMenu.getTopMenuId());
            if (null != topMenu) {
                menuUrlMap.put(this.toLowerCamelCase(subMenu.getMenuCode()), "/" + this.toLowerCamelCase(topMenu.getMenuCode()) + "/" + this.toLowerCamelCase(subMenu.getMenuCode()));
            }
        }

        return menuUrlMap;
    }

    private String toLowerCamelCase(String menuCode) {
        return menuCode.substring(0, 1).toLowerCase() + menuCode.substring(1);
    }
}
