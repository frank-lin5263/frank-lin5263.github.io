package gov.archives.core.security;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.security.access.intercept.RequestConfigMappingService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.RandomHahUtils;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class RestAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    private UserInfoService userService;
    @Autowired
    private RequestConfigMappingService requestConfigMappingService;

    public RestAuthenticationProvider() {
    }

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken)authentication;
        String account = (String)auth.getPrincipal();
        UserInfoEntity user = this.userService.getByAccount(account);
        if (null == user) {
            throw new UsernameNotFoundException("Invalid account.");
        } else {
            Collection<? extends GrantedAuthority> authorityList = this.requestConfigMappingService.createAuthorities(user);
            if (null == authorityList) {
                throw new AuthenticationServiceException("AP0016");
            } else {
                return new UsernamePasswordAuthenticationToken(account, RandomHahUtils.genRandomHash(), authorityList);
            }
        }
    }

    public boolean supports(Class<?> authentication) {
        return authentication.getSimpleName().equals(UsernamePasswordAuthenticationToken.class.getSimpleName());
    }
}

