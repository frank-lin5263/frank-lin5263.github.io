package gov.archives.core.domain.vo;

public class SignInMeta {
    private String orgUnitId;
    private String cardNumber;

    public SignInMeta() {
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getCardNumber() {
        return this.cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public static final class Builder {
        private String orgUnitId;
        private String cardNumber;

        private Builder() {
        }

        public static SignInMeta.Builder create() {
            return new SignInMeta.Builder();
        }

        public SignInMeta build() {
            SignInMeta detailBase = new SignInMeta();
            detailBase.setOrgUnitId(this.orgUnitId);
            detailBase.setCardNumber(this.cardNumber);
            return detailBase;
        }

        public SignInMeta.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public SignInMeta.Builder setCardNumber(String cardNumber) {
            this.cardNumber = cardNumber;
            return this;
        }
    }
}

