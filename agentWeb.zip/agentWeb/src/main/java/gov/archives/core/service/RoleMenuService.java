package gov.archives.core.service;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import java.util.List;
import java.util.UUID;

public interface RoleMenuService {
    List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleName(String var1);

    List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleSysId(UUID var1);
}
