package gov.archives.core.domain.entity;

import gov.archives.core.enums.SupportedLanguage;
import java.io.Serializable;
import java.util.Locale;
import java.util.UUID;
import java.util.Locale.Builder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.ibatis.type.Alias;
import org.iii.common.util.StringUtils;

@Alias("UserInfo")
public class UserInfoEntity extends BaseEntity implements Serializable {
    private String account;
    private UUID roleSysId;
    private String orgUnitId;
    private String email;
    private String phoneNumber;
    private String mobileNumber;
    private String orgInfo;
    private Integer activeStatus;
    private String deputyAccount;
    private String certCardNum;
    private String certHash;
    private String phoneAreaCode;
    private String phoneLocalNumber;
    private String phoneExtNumber;
    private String mobileAreaCode;
    private String mobileLocalNumber;
    private SupportedLanguage language;

    public UserInfoEntity() {
    }

    public void composePhoneNumber() {
        this.phoneNumber = this.phoneAreaCode + "-" + this.phoneLocalNumber + (StringUtils.isEmpty(this.phoneExtNumber) ? "" : "#" + this.phoneExtNumber);
    }

    public void composeMobileNumber() {
        this.mobileNumber = (this.mobileAreaCode != null && !this.mobileAreaCode.isEmpty() ? this.mobileAreaCode : "") + (StringUtils.isEmpty(this.mobileLocalNumber) ? "" : "-" + this.mobileLocalNumber);
    }

    public void rebuildPhoneNumbers() {
        this.composePhoneNumber();
        this.composeMobileNumber();
    }

    public void splitPhoneNumber() {
        if (this.phoneNumber.isEmpty()) {
            this.phoneAreaCode = "";
            this.phoneExtNumber = "";
            this.phoneLocalNumber = "";
        }

        String regex = "^(\\d+)-(\\d+)#?(\\d*)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(this.phoneNumber);
        if (matcher.matches()) {
            this.setPhoneAreaCode(matcher.group(1));
            this.setPhoneLocalNumber(matcher.group(2));
            this.setPhoneExtNumber(matcher.group(3));
        }

    }

    public void splitMobileNumber() {
        if (this.mobileNumber.isEmpty()) {
            this.mobileAreaCode = "";
            this.mobileLocalNumber = "";
        }

        String regex = "^(\\d*)-(\\d*)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(this.mobileNumber);
        if (matcher.matches()) {
            this.setMobileAreaCode(matcher.group(1));
            this.setMobileLocalNumber(matcher.group(2));
        }

    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public UUID getRoleSysId() {
        return this.roleSysId;
    }

    public void setRoleSysId(UUID roleSysId) {
        this.roleSysId = roleSysId;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        this.splitPhoneNumber();
    }

    public String getMobileNumber() {
        return this.mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
        this.splitMobileNumber();
    }

    public String getOrgInfo() {
        return this.orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public Integer getActiveStatus() {
        return this.activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getDeputyAccount() {
        return this.deputyAccount;
    }

    public void setDeputyAccount(String deputyAccount) {
        this.deputyAccount = deputyAccount;
    }

    public String getCertCardNum() {
        return this.certCardNum;
    }

    public void setCertCardNum(String certCardNum) {
        this.certCardNum = certCardNum;
    }

    public String getCertHash() {
        return this.certHash;
    }

    public void setCertHash(String certHash) {
        this.certHash = certHash;
    }

    public String getPhoneAreaCode() {
        return this.phoneAreaCode;
    }

    public void setPhoneAreaCode(String phoneAreaCode) {
        this.phoneAreaCode = phoneAreaCode;
    }

    public String getPhoneLocalNumber() {
        return this.phoneLocalNumber;
    }

    public void setPhoneLocalNumber(String phoneLocalNumber) {
        this.phoneLocalNumber = phoneLocalNumber;
    }

    public String getPhoneExtNumber() {
        return this.phoneExtNumber;
    }

    public void setPhoneExtNumber(String phoneExtNumber) {
        this.phoneExtNumber = phoneExtNumber;
    }

    public String getMobileAreaCode() {
        return this.mobileAreaCode;
    }

    public void setMobileAreaCode(String mobileAreaCode) {
        this.mobileAreaCode = mobileAreaCode;
    }

    public String getMobileLocalNumber() {
        return this.mobileLocalNumber;
    }

    public void setMobileLocalNumber(String mobileLocalNumber) {
        this.mobileLocalNumber = mobileLocalNumber;
    }

    public SupportedLanguage getLanguage() {
        return this.language;
    }

    public void setLanguage(SupportedLanguage language) {
        this.language = language;
    }

    public Locale getLocale() {
        return (new Builder()).setLanguage((this.language == null ? SupportedLanguage.TW : this.language).name().toLowerCase()).build();
    }
}

