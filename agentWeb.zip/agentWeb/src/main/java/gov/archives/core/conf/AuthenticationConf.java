package gov.archives.core.conf;

public class AuthenticationConf {
    public static final String LOGIN_PROCESSOR_URL = "/core/login";
    public static final String INDEX_PROCESSOR_URL = "/core/index";
    public static final String NEWLOG_PROCESSOR_URL = "/core/newAccount";
    public static final String FORWARD_TO_LOGIN_URL = "forward:/login";
    public static final String REDIRECT_LOGIN_URL = "redirect:/login?";
    public static final String AUTHENFAIL = "/errors/403";

    public AuthenticationConf() {
    }
}
