package gov.archives.core.conf;

import java.util.UUID;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;

public class CoreConf {
    public static final String DB_TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String QUERY_TX_MANAGER = "g2b2cQueryTxManager";
    public static final String COMMAND_TX_MANAGER = "g2b2cCommandTxManager";
    public static final UUID DEFAULT_ID = UUID.fromString("00000000-0000-0000-0000-000000000000");
    public static final Integer STATUS_DISABLED = 0;
    public static final Integer STATUS_ENABLED = 1;
    public static final Integer STATUS_APPLYING = -1;
    public static final String PATTERN_HEADER_FILE_DOWNLOAD = "attachment; filename=\"%s\"";
    public static final String HEADER_DISPOSITION = "Content-Disposition";
    public static final String DIGIT_EMPTY_PATTERN = "^[\\d]*$";
    public static final String DIGIT_PATTERN = "^[\\d]+$";
    public static final String LOW_CAPITAL_NUMERIC_PATTERN = "^[a-z0-9]+$";
    public static final String CAPITAL_NUMERIC_PATTERN = "^[A-Z0-9]+$";
    public static final String ALPHANUMERIC_PATTERN = "^[A-Za-z0-9]+$";
    public static final String DATE_PATTERN = "^\\d{4}-\\d{2}-\\d{2}$";
    public static final String ALPHANUMERIC_NLS_PATTERN = "^[a-zA-Z0-9\\u0080-\\u9fff ]+$";
    public static final String FILE_HASH_ALGORITHM = "SHA-256";
    public static final String CERT_FORMAT = "X509";
    public static final String SIGN_ALGORITHM = "SHA256withRSA";
    public static final String SUFFIX_CERT = ".cer";
    public static final String SUFFIX_CER = "cer";
    public static final String CERT_FOLDER = "CertFiles";
    public static final String TEMP_FOLDER = "TempFiles";
    public static final String RECEIVE_TEMP = "ReceiveTemp";
    public static final String SEND_LIST = "SendList";
    public static final String CSV_TEMP = "CsvTemp";
    public static final String REST_API_VERSION = "/v1";
    public static final String PROJECT_NAME = "agentWeb";
    public static final String SYSTEM_NAME = "agentWeb";
    public static final String CORE_BASE_URL = "/core";
    public static final String INDEX_URL = "/index";
    public static final String LOGIN_URL = "/login";
    public static final String HOME_URL = "/home/{authPath}";
    public static final String CAPTCHA_URL = "/captcha";
    public static final String UPLOAD_PATH = "/upload";
    public static final String UPLOAD_ZIP = "/zipFile";
    public static final String NEW_USER_APPLY_SUCCESS = "帳號申請成功，新申請資料審查中!!";
    public static final String EVENT_LEVEL_HIGH = "高";
    public static final String EVENT_LEVEL_MEDIUM = "中";
    public static final String EVENT_LEVEL_LOW = "低";
    public static final String LIST_URI = "/list";
    public static final String PREVIEW_URI = "/preview";
    public static final String QUERY_URI = "/query";
    public static final String SYSTEM_TOOL_URL = "/systemTool";
    public static final String DOC_EXCHANGE_URL = "/docExchange";
    public static final String OFFICIAL_FOLDER_URL = "/officialFolder";
    public static final String SEND_QUERY_URL = "/sendQuery";
    public static final String SEND_QUERY_DETAIL_URL = "/sendQueryDetail";
    public static final String RECEIVE_QUERY_URL = "/receivedQuery";
    public static final String MODIFY_PERSON_DATA_URL = "/modifyPersonData";
    public static final String ROLE_MANAGE_URL = "/roleManage";
    public static final String USER_MANAGE_URL = "/userManagement";
    public static final String INIT_EXCHANGE_URL = "/initExchange";
    public static final String SEND_DOCUMENT_URL = "/sendDocument";
    public static final String RECEIVE_DOCUMENT_URL = "/receiveDocument";
    public static final String DOWNLOAD_URL = "/download";
    public static final String FILE_NAME_URL = "/filename";
    public static final String CSV_URL = "/csv";
    public static final String SESSION_URL = "/session";
    public static final String USER_HOME = "user.home";
    public static final String USER_DIR = "user.dir";
    public static final String ERROR_RESOURCE = "/src/main/webapp/resources/error";
    public static final String PROPERTY_DB_URL = "datasource.jdbcUrl";
    public static final String PROPERTY_DB_COMMANDER = "datasource.commander";
    public static final String PROPERTY_DB_COMMANDER_PWD = "datasource.commanderPwd";
    public static final String PROPERTY_DB_QUERIER = "datasource.querier";
    public static final String PROPERTY_DB_QUERIER_PWD = "datasource.querierPwd";
    public static Level ROOT_LOGGER_LEVEL = LogManager.getRootLogger().getLevel();
    public static final String ACTION_ITEM_INNER = "actionItemInner";
    public static final String ACTOR_ACCOUNT_SYSTEM = "archives";

    public CoreConf() {
    }
}

