package gov.archives.core.controller;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.service.PKIIdentityService;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(
        path = {"/v1"}
)
public class SignCertIdentityController {
    private static final String REST_CERT_HASH = "/cert/check";
    @Autowired
    private PKIIdentityService identityService;

    public SignCertIdentityController() {
    }

    @RequestMapping(
            value = {"/cert/check"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<Void> checkSignCertHash(@RequestBody String certB64) {
        try {
            PreconditionUtils.checkArguments(new Object[]{certB64});
            this.identityService.checkDigitalSignatureCert(certB64);
            return new ResponseEntity(HttpStatus.OK);
        } catch (RuntimeException var3) {
            throw ArchivesException.getInstanceByErrorCode("SYS0007", new Object[]{var3});
        }
    }
}
