package gov.archives.core.exception;

import gov.archives.core.message.CoreErrorMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(RestExceptionHandler.class);

    public RestExceptionHandler() {
    }

    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("body: " + body);
        String error = ex.getMessage();
        log.error("getMessage: " + error);
        log.error("HttpStatus: " + status.value());
        return new ResponseEntity(body, headers, status);
    }

    @ExceptionHandler({ArchivesException.class})
    public ResponseEntity<Object> handleArchivesException(ArchivesException ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        Throwable throwable = ex.getCause();
        String message;
        if (throwable != null) {
            message = throwable.getMessage();
        } else {
            message = ex.getMessage();
        }

        return this.handleExceptionInternal(ex, ExceptionMessage.getInstanceByCodeAndMessage(ex.getMessage(), message), headers, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler({IllegalArgumentException.class})
    public ResponseEntity<Object> handleIllegalArgumentException(Exception ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return this.handleExceptionInternal(ex, new ExceptionMessage("", ex.getMessage()), headers, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler({Exception.class})
    public ResponseEntity<Object> handleDefaultException(Exception ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return this.handleExceptionInternal(ex, ExceptionMessage.getInstanceByCodeAndMessage("SYS0000", CoreErrorMessage.findByCode("SYS0000")), headers, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler({CoreException.class})
    public ResponseEntity<Object> handleCoreException(CoreException ex, WebRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return this.handleExceptionInternal(ex, ExceptionMessage.getInstanceByCodeAndMessage("SYS0000", CoreErrorMessage.findByCode("SYS0000")), headers, HttpStatus.BAD_REQUEST, request);
    }
}

