package gov.archives.core.controller;

import com.google.common.collect.ImmutableMap;
import gov.archives.core.domain.vo.RestResponse;
import gov.archives.core.domain.vo.RestResponse.ResponseBuilder;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.RoleMenuMappingFacade;
import gov.archives.core.service.MenuService;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/core"})
public class MenuController extends RestControllerBase {
    public static final String GET_MENUS = "/menu";
    @Autowired
    private RoleMenuMappingFacade roleMenuMappingFacade;
    @Autowired
    private MenuService menuService;

    public MenuController() {
    }

    @RequestMapping(
            value = {"/menu"},
            method = {RequestMethod.GET}
    )
    public ResponseEntity<RestResponse<Map>> getRoleMenu() {
        try {
            String loginAccount = super.getCurrentAccount();
            Map map = this.roleMenuMappingFacade.getRoleMappingMenu(loginAccount);
            RestResponse<Map> restResponse = ResponseBuilder.createResponseByData(map).setResultCode(0).setResultMessage("").build();
            return new ResponseEntity(restResponse, HttpStatus.OK);
        } catch (Exception var4) {
            throw var4 instanceof ArchivesException ? (ArchivesException)var4 : ArchivesException.getInstanceByErrorCode("AP0002", new Object[]{var4});
        }
    }

    @RequestMapping(
            value = {"/menu/all"},
            method = {RequestMethod.GET}
    )
    public Map getAllMenu() {
        try {
            return ImmutableMap.of("menu", this.menuService.getMenuTree());
        } catch (ArchivesException var2) {
            throw ArchivesException.getInstanceByErrorCode("MENU001", new Object[]{var2});
        }
    }

    @RequestMapping(
            value = {"/rest/urlMap"},
            method = {RequestMethod.GET}
    )
    public Map<String, String> getRestUrlMap() {
        return this.menuService.getMenuUrlMap();
    }
}
