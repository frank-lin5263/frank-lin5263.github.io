package gov.archives.core.controller;

import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.ModifyPersonDataVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.UserInfoUtil;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/systemTool/modifyPersonData"})
public class ModifyPersonDataController extends RestControllerBase {
    @Autowired
    private UserInfoService userInfoService;

    public ModifyPersonDataController() {
    }

    @RequestMapping(
            value = {"/getUser"},
            method = {RequestMethod.GET}
    )
    public ModifyPersonDataVO getUser(HttpServletRequest request) {
        try {
            ModifyPersonDataEntity modifyPersonDataEntity = this.userInfoService.getAccountInfo(this.getCurrentAccount());
            if (!modifyPersonDataEntity.getLoginCount().isEmpty() && !modifyPersonDataEntity.getLoginIP().isEmpty() && !modifyPersonDataEntity.getLoginTime().isEmpty()) {
                ModifyPersonDataVO modifyPersonDataVO = this.getModifyPersonDataVo(modifyPersonDataEntity);
                this.insertActionLogAndRsysLog("修改個人資料查詢模組", "低");
                return modifyPersonDataVO;
            } else {
                super.insertActionLog(request, "修改個人資料查詢模組", "SYS0007", "SYS0007", "高");
                throw ArchivesException.getInstanceByErrorCode("SYS0007", new Object[0]);
            }
        } catch (ArchivesException var4) {
            super.insertActionLog(request, "修改個人資料查詢模組", CoreErrorMessage.findByCode("SYS0007"), "SYS0007", "高");
            throw ArchivesException.getInstanceByErrorCode("SYS0007", new Object[]{var4});
        }
    }

    @RequestMapping(
            value = {"/modifyUser"},
            method = {RequestMethod.PUT}
    )
    public Map<String, String> saveUser(@RequestBody ModifyPersonDataEntity user, HttpServletRequest request) {
        try {
            Map<String, String> saveResult = new HashMap();
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST);
            } else {
                String regexResult = this.verifySingleUserInfo(user);
                if (!regexResult.isEmpty()) {
                    saveResult.put("result", regexResult);
                    return saveResult;
                } else {
                    this.userInfoService.update(this.getUserInfo(user));
                    this.insertActionLogAndRsysLog("修改個人資料修改模組", "中");
                    saveResult.put("result", "");
                    return saveResult;
                }
            }
        } catch (ArchivesException var5) {
            super.insertActionLog(request, "修改個人資料修改模組", CoreErrorMessage.findByCode("SYS0008"), "SYS0008", "高");
            throw ArchivesException.getInstanceByErrorCode("SYS0008", new Object[]{var5});
        }
    }

    private String verifySingleUserInfo(ModifyPersonDataEntity user) {
        String email = user.getEmail();
        if (null != email && EmailValidator.getInstance().isValid(email)) {
            if (!this.validateFiled(user.getOrgInfo(), "^[a-zA-Z0-9\\u0080-\\u9fff ]+$")) {
                return CoreErrorMessage.findByCode("ED9001");
            } else if (this.regexValidator(user.getPhoneAreaCode(), "^[\\d]+$")) {
                return CoreErrorMessage.findByCode("ED0002");
            } else if (this.regexValidator(user.getPhoneLocalNumber(), "^[\\d]+$")) {
                return CoreErrorMessage.findByCode("ED0002");
            } else if (this.regexValidator(user.getPhoneExtNumber(), "^[\\d]*$")) {
                return CoreErrorMessage.findByCode("ED0002");
            } else if (this.regexValidator(user.getMobileAreaCode(), "^[\\d]*$")) {
                return CoreErrorMessage.findByCode("ED0002");
            } else {
                return this.regexValidator(user.getMobileLocalNumber(), "^[\\d]*$") ? CoreErrorMessage.findByCode("ED0002") : "";
            }
        } else {
            return CoreErrorMessage.findByCode("ED0003");
        }
    }

    private Boolean regexValidator(String stringValue, String regexPattern) {
        RegexValidator regexValidator = new RegexValidator(regexPattern);
        return null == stringValue || !regexValidator.isValid(stringValue);
    }

    private UserInfoEntity getUserInfo(ModifyPersonDataEntity modifyPersonDataEntity) {
        UserInfoEntity userInfoEntity = this.userInfoService.getByAccount(UserInfoUtil.getCurrentAccount());
        if (null == userInfoEntity) {
            throw new RestApplicationException(HttpStatus.BAD_REQUEST);
        } else {
            userInfoEntity.setPhoneAreaCode(modifyPersonDataEntity.getPhoneAreaCode());
            userInfoEntity.setPhoneExtNumber(modifyPersonDataEntity.getPhoneExtNumber());
            userInfoEntity.setPhoneLocalNumber(modifyPersonDataEntity.getPhoneLocalNumber());
            userInfoEntity.setMobileAreaCode(modifyPersonDataEntity.getMobileAreaCode());
            userInfoEntity.setMobileLocalNumber(modifyPersonDataEntity.getMobileLocalNumber());
            userInfoEntity.setEmail(modifyPersonDataEntity.getEmail());
            userInfoEntity.setOrgInfo(modifyPersonDataEntity.getOrgInfo());
            userInfoEntity.rebuildPhoneNumbers();
            userInfoEntity.initUpdate(UserInfoUtil.getCurrentAccount());
            return userInfoEntity;
        }
    }

    private ModifyPersonDataVO getModifyPersonDataVo(ModifyPersonDataEntity modifyPersonDataEntity) {
        ModifyPersonDataVO modifyPersonDataVO = new ModifyPersonDataVO();
        modifyPersonDataVO.setUserAccount(modifyPersonDataEntity.getAccount());
        modifyPersonDataVO.setOrgUnitId(modifyPersonDataEntity.getOrgUnitId());
        modifyPersonDataVO.setPhoneAreaCode(modifyPersonDataEntity.getPhoneAreaCode());
        modifyPersonDataVO.setPhoneExtNumber(modifyPersonDataEntity.getPhoneExtNumber());
        modifyPersonDataVO.setPhoneLocalNumber(modifyPersonDataEntity.getPhoneLocalNumber());
        modifyPersonDataVO.setMobileAreaCode(modifyPersonDataEntity.getMobileAreaCode());
        modifyPersonDataVO.setMobileLocalNumber(modifyPersonDataEntity.getMobileLocalNumber());
        modifyPersonDataVO.setEmail(modifyPersonDataEntity.getEmail());
        modifyPersonDataVO.setOrgName(modifyPersonDataEntity.getOrgInfo());
        modifyPersonDataVO.setAccountLoginNum(modifyPersonDataEntity.getLoginCount());
        modifyPersonDataVO.setAccountLoginIP(modifyPersonDataEntity.getLoginIP());
        modifyPersonDataVO.setAccountLastTime(modifyPersonDataEntity.getLoginTime());
        return modifyPersonDataVO;
    }
}
