package gov.archives.core.conf;

public class ActionLogConf {
    public static final String SUCCESS_CODE = "0000";
    public static final String SUCCESS_MSG = "成功";
    public static final String FAIL_MSG = "失敗";
    public static final String EVENT_LEVEL_HIGH = "高";
    public static final String EVENT_LEVEL_MEDIUM = "中";
    public static final String EVENT_LEVEL_LOW = "低";
    public static final String IC_AUTH_LOGIN = "自然人憑證簽章驗證登入模組";
    public static final String REGISTER_ACCOUNT = "帳號申請模組";
    public static final String ACCOUNT_LOGIN = "帳號登入模組";
    public static final String ACCOUNT_LOGOUT = "帳號登出模組";
    public static final String ACCOUNT_CERT_CHNAGE = "使用者管理憑證變更作業模組";
    public static final String GENERATE_CAPTCHA = "圖形驗證碼模組";
    public static final String SEARCH_PERSON_DATA = "修改個人資料查詢模組";
    public static final String UPDATE_PERSON_DATA = "修改個人資料修改模組";
    public static final String SEARCH_ACCOUNT_KEYWORD = "使用者管理查詢帳號模組";
    public static final String UPDATE_ACCOUNT_DATA = "使用者管理修改帳號模組";
    public static final String UPDATE_MENU_CONFIG = "權限管理權限類型修改模組";
    public static final String UPDATE_ROLE = "權限管理修改權限模組";
    public static final String ADD_ROLE = "權限管理新增權限模組";
    public static final String SEARCH_ROLE = "權限管理查詢權限模組";
    public static final String READ_CENTRAL_GATEWAY = "中心閘道註冊查詢模組";
    public static final String CREATE_CENTRAL_GATEWAY = "中心閘道註冊新增模組";
    public static final String UPDATE_CENTRAL_GATEWAY = "中心閘道註冊修改模組";
    public static final String READ_SUBROGATION_MANAGEMENT = "代字號管理查詢模組";
    public static final String CREATE_SUBROGATION_MANAGEMENT = "代字號管理新增模組";
    public static final String UPDATE_SUBROGATION_MANAGEMENT = "代字號管理修改模組";
    public static final String DELETE_SUBROGATION_MANAGEMENT = "代字號管理刪除模組";
    public static final String READ_FORM_REGISTER_MANAGEMENT = "表單註冊管理查詢模組";
    public static final String CREATE_FORM_REGISTER_MANAGEMENT = "表單註冊管理新增模組";
    public static final String UPDATE_FORM_REGISTER_MANAGEMENT = "表單註冊管理修改模組";
    public static final String UPLOAD_FORM_REGISTER_MANAGEMENT = "表單註冊管理上傳檔案模組";
    public static final String READ_ADDRESSBOOK_METASTASIS = "地址簿移轉查詢模組";
    public static final String UPDATE_ADDRESSBOOK_METASTASIS = "地址簿移轉修改模組";
    public static final String TRANSFER_BATCH_ADRESS = "地址簿批次移轉模組";
    public static final String READ_ADDRESS_BOOK_MANAGEMENT = "地址簿管理查詢模組";
    public static final String CREATE_ADDRESS_BOOK_MANAGEMENT = "地址簿管理新增模組";
    public static final String UPDATE_ADDRESS_BOOK_MANAGEMENT = "地址簿管理修改模組";
    public static final String READ_ORG_CERT_MANAGEMENT = "憑證管理查詢模組";
    public static final String CREATE_ORG_CERT_MANAGEMENT = "憑證管理新增模組";
    public static final String UPDATE_ORG_CERT_MANAGEMENT = "憑證管理修改模組";
    public static final String DELETE_ORG_CERT_MANAGEMENT = "憑證管理刪除模組";
    public static final String UPLOAD_ORG_CERT_MANAGEMENT = "憑證管理上傳檔案模組";
    public static final String PARSE_ORG_CERT_MANAGEMENT = "憑證管理擷取檔案模組";
    public static final String READ_TIAN_YUAN_MANAGEMENT = "天元模組管理查詢模組";
    public static final String UPLOAD_TIAN_YUAN_MANAGEMENT = "天元模組管理上傳檔案模組";
    public static final String UPLOAD_ADDRESS_BOOK_BATCH_DISABLED = "地址簿批次處理作廢模組";
    public static final String UPLOAD_ADDRESS_BOOK_BATCH_MODIFIED = "地址簿批次處理作廢模組";
    public static final String READ_BLACK_LIST_SEARCH = "黑名單查詢模組";

    public ActionLogConf() {
    }
}

