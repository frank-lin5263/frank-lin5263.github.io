package gov.archives.core.i18n;

import java.util.Locale;
import java.util.Properties;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;

@Component
public class SerializableResourceBundleMessageSource extends ReloadableResourceBundleMessageSource {
    public SerializableResourceBundleMessageSource() {
    }

    public Properties getAllProperties(Locale locale) {
        this.clearCacheIncludingAncestors();
        PropertiesHolder propertiesHolder = this.getMergedProperties(locale);
        Properties properties = propertiesHolder.getProperties();
        return properties;
    }
}
