package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.UserInfoEntity;
import java.util.Map;

public interface UserInfoCommandMapper {
    String KEY_SYS_ID = "sysId";
    String KEY_ROLE_NAME = "roleName";
    String KEY_USER_ACCOUNT = "account";
    String KEY_MODIFIER_ACCOUNT = "modifierAccount";
    String KEY_MODIFIED_TIME = "modifiedTime";

    void save(UserInfoEntity var1);

    void update(UserInfoEntity var1);

    void remove(UserInfoEntity var1);

    void updateUserByAccount(UserInfoEntity var1);

    void updateUserByRoleName(Map<String, Object> var1);

    void updateSingleUserByName(Map<String, Object> var1);
}
