package gov.archives.core.facade;

import gov.archives.core.domain.vo.AccountForm;

public interface DocumentExchangeServiceFacade {
    void checkAccountExist(AccountForm var1);

    void saveNewAccount(AccountForm var1, Long var2);
}
