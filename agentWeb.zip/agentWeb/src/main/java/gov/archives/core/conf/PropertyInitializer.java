package gov.archives.core.conf;

import gov.archives.core.util.EncryptUtils;
import java.io.File;
import java.util.Properties;

public class PropertyInitializer extends CommonInitializer implements BaseInitializer {
    public PropertyInitializer() {
    }

    public void init() {
        Properties propInit = loadPropertiesFromFile(initPropertiesFile);
        Properties propDs = loadPropertiesFromFile(dsConfigFile);

        try {
            if (!checkStringsIsEmpty(new String[]{INIT_URL, INIT_COMMANDER, INIT_COMMANDER_PWD, INIT_QUERIER, INIT_QUERIER_PWD})) {
                this.dsPropertiesFileEncrypt(dsConfigFile, propDs);
                this.clearPropertiesFile(initPropertiesFile, propInit);
            }
        } finally {
            this.closeProperties(propInit, propDs);
        }

    }

    private void dsPropertiesFileEncrypt(File dsPropertiesFile, Properties properties) {
        properties.setProperty("datasource.jdbcUrl", EncryptUtils.encrypt(INIT_URL));
        properties.setProperty("datasource.commander", EncryptUtils.encrypt(INIT_COMMANDER));
        properties.setProperty("datasource.commanderPwd", EncryptUtils.encrypt(INIT_COMMANDER_PWD));
        properties.setProperty("datasource.querier", EncryptUtils.encrypt(INIT_QUERIER));
        properties.setProperty("datasource.querierPwd", EncryptUtils.encrypt(INIT_QUERIER_PWD));
        storePropertiesFile(dsPropertiesFile, properties);
    }

    private void closeProperties(Properties... properties) {
        Properties[] var2 = properties;
        int var3 = properties.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Properties property = var2[var4];
            if (property != null) {
                property.clear();
            }
        }

    }
}

