package gov.archives.core.controller;

import gov.archives.core.service.HomeService;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {
    private static final String REDIRECT_ACTION = "redirect:";
    private static final String VIEW_TEXT = "viewText";
    private static final String ERROR_MESSAGE = "ErrorMessage";
    private static final String PARAM_ERROR = "error";
    private static final String SPRING_SECURITY_LAST_EXCEPTION = "SPRING_SECURITY_LAST_EXCEPTION";
    @Autowired
    private HomeService homeService;

    public HomeController() {
    }

    @RequestMapping(
            value = {"/"},
            method = {RequestMethod.GET}
    )
    public String getHome() {
        return "redirect:/index";
    }

    @RequestMapping(
            path = {"/index"}
    )
    public String getIndex(Map<String, Object> model, HttpServletRequest request) {
        String error = request.getParameter("error");
        model.put("ErrorMessage", "");
        if (error != null) {
            System.out.println("error: " + error);
            if (error.length() > 0) {
                model.put("ErrorMessage", error);
            } else {
                Exception e = (Exception)request.getSession().getAttribute("SPRING_SECURITY_LAST_EXCEPTION");
                if (e != null) {
                    Throwable t = e.getCause();
                    String detailMsg = "";
                    if (t != null) {
                        detailMsg = t.getMessage();
                    }

                    model.put("ErrorMessage", e.getMessage() + ": " + detailMsg);
                }
            }
        }

        return "/core/index";
    }

    @RequestMapping(
            path = {"/v1/home/{authPath}"},
            method = {RequestMethod.GET}
    )
    @ResponseBody
    public Map<String, String> initHomeAction(@PathVariable String authPath) {
        Map<String, String> map = new HashMap();
        map.put("viewText", this.homeService.readHomePageTextASString(authPath));
        return map;
    }
}
