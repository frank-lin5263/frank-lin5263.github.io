package gov.archives.core.service.impl;

import gov.archives.agent.domain.vo.SystemCommand;
import gov.archives.agent.domain.vo.SystemCommand.Builder;
import gov.archives.agent.messaging.MessageReceiver;
import gov.archives.agent.messaging.MessageSender;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.service.SessionManageService;
import gov.archives.jagent.domain.parameter.SystemLogoutParameter;
import gov.archives.jagent.domain.result.CommandResult;
import gov.archives.jagent.domain.result.SystemLogoutResult;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListMap;
import org.apache.activemq.command.ActiveMQQueue;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Service;

@Service("sessionManageService")
public class SessionManageServiceImpl implements SessionManageService {
    private ConcurrentSkipListMap<String, AccountDetail> skipListMap = new ConcurrentSkipListMap();
    @Autowired
    private MessageSender messageSender;
    @Autowired
    private MessageReceiver messageReceiver;
    @Autowired
    private ActiveMQQueue commandDestination;
    @Autowired
    private ActiveMQQueue resultDestination;

    public SessionManageServiceImpl() {
    }

    public synchronized void setAccountDetail(AccountDetail detail) {
        if (null != detail) {
            String account = detail.getAccount();
            if (null != account) {
                this.skipListMap.put(detail.getAccount(), detail);
            }
        }

    }

    public synchronized AccountDetail getAccountDetail() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            String account = auth.getName();
            return (AccountDetail)this.skipListMap.get(account);
        } else {
            return null;
        }
    }

    public Boolean checkAccountSessionId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return this.checkSessionId(auth.getName(), (WebAuthenticationDetails)auth.getDetails());
    }

    public int removeAccountDetail(String account) {
        PreconditionUtils.checkArguments(new Object[]{account});
        this.skipListMap.remove(account);
        return this.skipListMap.size();
    }

    public String executeSystemLogout(String sessionId, String signedToken) {
        PreconditionUtils.checkArguments(new Object[]{sessionId, signedToken});
        this.messageSender.sendMessage(this.commandDestination, this.buildLogoutCommand(sessionId, signedToken));
        CommandResult<SystemLogoutResult> logoutResult = (CommandResult)this.messageReceiver.receiveMessage(this.resultDestination);
        SystemLogoutResult result = (SystemLogoutResult)logoutResult.getResult();
        return result.getLogoutResult();
    }

    private SystemCommand buildLogoutCommand(String sessionId, String tokenSig) {
        SystemCommand command = Builder.createParameter(new SystemLogoutParameter()).setName("System#Logout").setId(UUID.randomUUID()).setSessionId(sessionId).setTokenSig(tokenSig).build();
        return command;
    }

    private synchronized Boolean checkSessionId(String account, WebAuthenticationDetails authDetails) {
        PreconditionUtils.checkArguments(new Object[]{account});
        AccountDetail details = this.skipListMap.get(account);
        return details != null ? details.getSessionId().equals(authDetails.getSessionId()) : true;
    }
}
