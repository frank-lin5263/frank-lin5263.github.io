package gov.archives.core.accessor;

import gov.archives.core.conf.AgentConf;
import gov.archives.core.exception.ArchivesException;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.iii.common.util.IOUtils;
import org.springframework.stereotype.Service;

@Service
public class ClientLogAccessor {
    private static Properties prop;

    public ClientLogAccessor() {
    }

    public List<String> getLocationAllFile(String orgId, String certHash) throws IOException {
        String path = AgentConf.getClientLogLocation() + orgId + "/" + certHash + "/";
        if (!IOUtils.isFolderExist(path)) {
            (new File(path)).mkdirs();
        }

        List<String> prepareLocationFileNames = new ArrayList();
        Files.walk(Paths.get(path)).forEach((currentFile) -> {
            if (Files.isRegularFile(currentFile, new LinkOption[0])) {
                prepareLocationFileNames.add(currentFile.getFileName().toString());
            }

        });
        return prepareLocationFileNames;
    }

    public InputStream getLocationFile(String orgId, String certHash, String fileName) {
        String filePath = AgentConf.getClientLogLocation() + orgId + "/" + certHash + "/" + fileName;
        File download = new File(filePath);
        BufferedInputStream inputStream = null;

        BufferedInputStream var7;
        try {
            inputStream = new BufferedInputStream(new FileInputStream(download));
            var7 = inputStream;
        } catch (FileNotFoundException var11) {
            throw ArchivesException.getInstanceByErrorCode("CEX0003", new Object[0]);
        } finally {
            this.safeCloseInputStream(inputStream);
        }

        return var7;
    }

    public InputStream getProjectLocalFile(String filePath, String fileName, String fileType) {
        String realPath = filePath + fileName + fileType;
        File download = new File(realPath);
        BufferedInputStream inputStream = null;

        BufferedInputStream var7;
        try {
            if (!download.exists()) {
                throw ArchivesException.getInstanceByErrorCode("CEX0004", new Object[0]);
            }

            inputStream = new BufferedInputStream(new FileInputStream(download));
            var7 = inputStream;
        } catch (FileNotFoundException var11) {
            throw ArchivesException.getInstanceByErrorCode("CEX0003", new Object[0]);
        } finally {
            this.safeCloseInputStream(inputStream);
        }

        return var7;
    }

    private void safeCloseInputStream(InputStream is) {
        if (null != is) {
            try {
                is.close();
            } catch (IOException var3) {
                throw ArchivesException.getInstanceByErrorCode("CEX0004", new Object[0]);
            }
        }

    }
}
