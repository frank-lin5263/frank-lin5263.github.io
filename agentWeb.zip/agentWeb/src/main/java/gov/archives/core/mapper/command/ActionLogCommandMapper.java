package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.ActionLogEntity;

public interface ActionLogCommandMapper {
    void save(ActionLogEntity var1);

    void remove(ActionLogEntity var1);
}
