package gov.archives.core.typehandlers;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

@MappedJdbcTypes({JdbcType.OTHER})
@MappedTypes({String.class})
public class TextArrayTypeHandler extends BaseTypeHandler<String[]> {
    private static final String ARRAY_TYPE_NAME = "text";

    public TextArrayTypeHandler() {
    }

    public void setNonNullParameter(PreparedStatement ps, int i, String[] parameter, JdbcType jdbcType) throws SQLException {
        ps.setArray(i, ps.getConnection().createArrayOf("text", parameter));
    }

    public String[] getNullableResult(ResultSet rs, String columnName) throws SQLException {
        Array outputArray = rs.getArray(columnName);
        return outputArray == null ? null : (String[])((String[])outputArray.getArray());
    }

    public String[] getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        Array outputArray = rs.getArray(columnIndex);
        return outputArray == null ? null : (String[])((String[])outputArray.getArray());
    }

    public String[] getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        Array outputArray = cs.getArray(columnIndex);
        return outputArray == null ? null : (String[])((String[])outputArray.getArray());
    }
}

