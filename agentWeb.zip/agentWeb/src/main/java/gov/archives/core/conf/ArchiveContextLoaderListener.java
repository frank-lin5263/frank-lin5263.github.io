package gov.archives.core.conf;

import javax.servlet.ServletContext;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

public class ArchiveContextLoaderListener extends ContextLoaderListener {
    public ArchiveContextLoaderListener() {
    }

    public WebApplicationContext initWebApplicationContext(ServletContext servletContext) {
        ArchivesInitializers.getSecKeyInitializer().init();
        ArchivesInitializers.getPropertyInitializer().init();
        return super.initWebApplicationContext(servletContext);
    }
}
