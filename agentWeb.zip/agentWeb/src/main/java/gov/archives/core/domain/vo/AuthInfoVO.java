package gov.archives.core.domain.vo;

import java.sql.Timestamp;

public class AuthInfoVO {
    public static final String PARAM_ACCOUNT = "account";
    public static final String PARAM_CARD_NUM = "cardNo";
    private String account;
    private String cardNum;
    private String sessionId;
    private String ipAddress;
    private String orgUnitId;
    private Timestamp lastAccessedTime;

    public AuthInfoVO() {
    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getCardNum() {
        return this.cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public Timestamp getLastAccessedTime() {
        return this.lastAccessedTime;
    }

    public void setLastAccessedTime(Timestamp lastAccessedTime) {
        this.lastAccessedTime = lastAccessedTime;
    }

    public static final class Builder {
        private String account;
        private String sessionId;
        private String ipAddress;
        private String cardNum;
        private Timestamp lastAccessedTime;

        private Builder() {
        }

        public static AuthInfoVO.Builder create() {
            return new AuthInfoVO.Builder();
        }

        public AuthInfoVO build() {
            AuthInfoVO authInfoVO = new AuthInfoVO();
            authInfoVO.setAccount(this.account);
            authInfoVO.setSessionId(this.sessionId);
            authInfoVO.setIpAddress(this.ipAddress);
            authInfoVO.setCardNum(this.cardNum);
            authInfoVO.setLastAccessedTime(this.lastAccessedTime);
            return authInfoVO;
        }

        public AuthInfoVO.Builder setAccount(String account) {
            this.account = account;
            return this;
        }

        public AuthInfoVO.Builder setSessionId(String sessionId) {
            this.sessionId = sessionId;
            return this;
        }

        public AuthInfoVO.Builder setIpAddress(String ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }

        public AuthInfoVO.Builder setCardNum(String cardNum) {
            this.cardNum = cardNum;
            return this;
        }

        public AuthInfoVO.Builder setLastAccessedTime(Timestamp lastAccessedTime) {
            this.lastAccessedTime = lastAccessedTime;
            return this;
        }
    }

}
