package gov.archives.core.validators;

import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.util.ValidatorUtil;
import java.util.Map;
import javax.validation.groups.Default;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class AccountValidator implements Validator {
    public AccountValidator() {
    }

    public boolean supports(Class<?> clazz) {
        return AccountForm.class.isAssignableFrom(clazz);
    }

    public void validate(Object target, Errors err) {
        AccountForm form = (AccountForm)target;
        Map<String, String> fieldValidation = ValidatorUtil.validate(form, new Class[]{Default.class});
        fieldValidation.forEach((k, v) -> {
            err.rejectValue(k, v);
        });
    }
}
