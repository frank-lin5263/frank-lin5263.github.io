package gov.archives.core.security;

import gov.archives.core.domain.entity.UserInfoEntity;
import java.util.Collection;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public final class CaptchaPKIAuthenticationToken extends UsernamePasswordAuthenticationToken {
    private static final long serialVersionUID = 6064887005191943988L;
    private final UserInfoEntity user;
    private String password;

    public CaptchaPKIAuthenticationToken(String principal, String credentials, UserInfoEntity user) {
        super(principal, credentials);
        this.user = user;
        this.password = credentials;
    }

    public CaptchaPKIAuthenticationToken(UserInfoEntity principal, String credentials, Collection<? extends GrantedAuthority> authorities) {
        super(principal, credentials, authorities);
        this.user = principal;
    }

    public UserInfoEntity getUser() {
        return this.user;
    }

    public String getPassword() {
        return this.password;
    }
}

