package gov.archives.core.controller;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.security.access.intercept.FilterInvocationServiceSecurityMetadataSource;
import gov.archives.core.service.RoleService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.UserInfoUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/systemTool/roleManage"})
public class RoleController extends RestControllerBase {
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserInfoService userService;
    @Autowired
    FilterInvocationServiceSecurityMetadataSource filterInvocationService;

    public RoleController() {
    }

    @RequestMapping(
            value = {"/listRoleName"},
            method = {RequestMethod.GET}
    )
    public Collection<RoleName> listRoleName(HttpServletRequest request) {
        try {
            Collection<RoleName> roleNameCollection = this.roleService.listRoleName();
            this.insertActionLogAndRsysLog("權限管理查詢權限模組", "低");
            return roleNameCollection;
        } catch (ArchivesException var3) {
            super.insertActionLog(request, "權限管理查詢權限模組", CoreErrorMessage.findByCode("RO0003"), "RO0003", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0003", new Object[]{var3});
        }
    }

    @RequestMapping(
            value = {"/roleList"},
            method = {RequestMethod.GET}
    )
    public List<RoleEntity> roleList(HttpServletRequest request) {
        try {
            List<RoleEntity> roleNameList = this.roleService.getRoleList();
            this.insertActionLogAndRsysLog("權限管理查詢權限模組", "低");
            return roleNameList;
        } catch (ArchivesException var3) {
            super.insertActionLog(request, "權限管理查詢權限模組", CoreErrorMessage.findByCode("失敗"), "RO0003", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0003", new Object[]{var3});
        }
    }

    @RequestMapping(
            value = {"/newRoleType"},
            method = {RequestMethod.POST}
    )
    public void addRole(@RequestParam("status") Boolean status, @RequestParam("roleName") String roleName, HttpServletRequest request) {
        try {
            if (null == this.roleService.getByRoleName(roleName)) {
                RoleEntity roleEntity = new RoleEntity();
                roleEntity.setSysId(UUID.randomUUID());
                roleEntity.setActiveStatus(status ? 1 : 0);
                roleEntity.setRoleName(roleName);
                roleEntity.initSave(super.getCurrentAccount());
                this.roleService.insert(roleEntity);
                this.insertActionLogAndRsysLog("權限管理新增權限模組", "中");
            }

        } catch (ArchivesException var5) {
            super.insertActionLog(request, "權限管理新增權限模組", CoreErrorMessage.findByCode("RO0003"), "RO0003", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0003", new Object[]{var5});
        }
    }

    @RequestMapping(
            value = {"/fixRoleType"},
            method = {RequestMethod.PUT}
    )
    public void fixRole(@RequestParam("oldRoleName") String oldRoleName, @RequestParam("fixStatus") int fixStatus, @RequestParam("fixRoleName") String fixRoleName, HttpServletRequest request) {
        try {
            RoleEntity roleList = this.roleService.getByRoleName(oldRoleName);
            RoleEntity roleEntity = this.buildRoleByRoleList(roleList, oldRoleName, fixStatus, fixRoleName);
            this.updateRoleEntity(roleEntity);
            this.insertActionLogAndRsysLog("權限管理修改權限模組", "中");
        } catch (ArchivesException var7) {
            super.insertActionLog(request, "權限管理修改權限模組", CoreErrorMessage.findByCode("RO0003"), "RO0003", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0003", new Object[]{var7});
        }
    }

    private RoleEntity buildRoleByRoleList(RoleEntity roleList, String oldRoleName, int fixStatus, String fixRoleName) {
        PreconditionUtils.checkArguments(new Object[]{roleList});
        RoleEntity roleEntity = new RoleEntity();
        roleEntity.setRoleName(fixRoleName);
        roleEntity.setSysId(roleList.getSysId());
        roleEntity.setActiveStatus(fixStatus);
        roleEntity.initUpdate(oldRoleName);
        return roleEntity;
    }

    private void updateRoleEntity(RoleEntity roleEntity) {
        if (this.roleService.getOtherList(roleEntity).isEmpty()) {
            this.roleService.update(roleEntity);
            this.filterInvocationService.createSecurityMetadataSource();
        }

    }

    @RequestMapping(
            value = {"/choiceRole"},
            method = {RequestMethod.GET}
    )
    public List<RoleMenuMapping> choiceRole(@RequestParam("SysId") UUID roleSysId, HttpServletRequest request) {
        try {
            PreconditionUtils.checkArguments(new Object[]{roleSysId});
            List<RoleMenuMapping> roleMenuList = new ArrayList();
            roleMenuList.add(this.roleService.getMenuMappingByRoleSysId(roleSysId));
            this.insertActionLogAndRsysLog("權限管理查詢權限模組", "低");
            return roleMenuList;
        } catch (ArchivesException var4) {
            super.insertActionLog(request, "權限管理查詢權限模組", CoreErrorMessage.findByCode("RO0001"), "RO0001", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0001", new Object[]{var4});
        }
    }

    @RequestMapping(
            value = {"/menuConfig"},
            method = {RequestMethod.PUT}
    )
    public void menuConfig(@RequestParam("roleSysId") UUID roleSysId, @RequestParam("menu") List<UUID> menu, HttpServletRequest request) {
        try {
            RoleMenuMapping roleMenuMapping = this.getRoleMenuMapping(roleSysId, menu);
            this.roleService.updateRoleMenuMapping(roleMenuMapping);
            this.filterInvocationService.createSecurityMetadataSource();
            this.insertActionLogAndRsysLog("權限管理權限類型修改模組", "中");
        } catch (ArchivesException var5) {
            super.insertActionLog(request, "權限管理權限類型修改模組", CoreErrorMessage.findByCode("RO0004"), "RO0004", "高");
            throw ArchivesException.getInstanceByErrorCode("RO0004", new Object[]{var5});
        }
    }

    private RoleMenuMapping getRoleMenuMapping(UUID roleSysId, List<UUID> menu) {
        RoleMenuMapping roleMenu = new RoleMenuMapping();
        List<MenuEntity> menuList = new ArrayList();
        RoleEntity role = new RoleEntity();
        role.setSysId(roleSysId);
        menu.stream().forEach((sysId) -> {
            MenuEntity menuEntity = new MenuEntity();
            menuEntity.setSysId(sysId);
            menuList.add(menuEntity);
        });
        roleMenu.setRole(role);
        roleMenu.setMenus(menuList);
        roleMenu.setCreatorAccount(UserInfoUtil.getCurrentAccount());
        return roleMenu;
    }
}
