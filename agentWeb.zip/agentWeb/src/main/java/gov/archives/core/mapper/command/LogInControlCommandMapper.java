package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.LogInControlEntity;

public interface LogInControlCommandMapper {
    void save(LogInControlEntity var1);

    void update(LogInControlEntity var1);

    void remove(LogInControlEntity var1);
}
