package gov.archives.core.service;

import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import java.util.List;
import java.util.UUID;

public interface RoleService {
    RoleEntity getBySysId(UUID var1);

    RoleEntity getByRoleName(String var1);

    List<RoleEntity> getOtherList(RoleEntity var1);

    List<RoleEntity> getRoleList();

    List<RoleEntity> getRoleListByStatus(int var1);

    void insert(RoleEntity var1);

    void update(RoleEntity var1);

    void delete(RoleEntity var1);

    RoleMenuMapping getMenuMappingByRoleName(String var1);

    RoleMenuMapping getMenuMappingByRoleSysId(UUID var1);

    void updateRoleMenuMapping(RoleMenuMapping var1);

    void deleteMenuMapping(RoleEntity var1);

    List<RoleName> listRoleName();
}

