package gov.archives.core.facade.impl;

import com.google.common.collect.ImmutableMap;
import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.TopMenuVo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.RoleMenuMappingFacade;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleMenuService;
import gov.archives.core.service.UserInfoService;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleMenuMappingFacadeImpl implements RoleMenuMappingFacade {
    @Autowired
    private MenuService menuService;
    @Autowired
    private RoleMenuService roleMenuService;
    @Autowired
    private UserInfoService userInfoService;

    public RoleMenuMappingFacadeImpl() {
    }

    public List<MenuEntity> getRoleMenuFacade(String account) {
        List<MenuEntity> subRoleMenu = new ArrayList();
        UserInfoEntity userInfoEntity = this.userInfoService.getByAccount(account);
        if (null != userInfoEntity) {
            UUID roleId = userInfoEntity.getRoleSysId();
            if (roleId != null && !roleId.equals(CoreConf.DEFAULT_ID)) {
                List<RoleMenuMappingEntity> subMenuSysid = this.roleMenuService.getRoleMenuMappingListByRoleSysId(userInfoEntity.getRoleSysId());
                subRoleMenu = (List)this.menuService.getAllMenu().stream().filter((menuEntity) -> {
                    return subMenuSysid.stream().anyMatch((roleMenuMappingEntity) -> {
                        return menuEntity.getSysId().equals(roleMenuMappingEntity.getMenuSysId());
                    });
                }).collect(Collectors.toList());
            }
        }

        return (List)subRoleMenu;
    }

    public Map getRoleMappingMenu(String account) {
        Map<Integer, TopMenuVo> resultMenu = this.menuService.getMenuTree(this.getRoleMenuFacade(account));
        if (MapUtils.isEmpty(resultMenu)) {
            throw ArchivesException.getInstanceByErrorCode("AP0000", new Object[0]);
        } else {
            return ImmutableMap.of("menu", resultMenu);
        }
    }
}
