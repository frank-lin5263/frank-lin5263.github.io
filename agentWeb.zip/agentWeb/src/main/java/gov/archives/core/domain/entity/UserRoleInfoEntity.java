package gov.archives.core.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("UserRoleInfo")
public class UserRoleInfoEntity extends UserInfoEntity {
    private String roleName;

    public UserRoleInfoEntity() {
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
