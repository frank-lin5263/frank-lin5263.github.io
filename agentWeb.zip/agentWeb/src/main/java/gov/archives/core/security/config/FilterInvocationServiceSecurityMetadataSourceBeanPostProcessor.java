package gov.archives.core.security.config;

import gov.archives.core.security.access.intercept.FilterInvocationServiceSecurityMetadataSource;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.stereotype.Component;

@Component
public class FilterInvocationServiceSecurityMetadataSourceBeanPostProcessor implements BeanPostProcessor {
    @Autowired
    private FilterInvocationServiceSecurityMetadataSource metadataSource;

    public FilterInvocationServiceSecurityMetadataSourceBeanPostProcessor() {
    }

    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean instanceof FilterInvocationSecurityMetadataSource ? this.metadataSource : bean;
    }

    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        return bean instanceof FilterInvocationSecurityMetadataSource ? this.metadataSource : bean;
    }
}

