package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import java.util.UUID;

public interface RoleMenuMappingCommandMapper {
    void save(RoleMenuMappingEntity var1);

    void removeByRoleSysId(UUID var1);
}
