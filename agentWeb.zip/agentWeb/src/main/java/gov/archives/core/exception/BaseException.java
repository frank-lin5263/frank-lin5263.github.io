package gov.archives.core.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseException extends Exception {
    private static final Logger log = LoggerFactory.getLogger(BaseException.class);

    private BaseException() {
    }

    public BaseException(String errorCodeOrMessage) {
        super(errorCodeOrMessage);
    }

    public BaseException(Throwable cause, String errorCodeOrMessage) {
        super(errorCodeOrMessage, cause);
    }

    public BaseException(Throwable cause) {
        super(cause);
    }

    protected BaseException(String errorCodeOrMessage, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(errorCodeOrMessage, cause, enableSuppression, writableStackTrace);
    }
}

