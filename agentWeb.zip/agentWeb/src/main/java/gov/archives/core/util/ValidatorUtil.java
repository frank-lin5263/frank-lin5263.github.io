package gov.archives.core.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

public class ValidatorUtil {
    private static Validator validator;

    public ValidatorUtil() {
    }

    public static <T> Map<String, String> validate(T object, Class... groups) {
        Class<?>[] args = (Class[])Arrays.copyOf(groups, groups.length + 1);
        args[groups.length] = Default.class;
        return extractViolations(validator.validate(object, args));
    }

    private static <T> Map<String, String> extractViolations(Set<ConstraintViolation<T>> violations) {
        Map<String, String> errors = new HashMap();
        Iterator var2 = violations.iterator();

        while(var2.hasNext()) {
            ConstraintViolation<T> v = (ConstraintViolation)var2.next();
            errors.put(v.getPropertyPath().toString(), "[" + v.getPropertyPath().toString() + "] " + StringUtils.capitalize(v.getMessage()));
        }

        return errors;
    }

    public static void raiseFirstError(BindingResult result) {
        if (result.hasErrors()) {
            throw new IllegalArgumentException(((ObjectError)result.getAllErrors().get(0)).getCode());
        } else if (result.hasGlobalErrors()) {
            throw new IllegalArgumentException(result.getGlobalError().getDefaultMessage());
        }
    }

    static {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }
}
