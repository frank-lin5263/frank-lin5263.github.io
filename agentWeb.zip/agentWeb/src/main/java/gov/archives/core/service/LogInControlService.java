package gov.archives.core.service;

import gov.archives.core.domain.entity.LogInControlEntity;

public interface LogInControlService {
    void insert(LogInControlEntity var1);

    void update(LogInControlEntity var1);

    void delete(LogInControlEntity var1);

    LogInControlEntity getBySessionIdAndAccount(String var1, String var2);

    LogInControlEntity getBySessionIdAndAccountMaxlimitTime(String var1, String var2);

    LogInControlEntity getByAccountMaxlimitTime(String var1);
}
