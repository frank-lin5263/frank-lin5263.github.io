package gov.archives.core.controller;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.RestApplicationException;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.UserInfoService;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.validator.routines.RegexValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/systemTool/userManagement"})
public class UserInfoController extends RestControllerBase {
    @Autowired
    private UserInfoService userInfoService;

    public UserInfoController() {
    }

    @RequestMapping(
            value = {"/list"},
            method = {RequestMethod.GET}
    )
    public Collection<UserInfo> getFilterAccount(@RequestParam Map<String, Object> requestMap, HttpServletRequest request) {
        try {
            Map<String, Object> nameSearchMap = new HashMap();
            nameSearchMap.put("keyWord", MapUtils.getObject(requestMap, "keyWord"));
            nameSearchMap.put("verification", Boolean.parseBoolean(MapUtils.getString(requestMap, "verification")));
            nameSearchMap.put("active", Boolean.parseBoolean(MapUtils.getString(requestMap, "active")));
            nameSearchMap.put("inactive", Boolean.parseBoolean(MapUtils.getString(requestMap, "inactive")));
            List<UserInfo> userInfoList = this.userInfoService.listByKeyWord(nameSearchMap);
            this.insertActionLogAndRsysLog("使用者管理查詢帳號模組", "低");
            return userInfoList;
        } catch (ArchivesException var5) {
            this.insertActionLog(request, "使用者管理查詢帳號模組", CoreErrorMessage.findByCode("SYS0007"), "SYS0007", "高");
            throw ArchivesException.getInstanceByErrorCode("SYS0007", new Object[]{var5});
        }
    }

    @RequestMapping(
            value = {"/saveUser"},
            method = {RequestMethod.PUT}
    )
    @ResponseStatus(HttpStatus.OK)
    public void saveUser(@RequestBody UserInfo user, HttpServletRequest request) {
        try {
            if (null == user) {
                throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
            } else {
                if (user.getOrgInfo() == null) {
                    user.setOrgInfo("");
                }

                this.verifyUserInfo(user);
                this.userInfoService.updateUserByAccount(user);
                this.insertActionLogAndRsysLog(request, "使用者管理修改帳號模組", "成功", "0000", "中");
            }
        } catch (ArchivesException var4) {
            this.insertActionLog(request, "修改個人資料修改模組", CoreErrorMessage.findByCode("SYS0007"), "SYS0007", "高");
            throw ArchivesException.getInstanceByErrorCode(var4.getMessage(), new Object[0]);
        }
    }

    private void verifyUserInfo(UserInfo user) {
        RegexValidator alphaNumericValidator = new RegexValidator("^[A-Za-z0-9]+$");
        RegexValidator alphaNumericNlsValidator = new RegexValidator("^[a-zA-Z0-9\\u0080-\\u9fff ]+$");
        String account = user.getAccount();
        if (null != account && alphaNumericValidator.isValid(account)) {
            String roleName = user.getRoleName();
            if (roleName != null && (roleName.isEmpty() || alphaNumericNlsValidator.isValid(roleName))) {
                String orgUnitId = user.getOrgUnitId();
                if (null != orgUnitId && alphaNumericNlsValidator.isValid(orgUnitId)) {
                    String email = user.getEmail();
                    if (null != email && EmailValidator.getInstance().isValid(email)) {
                        int activeStatus = user.getActiveStatus();
                        if (activeStatus != CoreConf.STATUS_APPLYING && activeStatus != CoreConf.STATUS_DISABLED && activeStatus != CoreConf.STATUS_ENABLED) {
                            throw new RestApplicationException("Invalid ActiveStatus");
                        } else {
                            String deputyAccount = user.getDeputyAccount();
                            if (null == deputyAccount || !deputyAccount.isEmpty() && !alphaNumericValidator.isValid(deputyAccount)) {
                                throw new RestApplicationException(HttpStatus.BAD_REQUEST.toString());
                            }
                        }
                    } else {
                        throw ArchivesException.getInstanceByErrorCode("ED0003", new Object[0]);
                    }
                } else {
                    throw ArchivesException.getInstanceByErrorCode("ED0018", new Object[0]);
                }
            } else {
                throw ArchivesException.getInstanceByErrorCode("ED9000", new Object[0]);
            }
        } else {
            throw ArchivesException.getInstanceByErrorCode("ED0017", new Object[0]);
        }
    }
}
