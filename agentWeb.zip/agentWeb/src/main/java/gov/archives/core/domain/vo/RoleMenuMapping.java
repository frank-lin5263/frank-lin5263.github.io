package gov.archives.core.domain.vo;

import gov.archives.core.domain.entity.MenuEntity;
import gov.archives.core.domain.entity.RoleEntity;
import java.util.ArrayList;
import java.util.List;

public class RoleMenuMapping {
    private RoleEntity role;
    private List<MenuEntity> menus = new ArrayList();
    private String creatorAccount;

    public RoleMenuMapping() {
    }

    public RoleEntity getRole() {
        return this.role;
    }

    public void setRole(RoleEntity role) {
        this.role = role;
    }

    public List<MenuEntity> getMenus() {
        return this.menus;
    }

    public void setMenus(List<MenuEntity> menus) {
        this.menus = menus;
    }

    public void addMenu(MenuEntity menu) {
        this.menus.add(menu);
    }

    public String getCreatorAccount() {
        return this.creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }
}

