package gov.archives.core.servlet;

import gov.archives.agent.conf.AgentApiConf;
import gov.archives.core.conf.CommonInitializer;
import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class AgentApiLoadListener implements ServletContextListener {
    public AgentApiLoadListener() {
    }

    public void contextInitialized(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        AgentApiConf.setGCAProperties(this.getMainProperties(context));
    }

    private Properties getMainProperties(ServletContext context) {
        InputStream is = null;

        Properties var4;
        try {
            Properties prop = new Properties();
            is = this.getMainPropertiesFile(context);
            prop.load(is);
            var4 = prop;
        } catch (IOException var8) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var8});
        } finally {
            this.safeCloseInputStream(is);
        }

        return var4;
    }

    private InputStream getMainPropertiesFile(ServletContext context) throws FileNotFoundException {
        String defaultLocation = "WEB-INF/gca.properties";
        File customized = CommonInitializer.getFileFromConfiguredFolderOrClasspath("gca.properties");
        return (InputStream)(null != customized && customized.exists() ? new FileInputStream(customized) : context.getResourceAsStream(defaultLocation));
    }

    private void safeCloseInputStream(InputStream is) {
        if (null != is) {
            try {
                is.close();
            } catch (IOException var3) {
                throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var3});
            }
        }

    }

    public void contextDestroyed(ServletContextEvent sce) {
    }
}
