package gov.archives.core.util;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CertificateVerifier {
    public CertificateVerifier() {
    }

    public static boolean isSelfSigned(X509Certificate cert) {
        try {
            PublicKey key = cert.getPublicKey();
            cert.verify(key);
            return true;
        } catch (NoSuchAlgorithmException | NoSuchProviderException | SignatureException | CertificateException var2) {
            return false;
        } catch (InvalidKeyException var3) {
            return false;
        }
    }
}

