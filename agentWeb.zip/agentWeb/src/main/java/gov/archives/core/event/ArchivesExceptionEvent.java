package gov.archives.core.event;

import gov.archives.core.exception.ExceptionMessage;
import gov.archives.core.util.LogUtils;
import java.sql.Timestamp;
import javax.servlet.http.HttpServletRequest;
import org.iii.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ArchivesExceptionEvent extends BaseEvent {
    private static final Logger log = LoggerFactory.getLogger(ArchivesExceptionEvent.class);
    private static final String EVENT_NAME = "ArchivesExceptionEvent";
    private ExceptionMessage exceptionMessage;
    private Throwable cause;
    private HttpServletRequest httpServletRequest;

    public ArchivesExceptionEvent(Object source) {
        super(source);
    }

    public ArchivesExceptionEvent(Object source, String errorMessage, String errorCode, Object... objects) {
        super(source);
        this.exceptionMessage = this.initExceptionMessage(errorMessage, errorCode);
        this.cause = this.initThrowable(objects);
        this.httpServletRequest = this.initHttpServletRequest(objects);
    }

    public ArchivesExceptionEvent(Object source, String errorCodeOrMessage, Object... objects) {
        super(source);
        this.exceptionMessage = this.initExceptionMessage(errorCodeOrMessage);
        this.cause = this.initThrowable(objects);
        this.httpServletRequest = this.initHttpServletRequest(objects);
    }

    public String toString() {
        return "ArchivesExceptionEvent";
    }

    public void logEvent() {
        Timestamp actionTime = new Timestamp(System.currentTimeMillis());
        String remoteIp = this.getIp();
        String actionItem = null != this.source ? this.source.getClass().getName() : "actionItemInner";
        String actorAccount = null != this.httpServletRequest ? (StringUtils.isEmpty(this.httpServletRequest.getRemoteUser()) ? "archives" : this.httpServletRequest.getRemoteUser()) : "archives";
        String actionResult = StringUtils.isEmpty(this.exceptionMessage.getErrorMessage()) ? LogUtils.getErrorMessage("SYS0000") : this.exceptionMessage.getErrorMessage();
        String errorCode = StringUtils.isEmpty(this.exceptionMessage.getErrorCode()) ? "SYS0000" : this.exceptionMessage.getErrorCode();
        String eventLevel = "SYS0000".equals(LogUtils.getErrorCodeIfExist(this.exceptionMessage.getErrorCode())) ? "高" : "中";
        String logMessage = actionTime + "," + remoteIp + "," + actionItem + "," + actorAccount + "," + actionResult + "," + errorCode + "," + eventLevel;
        if (null == this.cause) {
            LogUtils.logException(logMessage);
        } else {
            LogUtils.logException(logMessage, this.cause);
        }

    }

    private ExceptionMessage initExceptionMessage(String errorCodeOrMessage) {
        return ExceptionMessage.getInstanceByCodeAndMessage(LogUtils.getErrorCodeIfExist(errorCodeOrMessage), LogUtils.getErrorMessage(errorCodeOrMessage));
    }

    private ExceptionMessage initExceptionMessage(String errorMessage, String errorCode) {
        return ExceptionMessage.getInstanceByCodeAndMessage(errorCode, errorMessage);
    }

    private HttpServletRequest initHttpServletRequest(Object[] objects) {
        Object[] var2 = objects;
        int var3 = objects.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Object obj = var2[var4];
            if (obj instanceof HttpServletRequest) {
                return (HttpServletRequest)obj;
            }
        }

        return null;
    }

    private Throwable initThrowable(Object[] objects) {
        Object[] var2 = objects;
        int var3 = objects.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Object obj = var2[var4];
            if (obj instanceof Throwable) {
                return (Throwable)obj;
            }
        }

        return null;
    }

    private String getIp() {
        String ip = "";
        if (null != this.httpServletRequest) {
            ip = this.httpServletRequest.getRemoteAddr();
        }

        return StringUtils.isEmpty(ip) ? "archives" : ip;
    }
}

