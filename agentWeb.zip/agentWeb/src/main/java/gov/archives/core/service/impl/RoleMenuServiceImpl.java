package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.mapper.query.RoleMenuMappingQueryMapper;
import gov.archives.core.service.RoleMenuService;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleMenuServiceImpl implements RoleMenuService {
    @Autowired
    private RoleMenuMappingQueryMapper roleMenuMappingQueryMapper;

    public RoleMenuServiceImpl() {
    }

    public List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleName(String roleName) {
        return this.roleMenuMappingQueryMapper.findByRoleName(roleName);
    }

    public List<RoleMenuMappingEntity> getRoleMenuMappingListByRoleSysId(UUID roleSysId) {
        return this.roleMenuMappingQueryMapper.findByRoleSysId(roleSysId);
    }
}
