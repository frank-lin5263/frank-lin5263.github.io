package gov.archives.core.service;

import gov.archives.core.domain.entity.ActionLogEntity;
import java.sql.Timestamp;

public interface ActionLogService {
    void insertsAndRsysLog(ActionLogEntity var1);

    void insert(ActionLogEntity var1);

    void delete(ActionLogEntity var1);

    void logEvent(ActionLogEntity var1);

    void setSuccessActionLog(String var1, String var2);

    void saveSuccessActionAndRsysLog(String var1, String var2, Timestamp var3);
}
