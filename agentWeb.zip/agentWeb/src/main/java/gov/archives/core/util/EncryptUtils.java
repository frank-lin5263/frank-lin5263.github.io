package gov.archives.core.util;

import gov.archives.core.conf.SecKeyInitializer;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.CoreException;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.security.Security;
import java.util.Properties;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.iii.security.cipher.Decryptor;
import org.iii.security.cipher.Decryptors;
import org.iii.security.cipher.Encryptor;
import org.iii.security.cipher.Encryptors;
import org.iii.security.exception.SecurityException;
import org.iii.security.hash.HashGenerator;
import org.iii.security.hash.HashGenerators;
import org.iii.security.util.SecretKeyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class EncryptUtils {
    private static final Logger log = LoggerFactory.getLogger(EncryptUtils.class);
    private static final String ENCRYPT_CONFIG_FILE_NAME = "encryptWeb.properties";
    private static File encryptConfigFile;
    private static final String ENCODING;
    private static final String PROPERTY_DEFAULT_ENCODING = "encoding";
    private static final String DEFAULT_ENCODING = "UTF-8";

    public EncryptUtils() {
    }

    public static String encrypt(String painText) {
        PreconditionUtils.checkArguments(new Object[]{painText});

        try {
            Encryptor encryptor = Encryptors.getAESEncryptorByKey(getSecretKey());
            byte[] cipher = encryptor.encrypt(painText.getBytes(ENCODING));
            return Hex.encodeHexString(cipher);
        } catch (UnsupportedEncodingException | SecurityException var4) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var4});
        }
    }

    public static String decrypt(String encryptText) {
        PreconditionUtils.checkArguments(new Object[]{encryptText});

        try {
            Decryptor decryptor = Decryptors.getAESDecryptorByKey(getSecretKey());
            byte[] plain = decryptor.decrypt(Hex.decodeHex(encryptText.toCharArray()));
            return new String(plain, ENCODING);
        } catch (UnsupportedEncodingException | DecoderException | SecurityException var4) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var4});
        }
    }

    private static SecretKey getSecretKey() {
        try {
            return SecretKeyUtils.getAESKeyFromCustData(SecKeyInitializer.getRandomSecKey().getBytes());
        } catch (SecurityException var1) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var1});
        }
    }

    public static String txtToBase64(String plainText) {
        PreconditionUtils.checkArguments(new Object[]{plainText});

        try {
            byte[] outputBytes = plainText.getBytes("UTF-8");
            String rtnStr = DatatypeConverter.printBase64Binary(outputBytes);
            return rtnStr;
        } catch (UnsupportedEncodingException var4) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var4});
        }
    }

    public static String base64ToText(String plainText) {
        PreconditionUtils.checkArguments(new Object[]{plainText});

        try {
            byte[] outputBytes = DatatypeConverter.parseBase64Binary(plainText);
            String rtnStr = null != outputBytes ? new String(outputBytes, ENCODING) : "";
            return rtnStr;
        } catch (UnsupportedEncodingException var4) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var4});
        }
    }

    public static String txtToHash(String plainText) throws CoreException {
        PreconditionUtils.checkArguments(new Object[]{plainText});
        HashGenerator hashGenerator = HashGenerators.getInstanceByAlgorithm("SHA-1");
        return hashGenerator.getHashByString(plainText);
    }

    static {
        Security.addProvider(new BouncyCastleProvider());
        Properties propEn = new Properties();

        try {
            encryptConfigFile = Paths.get(IOUtils.loadResourceURLInClasspath("encryptWeb.properties").toURI()).toFile();
            propEn.load(IOUtils.loadResourceInClasspath("encryptWeb.properties"));
        } catch (URISyntaxException | IOException var5) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[]{var5});
        } finally {
            ENCODING = propEn.getProperty("encoding", "UTF-8");
        }

    }
}
