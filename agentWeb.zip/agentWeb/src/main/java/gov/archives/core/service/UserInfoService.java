package gov.archives.core.service;

import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.UserInfo;
import java.util.List;
import java.util.Map;

public interface UserInfoService {
    UserInfoEntity getByAccount(String var1);

    List<UserInfoEntity> getByCertHash(String var1);

    void insert(UserInfoEntity var1);

    void update(UserInfoEntity var1);

    void delete(UserInfoEntity var1);

    void updateUserByAccount(UserInfo var1);

    void updateUserByRoleName(UserInfoEntity var1, String var2);

    List<UserInfo> list();

    List<UserInfo> listByKeyWord(Map<String, Object> var1);

    ModifyPersonDataEntity getAccountInfo(String var1);
}

