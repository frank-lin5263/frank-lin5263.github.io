package gov.archives.core.controller;

import gov.archives.core.domain.vo.SignPackageData;
import gov.archives.core.domain.vo.SignPackageData.Builder;
import gov.archives.core.util.EncryptUtils;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/auth"})
public class AuthTokenController extends RestControllerBase {
    public AuthTokenController() {
    }

    @RequestMapping(
            value = {"signToken"},
            method = {RequestMethod.GET}
    )
    public ResponseEntity<SignPackageData> getSignPackageData(HttpServletRequest request) {
        String token = UUID.randomUUID().toString();
        request.getSession().setAttribute("login_uuid", token);
        SignPackageData data = Builder.create().setContent(EncryptUtils.encrypt(token)).build();
        return new ResponseEntity(data, HttpStatus.OK);
    }
}
