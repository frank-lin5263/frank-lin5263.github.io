package gov.archives.core.conf;

import gov.archives.core.util.EncryptUtils;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.util.ObjectUtils;

public class ArchivesPropertyConfigurer extends PropertyPlaceholderConfigurer {
    private static final List<String> DECRYPT_ITEM = new ArrayList();

    public ArchivesPropertyConfigurer() {
    }

    protected void convertProperties(Properties props) {
        super.convertProperties(props);
        Enumeration propertyNames = props.propertyNames();

        while(propertyNames.hasMoreElements()) {
            String propertyName = (String)propertyNames.nextElement();
            String propertyValue = props.getProperty(propertyName);
            if (DECRYPT_ITEM.contains(propertyName)) {
                String convertedValue;
                if (SecKeyInitializer.isEncrypt()) {
                    convertedValue = EncryptUtils.decrypt(propertyValue);
                } else {
                    convertedValue = propertyValue;
                }

                if (!ObjectUtils.nullSafeEquals(propertyValue, convertedValue)) {
                    props.setProperty(propertyName, convertedValue);
                }
            }
        }

    }

    static {
        DECRYPT_ITEM.add("datasource.jdbcUrl");
        DECRYPT_ITEM.add("datasource.commander");
        DECRYPT_ITEM.add("datasource.commanderPwd");
        DECRYPT_ITEM.add("datasource.querier");
        DECRYPT_ITEM.add("datasource.querierPwd");
    }
}

