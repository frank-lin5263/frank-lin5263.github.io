package gov.archives.core.exception;

public class ExceptionMessage {
    private String errorCode;
    private String errorMessage;

    public ExceptionMessage(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public static ExceptionMessage getInstanceByCodeAndMessage(String errorCode, String message) {
        return new ExceptionMessage(errorCode, message);
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
