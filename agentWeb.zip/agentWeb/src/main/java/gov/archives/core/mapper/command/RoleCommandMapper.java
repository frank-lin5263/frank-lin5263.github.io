package gov.archives.core.mapper.command;

import gov.archives.core.domain.entity.RoleEntity;

public interface RoleCommandMapper {
    void save(RoleEntity var1);

    void update(RoleEntity var1);

    void remove(RoleEntity var1);
}
