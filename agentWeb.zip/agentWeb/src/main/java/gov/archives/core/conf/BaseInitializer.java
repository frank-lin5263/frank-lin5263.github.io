package gov.archives.core.conf;

public interface BaseInitializer {
    void init();
}
