package gov.archives.core.domain.vo;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;

public class AccountForm implements Serializable {
    private static final long serialVersionUID = -2859976001619288699L;
    @NotNull(
            message = "帳號必填欄位，請確認!!"
    )
    @Pattern(
            regexp = "^[a-zA-Z0-9\\u0080-\\u9fff ]+$",
            message = "帳號必需為一般文數字"
    )
    @Size(
            max = 100,
            message = "帳號最大長度100字元"
    )
    private String account;
    @NotNull(
            message = "機關單位代碼必填欄位，請確認!!"
    )
    @Pattern(
            regexp = "^[A-Za-z0-9]+$",
            message = "機關單位代碼必需為一般文數字"
    )
    @Size(
            min = 10,
            max = 17,
            message = "機關單位代碼最大長度10~17字元"
    )
    private String orgUnitId;
    @NotNull(
            message = "電話區碼不能空白，請確認!!"
    )
    @Pattern(
            regexp = "^[\\d]+$",
            message = "電話區碼必需數字"
    )
    @Size(
            min = 2,
            max = 4,
            message = "電話區碼長度在2~4字元"
    )
    private String phoneLocal;
    @NotNull(
            message = "電話號碼必填欄位，請確認!!"
    )
    @Pattern(
            regexp = "^[\\d]+$",
            message = "電話號碼必需數字"
    )
    @Size(
            max = 10,
            message = "電話號碼最大長度 10字元"
    )
    private String phoneNum;
    @NotNull(
            message = "電話分機必需數字，請確認!!"
    )
    @Pattern(
            regexp = "^[\\d]+$",
            message = "電話分機必需數字"
    )
    @Size(
            max = 6,
            message = "電話分機最大長度 6字元"
    )
    private String phoneExt;
    private String mobileLocal;
    private String mobileNum;
    @NotNull(
            message = "電子郵件是必填欄位，請確認!!"
    )
    @Email(
            message = "電子郵件格式錯誤，請確認!!"
    )
    private String email;
    private String cardNo;
    private String b64Cert;
    @NotNull(
            message = "圖形驗證碼是必填欄位，請確認!!"
    )
    @Pattern(
            regexp = "^[a-z0-9]+$",
            message = "圖形驗證碼必需為一般文數字"
    )
    @Size(
            min = 4,
            max = 6,
            message = "圖形驗證碼長度在4~6字元"
    )
    private String captcha;
    private String loginCount;
    private String loginIp;
    private Timestamp LogDateTime;

    public AccountForm() {
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public String getPhoneNum() {
        return this.phoneNum;
    }

    public String getPhoneExt() {
        return this.phoneExt;
    }

    public String getCardNo() {
        return this.cardNo;
    }

    public String getB64Cert() {
        return this.b64Cert;
    }

    public String getCaptcha() {
        return this.captcha;
    }

    public String getLoginCount() {
        return this.loginCount;
    }

    public String getLoginIp() {
        return this.loginIp;
    }

    public Timestamp getLogDateTime() {
        return this.LogDateTime;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getMobileLocal() {
        return this.mobileLocal;
    }

    public String getMobileNum() {
        return this.mobileNum;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPhoneLocal() {
        return this.phoneLocal;
    }

    public String getAccount() {
        return this.account;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setPhoneExt(String phoneExt) {
        this.phoneExt = phoneExt;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public void setB64Cert(String b64Cert) {
        this.b64Cert = b64Cert;
    }

    public void setLoginCount(String loginCount) {
        this.loginCount = loginCount;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp;
    }

    public void setLogDateTime(Timestamp logDateTime) {
        this.LogDateTime = logDateTime;
    }

    public void setMobileLocal(String mobileLocal) {
        this.mobileLocal = mobileLocal;
    }

    public void setMobileNum(String mobileNum) {
        this.mobileNum = mobileNum;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneLocal(String phoneLocal) {
        this.phoneLocal = phoneLocal;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }
}

