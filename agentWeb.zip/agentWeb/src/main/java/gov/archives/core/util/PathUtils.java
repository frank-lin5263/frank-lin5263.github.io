package gov.archives.core.util;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathUtils {
    public PathUtils() {
    }

    public static Path getProjectHomeFolder() {
        return Paths.get(System.getProperty("user.home"), "agentWeb");
    }

    public static Path getCertFolderPath() {
        return Paths.get(System.getProperty("user.home"), "agentWeb", "CertFiles");
    }

    public static Path getTempFolderPath() {
        return Paths.get(System.getProperty("user.home"), "agentWeb", "TempFiles");
    }

    public static String getErrorResourceFolder() {
        return Paths.get(System.getProperty("user.dir"), "/src/main/webapp/resources/error").toString();
    }

    public static Path buildTempFileUrlByPaths(String... paths) {
        Path rootPath = getProjectHomeFolder();
        String[] var2 = paths;
        int var3 = paths.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            String path = var2[var4];
            rootPath = rootPath.resolve(path);
        }

        return rootPath;
    }
}
