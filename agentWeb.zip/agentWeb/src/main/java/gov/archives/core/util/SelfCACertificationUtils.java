package gov.archives.core.util;

import gov.archives.core.security.pki.JPKISelfCASecurityUtils;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import org.bouncycastle.util.encoders.Hex;
import org.iii.common.conf.CommonConfig;
import org.iii.common.util.IOUtils;
import org.iii.security.domain.KeyStorePackage;
import org.iii.security.domain.SignPackage;
import org.iii.security.exception.SecurityException;

public class SelfCACertificationUtils {
    private static final String TEST_RESOURCES_FOLDER = "test-resources";
    private static final String TEST_CA_FOLDER = "SelfCACertification";
    private static final String TEST_ORG_ID = "SSCA000001";
    private static final String KEYSTORE_PASSWORD = "!QAZ2wsx";
    private static final String FILE_SIGNATURE_KEYSTORE = "cert1.p12";
    private static final String FILE_SIGNATURE_CERT_FILE = "cert1.cer";
    private static final String KEYSTORE_FOR_SIG_CERT_ALIAS = "cert1";
    private static final String FILE_ENCRYPTION_KEYSTORE = "cert2.p12";
    private static final String FILE_ENCRYPTION_CERT_FILE = "cert2.cer";
    private static final String KEYSTORE_FOR_ENC_CERT_ALIAS = "cert2";
    public static JPKISelfCASecurityUtils selfCASecurityUtils = JPKISelfCASecurityUtils.getInstance();

    public SelfCACertificationUtils() {
    }

    public static SignPackage signHashByKeyStore(String hash) throws SecurityException {
        return selfCASecurityUtils.signHashedByKeyStore("SHA-256", Hex.decode(hash), prepareKeyStorePackForSignature());
    }

    private static KeyStorePackage prepareKeyStorePackForSignature() {
        return KeyStorePackage.getInstanceByField(getKeyStoreForSign(), "!QAZ2wsx", "cert1");
    }

    private static File getKeyStoreForSign() {
        Path testFolder = getRuntimeTestResourceFolder().resolve("SelfCACertification").resolve("SSCA000001");
        return testFolder.resolve("cert1.p12").toFile();
    }

    public static byte[] getSigCert() throws IOException {
        Path testFolder = getRuntimeTestResourceFolder().resolve("SelfCACertification").resolve("SSCA000001");
        return IOUtils.readBytesFromFile(testFolder.resolve("cert1.cer").toFile());
    }

    public static byte[] getEncCert() throws IOException {
        Path testFolder = getRuntimeTestResourceFolder().resolve("SelfCACertification").resolve("SSCA000001");
        return IOUtils.readBytesFromFile(testFolder.resolve("cert2.cer").toFile());
    }

    private static Path getRuntimeTestResourceFolder() {
        return CommonConfig.getRuntimeRoot(SelfCACertificationUtils.class).resolve("test-resources");
    }

    public static byte[] decByKeyStore(byte[] cipher) throws SecurityException {
        return selfCASecurityUtils.decryptByKeyStore(cipher, prepareKeyStorePackForEncryption());
    }

    private static KeyStorePackage prepareKeyStorePackForEncryption() {
        return KeyStorePackage.getInstanceByField(getKeyStoreForEnc(), "!QAZ2wsx", "cert2");
    }

    private static File getKeyStoreForEnc() {
        Path testFolder = getRuntimeTestResourceFolder().resolve("SelfCACertification").resolve("SSCA000001");
        return testFolder.resolve("cert2.p12").toFile();
    }
}

