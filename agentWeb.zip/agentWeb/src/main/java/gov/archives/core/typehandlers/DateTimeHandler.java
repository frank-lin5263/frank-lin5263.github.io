package gov.archives.core.typehandlers;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;
import org.iii.common.util.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

public class DateTimeHandler implements TypeHandler<DateTime> {
    public DateTimeHandler() {
    }

    public void setParameter(PreparedStatement preparedStatement, int i, DateTime dateTime, JdbcType jdbcType) throws SQLException {
        preparedStatement.setObject(i, new Timestamp(dateTime.getMillis()), 93);
    }

    public DateTime getResult(ResultSet resultSet, String s) throws SQLException {
        Object timestamp = resultSet.getObject(s);
        return timestamp instanceof Timestamp ? new DateTime(((Timestamp)timestamp).getTime()) : DateTime.parse(StringUtils.trimFromUnknown(timestamp), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }

    public DateTime getResult(ResultSet resultSet, int i) throws SQLException {
        Object timestamp = resultSet.getObject(i);
        return timestamp instanceof Timestamp ? new DateTime(((Timestamp)timestamp).getTime()) : DateTime.parse(StringUtils.trimFromUnknown(timestamp), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }

    public DateTime getResult(CallableStatement callableStatement, int i) throws SQLException {
        Object timestamp = callableStatement.getObject(i);
        return timestamp instanceof Timestamp ? new DateTime(((Timestamp)timestamp).getTime()) : DateTime.parse(StringUtils.trimFromUnknown(timestamp), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS"));
    }
}

