package gov.archives.core.domain.entity;

import gov.archives.core.conf.CoreConf;
import java.util.UUID;
import org.apache.ibatis.type.Alias;

@Alias("Menu")
public class MenuEntity extends BaseEntity {
    private String menuCode;
    private String menuName;
    private Integer menuSeq;
    private UUID topMenuId;
    private Integer activeStatus;
    private String modifiedMemo;

    public MenuEntity() {
        this.topMenuId = CoreConf.DEFAULT_ID;
    }

    public String getMenuCode() {
        return this.menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public String getMenuName() {
        return this.menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public Integer getMenuSeq() {
        return this.menuSeq;
    }

    public void setMenuSeq(Integer menuSeq) {
        this.menuSeq = menuSeq;
    }

    public UUID getTopMenuId() {
        return this.topMenuId;
    }

    public void setTopMenuId(UUID topMenuId) {
        this.topMenuId = topMenuId;
    }

    public Integer getActiveStatus() {
        return this.activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getModifiedMemo() {
        return this.modifiedMemo;
    }

    public void setModifiedMemo(String modifiedMemo) {
        this.modifiedMemo = modifiedMemo;
    }
}

