package gov.archives.core.domain.vo;

import java.io.Serializable;

public class RestResponse<D> implements Serializable {
    public static final String KEY_RESULT_CODE = "resultCode";
    public static final String KEY_RESULT_MESSAGE = "resultMessage";
    public static final String KEY_RESULT_DATA = "resultData";
    private Integer resultCode;
    private String resultMessage;
    private D resultData;

    public RestResponse() {
    }

    public Integer getResultCode() {
        return this.resultCode;
    }

    public String getResultMessage() {
        return this.resultMessage;
    }

    public D getResultData() {
        return this.resultData;
    }

    public void setResultCode(Integer resultCode) {
        this.resultCode = resultCode;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public void setResultData(D resultData) {
        this.resultData = resultData;
    }

    public static class ResponseBuilder<D> {
        private Integer resultCode;
        private String resultMessage;
        private D data;

        public static <T> RestResponse.ResponseBuilder<T> createResponseByData(T data) {
            return new RestResponse.ResponseBuilder(data);
        }

        private ResponseBuilder(D data) {
            this.data = data;
        }

        public RestResponse.ResponseBuilder<D> setResultCode(Integer resultCode) {
            this.resultCode = resultCode;
            return this;
        }

        public RestResponse.ResponseBuilder<D> setResultMessage(String resultMessage) {
            this.resultMessage = resultMessage;
            return this;
        }

        public RestResponse<D> build() {
            RestResponse<D> response = new RestResponse();
            response.setResultCode(this.resultCode);
            response.setResultMessage(this.resultMessage);
            response.setResultData(this.data);
            return response;
        }
    }
}
