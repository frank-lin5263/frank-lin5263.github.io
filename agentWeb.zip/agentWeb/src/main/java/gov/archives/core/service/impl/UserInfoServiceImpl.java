package gov.archives.core.service.impl;

import gov.archives.core.conf.CoreConf;
import gov.archives.core.domain.entity.ModifyPersonDataEntity;
import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.entity.UserRoleInfoEntity;
import gov.archives.core.domain.vo.UserInfo;
import gov.archives.core.mapper.command.UserInfoCommandMapper;
import gov.archives.core.mapper.query.RoleQueryMapper;
import gov.archives.core.mapper.query.UserInfoQueryMapper;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.BeanUtils;
import gov.archives.core.util.UserInfoUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserInfoServiceImpl implements UserInfoService {
    @Autowired
    private UserInfoCommandMapper commandMapper;
    @Autowired
    private UserInfoQueryMapper queryMapper;
    @Autowired
    private RoleQueryMapper roleQueryMapper;

    public UserInfoServiceImpl() {
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public UserInfoEntity getByAccount(String account) {
        PreconditionUtils.checkArguments(new Object[]{account});
        return this.queryMapper.findByAccount(account);
    }

    public List<UserInfoEntity> getByCertHash(String certHash) {
        PreconditionUtils.checkArguments(new Object[]{certHash});
        return this.queryMapper.findByCertHash(certHash);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insert(UserInfoEntity user) {
        PreconditionUtils.checkArguments(new Object[]{user});
        this.commandMapper.save(user);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void update(UserInfoEntity user) {
        PreconditionUtils.checkArguments(new Object[]{user});
        this.commandMapper.update(user);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void delete(UserInfoEntity user) {
        PreconditionUtils.checkArguments(new Object[]{user});
        this.commandMapper.remove(user);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void updateUserByRoleName(UserInfoEntity user, String roleName) {
        PreconditionUtils.checkArguments(new Object[]{user, roleName});
        Map<String, Object> params = new HashMap();
        params.put("account", user.getAccount());
        params.put("sysId", user.getSysId());
        params.put("roleName", roleName);
        params.put("modifierAccount", user.getModifierAccount());
        params.put("modifiedTime", user.getModifiedTime());
        this.commandMapper.updateUserByRoleName(params);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public List<UserInfo> list() throws ApplicationException {
        return this.compositionAccountList(this.queryMapper.list());
    }

    public List<UserInfo> listByKeyWord(Map<String, Object> nameSearchMap) {
        return this.compositionAccountList(this.queryMapper.listByKeyWord(nameSearchMap));
    }

    public ModifyPersonDataEntity getAccountInfo(String personAccount) {
        PreconditionUtils.checkArguments(new Object[]{personAccount});
        return this.queryMapper.personDataByAccount(personAccount);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void updateUserByAccount(UserInfo userInfo) throws ApplicationException {
        UserInfoEntity userInfoEntity = new UserInfoEntity();
        userInfo.rebuildPhoneNumbers();
        BeanUtils.copyProperties(userInfoEntity, userInfo);
        String roleName = userInfo.getRoleName();
        if (StringUtils.isEmpty(roleName)) {
            userInfoEntity.setRoleSysId(CoreConf.DEFAULT_ID);
        } else {
            RoleEntity roleEntity = this.roleQueryMapper.findByRoleName(userInfo.getRoleName());
            userInfoEntity.setRoleSysId(roleEntity.getSysId());
        }

        userInfoEntity.initUpdate(UserInfoUtil.getCurrentAccount());
        this.commandMapper.updateUserByAccount(userInfoEntity);
    }

    private List<UserInfo> compositionAccountList(List<UserRoleInfoEntity> userRoleInfoEntitiesList) {
        if (null != userRoleInfoEntitiesList && !userRoleInfoEntitiesList.isEmpty()) {
            List<UserInfo> userInfoList = new ArrayList();
            Iterator var3 = userRoleInfoEntitiesList.iterator();

            while(var3.hasNext()) {
                UserInfoEntity userInfoEntity = (UserInfoEntity)var3.next();
                UserInfo userInfo = new UserInfo();
                BeanUtils.copyProperties(userInfo, userInfoEntity);
                userInfoList.add(userInfo);
            }

            return userInfoList;
        } else {
            return new ArrayList();
        }
    }
}
