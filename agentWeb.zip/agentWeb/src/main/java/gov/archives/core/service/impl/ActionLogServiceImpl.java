package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.ActionLogEntity;
import gov.archives.core.domain.entity.ActionLogEntity.Builder;
import gov.archives.core.mapper.command.ActionLogCommandMapper;
import gov.archives.core.service.ActionLogService;
import gov.archives.core.util.LogUtils;
import java.sql.Timestamp;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ActionLogServiceImpl implements ActionLogService {
    private static final Logger log = LoggerFactory.getLogger(ActionLogServiceImpl.class);
    @Autowired
    private ActionLogCommandMapper commandMapper;
    private ActionLogEntity succussActionLog;

    public ActionLogServiceImpl() {
        this.initSuccessActionLog();
    }

    public void initSuccessActionLog() {
        this.succussActionLog = Builder.create().setActionItem("成功").setActionResult(LogUtils.getErrorMessage("成功")).setErrorCode("0000").setEventLevel("中").setActorAccount("").setRemoteIp("").setActionTime(new Timestamp(System.currentTimeMillis())).build();
    }

    public synchronized void setSuccessActionLog(String account, String remoteIp) {
        PreconditionUtils.checkArguments(new Object[]{account, remoteIp});
        this.succussActionLog.setActorAccount(account);
        this.succussActionLog.setRemoteIp(remoteIp);
    }

    public synchronized void saveSuccessActionAndRsysLog(String actionItem, String eventLevel, Timestamp actionTime) {
        PreconditionUtils.checkArguments(new Object[]{actionItem, eventLevel, actionTime});
        this.succussActionLog.setActionItem(actionItem);
        this.succussActionLog.setEventLevel(eventLevel);
        this.succussActionLog.setActionTime(actionTime);
        this.succussActionLog.initSave(this.succussActionLog.getActorAccount());
        this.actionSQLInsert(this.succussActionLog);
        this.logEvent(this.succussActionLog);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insertsAndRsysLog(ActionLogEntity actionLog) {
        this.actionSQLInsert(actionLog);
        this.logEvent(actionLog);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insert(ActionLogEntity actionLog) {
        this.actionSQLInsert(actionLog);
    }

    private void actionSQLInsert(ActionLogEntity actionLogEntity) {
        PreconditionUtils.checkArguments(new Object[]{actionLogEntity});
        this.commandMapper.save(actionLogEntity);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void delete(ActionLogEntity actionLog) {
        PreconditionUtils.checkArguments(new Object[]{actionLog});
        this.commandMapper.remove(actionLog);
    }

    public void logEvent(ActionLogEntity actionLog) {
        String errorCode = actionLog.getErrorCode();
        if (!HttpStatus.OK.getReasonPhrase().equals(errorCode) && !errorCode.equals("0000")) {
            this.insertErrorActionLog(actionLog);
        } else {
            this.insertInfoActionLog(actionLog);
        }

    }

    private void insertInfoActionLog(ActionLogEntity actionLog) {
        log.info(this.prepareLogMessage(actionLog));
    }

    private void insertErrorActionLog(ActionLogEntity actionLog) {
        log.error(this.prepareLogMessage(actionLog));
    }

    private String prepareLogMessage(ActionLogEntity actionLog) {
        Timestamp actionTime = actionLog.getActionTime();
        String remoteIp = actionLog.getRemoteIp();
        String actionItem = actionLog.getActionItem();
        String actorAccount = actionLog.getActorAccount();
        String actionResult = actionLog.getActionResult();
        String errorCode = actionLog.getErrorCode();
        String eventLevel = actionLog.getEventLevel();
        return actionTime + "," + remoteIp + "," + actionItem + "," + actorAccount + "," + actionResult + "," + errorCode + "," + eventLevel;
    }
}
