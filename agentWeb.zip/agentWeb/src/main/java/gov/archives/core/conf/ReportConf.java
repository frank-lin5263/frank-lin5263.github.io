package gov.archives.core.conf;

public class ReportConf {
    public static final String EVENT_SUCCESS = "success";
    public static final String EVENT_FAIL = "fail";
    public static final String PDF = "PDF";
    public static final String ODS = "ODS";
    public static final String CONTENT_TYPE = "application/";

    public ReportConf() {
    }
}
