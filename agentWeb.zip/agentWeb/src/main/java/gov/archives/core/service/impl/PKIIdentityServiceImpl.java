package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.security.DigitalSignHandle;
import gov.archives.core.service.PKIIdentityService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.UserInfoUtil;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.iii.common.util.PreconditionUtils;
import org.iii.security.hash.HashGenerators;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Service;

@Service
public class PKIIdentityServiceImpl implements PKIIdentityService {
    private static final Logger log = LoggerFactory.getLogger(PKIIdentityServiceImpl.class);
    @Autowired
    private DigitalSignHandle signHandle;
    @Autowired
    private UserInfoService userInfoService;

    public PKIIdentityServiceImpl() {
    }

    public String getSHA256CertHash(String b64Cert) {
        PreconditionUtils.checkArguments(new Object[]{b64Cert});

        try {
            X509Certificate x509 = this.signHandle.transBase64CertIntoX509(b64Cert);
            return HashGenerators.getInstanceByAlgorithm("SHA-256").getHashByString(new String(x509.getEncoded(), StandardCharsets.UTF_8));
        } catch (CertificateException var3) {
            throw new AuthenticationServiceException("SYS0000");
        }
    }

    public String getSHA256CertHash(X509Certificate x509) {
        PreconditionUtils.checkArguments(new Object[]{x509});

        try {
            return HashGenerators.getInstanceByAlgorithm("SHA-256").getHashByString(new String(x509.getEncoded(), StandardCharsets.UTF_8));
        } catch (CertificateException var3) {
            throw new AuthenticationServiceException("SYS0000");
        }
    }

    public void checkDigitalSignatureCert(String certB64) {
        UserInfoEntity entity = this.userInfoService.getByAccount(UserInfoUtil.getCurrentAccount());
        String certSHA256Hash = this.getSHA256CertHash(certB64);
        PreconditionUtils.checkArguments(new Object[]{entity, certSHA256Hash});
        if (!certSHA256Hash.equals(entity.getCertHash())) {
            throw new ArchivesException("AP0019");
        }
    }
}
