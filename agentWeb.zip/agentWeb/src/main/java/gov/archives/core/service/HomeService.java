package gov.archives.core.service;

public interface HomeService {
    String readHomePageTextASString(String var1);
}
