package gov.archives.core.domain.entity;

import org.apache.ibatis.type.Alias;

@Alias("Role")
public class RoleEntity extends BaseEntity {
    private String roleName;
    private Integer activeStatus;

    public RoleEntity() {
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Integer getActiveStatus() {
        return this.activeStatus;
    }

    public void setActiveStatus(Integer activeStatus) {
        this.activeStatus = activeStatus;
    }
}

