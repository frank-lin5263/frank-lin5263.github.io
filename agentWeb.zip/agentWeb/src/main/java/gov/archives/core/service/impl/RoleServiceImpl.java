package gov.archives.core.service.impl;

import gov.archives.core.domain.entity.RoleEntity;
import gov.archives.core.domain.entity.RoleMenuMappingEntity;
import gov.archives.core.domain.vo.RoleMenuMapping;
import gov.archives.core.domain.vo.RoleName;
import gov.archives.core.mapper.command.RoleCommandMapper;
import gov.archives.core.mapper.command.RoleMenuMappingCommandMapper;
import gov.archives.core.mapper.query.RoleMenuMappingQueryMapper;
import gov.archives.core.mapper.query.RoleQueryMapper;
import gov.archives.core.service.MenuService;
import gov.archives.core.service.RoleService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.iii.common.exception.ApplicationException;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleQueryMapper roleQueryMapper;
    @Autowired
    private RoleCommandMapper roleCommandMapper;
    @Autowired
    private RoleMenuMappingCommandMapper roleMenuCommandMapper;
    @Autowired
    private RoleMenuMappingQueryMapper roleMenuQueryMapper;
    @Autowired
    private MenuService menuService;

    public RoleServiceImpl() {
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public RoleEntity getBySysId(UUID sysId) {
        PreconditionUtils.checkArguments(new Object[]{sysId});
        return this.roleQueryMapper.findById(sysId);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public RoleEntity getByRoleName(String roleName) {
        PreconditionUtils.checkArguments(new Object[]{roleName});
        return this.roleQueryMapper.findByRoleName(roleName);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public RoleMenuMapping getMenuMappingByRoleName(String roleName) {
        PreconditionUtils.checkArguments(new Object[]{roleName});
        List<RoleMenuMappingEntity> mappingEntities = this.roleMenuQueryMapper.findByRoleName(roleName);
        return this.mapRoleMenuMappingEntitiesToVo(mappingEntities);
    }

    private RoleMenuMapping mapRoleMenuMappingEntitiesToVo(List<RoleMenuMappingEntity> mappingEntities) {
        RoleMenuMapping mapping = new RoleMenuMapping();
        if (null != mappingEntities && !mappingEntities.isEmpty()) {
            RoleMenuMappingEntity first = (RoleMenuMappingEntity)mappingEntities.get(0);
            mapping.setRole(this.getBySysId(first.getRoleSysId()));
            mappingEntities.stream().forEach((entity) -> {
                mapping.addMenu(this.menuService.getBySysId(entity.getMenuSysId()));
            });
        }

        return mapping;
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public RoleMenuMapping getMenuMappingByRoleSysId(UUID roleSysId) {
        PreconditionUtils.checkArguments(new Object[]{roleSysId});
        List<RoleMenuMappingEntity> mappingEntities = this.roleMenuQueryMapper.findByRoleSysId(roleSysId);
        return this.mapRoleMenuMappingEntitiesToVo(mappingEntities);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void insert(RoleEntity role) {
        PreconditionUtils.checkArguments(new Object[]{role});
        this.roleCommandMapper.save(role);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void update(RoleEntity role) {
        PreconditionUtils.checkArguments(new Object[]{role});
        this.roleCommandMapper.update(role);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void delete(RoleEntity role) {
        PreconditionUtils.checkArguments(new Object[]{role});
        this.roleCommandMapper.remove(role);
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void updateRoleMenuMapping(RoleMenuMapping mapping) {
        PreconditionUtils.checkArguments(new Object[]{mapping});
        this.deleteMenuMapping(mapping.getRole());
        List<RoleMenuMappingEntity> mappingEntities = this.collectRoleMenuMappingFromVo(mapping);
        if (null != mappingEntities && !mappingEntities.isEmpty()) {
            mappingEntities.stream().forEach((entity) -> {
                this.roleMenuCommandMapper.save(entity);
            });
        }

    }

    private List<RoleMenuMappingEntity> collectRoleMenuMappingFromVo(RoleMenuMapping mapping) {
        List<RoleMenuMappingEntity> entities = new ArrayList();
        RoleEntity role = mapping.getRole();
        String creator = mapping.getCreatorAccount();
        mapping.getMenus().stream().forEach((menu) -> {
            entities.add(this.getRoleMenuMappingEntityByRoleSysIdAndMenuSysIdAndCreator(role.getSysId(), menu.getSysId(), creator));
        });
        return entities;
    }

    private RoleMenuMappingEntity getRoleMenuMappingEntityByRoleSysIdAndMenuSysIdAndCreator(UUID roleSysId, UUID menuSysId, String creator) {
        RoleMenuMappingEntity entity = RoleMenuMappingEntity.getInstanceByRoleSysIdAndMenuSysId(roleSysId, menuSysId);
        entity.initSave(creator);
        return entity;
    }

    @Transactional(
            value = "g2b2cCommandTxManager",
            propagation = Propagation.REQUIRES_NEW,
            rollbackFor = {ApplicationException.class}
    )
    public void deleteMenuMapping(RoleEntity role) {
        PreconditionUtils.checkArguments(new Object[]{role});
        this.roleMenuCommandMapper.removeByRoleSysId(role.getSysId());
    }

    public List<RoleEntity> getRoleList() {
        return this.roleQueryMapper.list();
    }

    public List<RoleEntity> getRoleListByStatus(int status) {
        return this.roleQueryMapper.getRoleByStatus(status);
    }

    @Transactional(
            value = "g2b2cQueryTxManager",
            readOnly = true
    )
    public List<RoleName> listRoleName() {
        List<RoleEntity> roleEntityList = this.roleQueryMapper.list();
        List<RoleName> roleNameList = new ArrayList();
        Iterator var3 = roleEntityList.iterator();

        while(var3.hasNext()) {
            RoleEntity roleEntity = (RoleEntity)var3.next();
            RoleName roleName = new RoleName();
            BeanUtils.copyProperties(roleEntity, roleName);
            roleNameList.add(roleName);
        }

        return roleNameList;
    }

    public List<RoleEntity> getOtherList(RoleEntity role) {
        return this.roleQueryMapper.findHaveSame(role);
    }
}
