package gov.archives.core.domain.vo;

import gov.archives.core.domain.entity.UpdateCertEntity;
import java.io.File;
import java.security.cert.X509Certificate;

public class UpdateCertVO {
    private String account;
    private X509Certificate x509;
    private File tempCerFile;
    private String hwIcCardNumber;
    private UpdateCertEntity certEntity;

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public X509Certificate getX509() {
        return this.x509;
    }

    public void setX509(X509Certificate x509) {
        this.x509 = x509;
    }

    public File getTempCerFile() {
        return this.tempCerFile;
    }

    public void setTempCerFile(File tempCerFile) {
        this.tempCerFile = tempCerFile;
    }

    public String getHwIcCardNumber() {
        return this.hwIcCardNumber;
    }

    public void setHwIcCardNumber(String hwIcCardNumber) {
        this.hwIcCardNumber = hwIcCardNumber;
    }

    public UpdateCertEntity getCertEntity() {
        return this.certEntity;
    }

    public void setCertEntity(UpdateCertEntity certEntity) {
        this.certEntity = certEntity;
    }

    private UpdateCertVO(UpdateCertVO.Builder builder) {
        this.x509 = builder.x509;
        this.tempCerFile = builder.tempCerFile;
    }

    public static UpdateCertVO.Builder newUpdateCertVO() {
        return new UpdateCertVO.Builder();
    }

    public static final class Builder {
        private X509Certificate x509;
        private File tempCerFile;
        private String hwIcCardNumber;

        private Builder() {
        }
        public UpdateCertVO build() {
            return new UpdateCertVO(this);
        }

        public UpdateCertVO.Builder setX509(X509Certificate x509) {
            this.x509 = x509;
            return this;
        }

        public UpdateCertVO.Builder setTempCerFile(File tempCerFile) {
            this.tempCerFile = tempCerFile;
            return this;
        }

        public UpdateCertVO.Builder setTempCerFile(String cardNumber) {
            this.hwIcCardNumber = cardNumber;
            return this;
        }
    }
}

