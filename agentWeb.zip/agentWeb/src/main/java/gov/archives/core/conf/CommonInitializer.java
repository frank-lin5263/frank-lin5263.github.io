package gov.archives.core.conf;

import gov.archives.core.exception.ArchivesException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Collections;
import java.util.Properties;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.iii.common.util.EnvironmentUtils;
import org.iii.common.util.FileSystemUtils;
import org.iii.common.util.IOUtils;
import org.iii.common.util.PreconditionUtils;
import org.iii.common.util.StringUtils;

public class CommonInitializer {
    protected static final String ENCRYPT_CONFIG_FILE_NAME = "encryptWeb.properties";
    protected static final String INIT_PROPERTIES_FILE_NAME = "initWeb.properties";
    protected static final String DS_CONFIG_FILE_NAME = "datasourceWeb.properties";
    protected static File initPropertiesFile = getFileFromConfiguredFolderOrClasspath("initWeb.properties");
    protected static File encryptConfigFile = getFileFromConfiguredFolderOrClasspath("encryptWeb.properties");
    protected static File dsConfigFile = getFileFromConfiguredFolderOrClasspath("datasourceWeb.properties");
    protected static String secretkey;
    protected static final String SECRETKEY_SEGMENT;
    protected static final String DEFAULT_SECRETKEY_SEGMENT = "1,5,7";
    protected static final String IS_ENCRYPT;
    protected static final String PROPERTY_IS_ENCRYPT = "IS_ENCRYPT";
    protected static final String DEFAULT_IS_ENCRYPT = "Y";
    protected static final String PROPERTY_SKSEG = "skseg";
    protected static final String PROPERTY_SECRETKEY_PART1 = "sk01";
    protected static final String PROPERTY_SECRETKEY_PART2 = "sk02";
    protected static final String PROPERTY_SECRETKEY_PART3 = "sk03";
    protected static final String PROPERTY_SECRETKEY_PART4 = "sk04";
    protected static final String PROPERTY_SECRETKEY_PART5 = "sk05";
    protected static final String PROPERTY_SECRETKEY_PART6 = "sk06";
    protected static final String PROPERTY_SECRETKEY_PART7 = "sk07";
    protected static final String PROPERTY_SECRETKEY_PART8 = "sk08";
    protected static final String PROPERTY_SECRETKEY_PART9 = "sk09";
    protected static final String PROPERTY_SECRETKEY_PART10 = "sk10";
    protected static final String[] PROPERTY_SECRETKEY_PART = new String[]{"sk01", "sk02", "sk03", "sk04", "sk05", "sk06", "sk07", "sk08", "sk09", "sk10"};
    protected static final String PROPERTY_INIT_URL = "init.jdbcUrl";
    protected static final String PROPERTY_INIT_COMMANDER = "init.commander";
    protected static final String PROPERTY_INIT_COMMANDER_PWD = "init.commanderPwd";
    protected static final String PROPERTY_INIT_QUERIER = "init.querier";
    protected static final String PROPERTY_INIT_QUERIER_PWD = "init.querierPwd";
    protected static final String INIT_URL;
    protected static final String INIT_COMMANDER;
    protected static final String INIT_COMMANDER_PWD;
    protected static final String INIT_QUERIER;
    protected static final String INIT_QUERIER_PWD;
    protected static final String EMPTY = "";

    public CommonInitializer() {
    }

    public static File getFileFromConfiguredFolderOrClasspath(String fileName) {
        try {
            return EnvironmentUtils.getFileFromConfiguredFolderOrClasspath("location.config.folder", fileName);
        } catch (URISyntaxException var2) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
        }
    }

    public static Properties loadPropertiesFromFile(File propFile) {
        if (!FileSystemUtils.isExists(propFile)) {
            throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
        } else {
            Properties prop = new Properties();
            FileInputStream fis = null;

            Properties var3;
            try {
                fis = new FileInputStream(propFile);
                prop.load(fis);
                var3 = prop;
            } catch (IOException var7) {
                throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
            } finally {
                IOUtils.closeInputStream(fis);
            }

            return var3;
        }
    }

    protected static boolean checkStringsIsEmpty(String... strings) {
        String[] var1 = strings;
        int var2 = strings.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            String string = var1[var3];
            if (StringUtils.isEmpty(string)) {
                return true;
            }
        }

        return false;
    }

    protected static boolean createFile(File file) {
        if (!IOUtils.isFileExist(file)) {
            try {
                return file.createNewFile();
            } catch (IOException var2) {
                throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
            }
        } else {
            return false;
        }
    }

    protected static void safeCloseFileOutputStream(OutputStream fos) {
        if (null != fos) {
            try {
                fos.close();
            } catch (IOException var2) {
                throw ArchivesException.getInstanceByErrorCode("SYS0000", new Object[0]);
            }
        }

    }

    protected static void reloadPropertiesFile(File propertiesFile) {
        getPropertiesConfiguration(propertiesFile).setReloadingStrategy(new FileChangedReloadingStrategy());
    }

    protected static PropertiesConfiguration getPropertiesConfiguration(Object propertiesObj) {
        PreconditionUtils.checkArguments(new Object[]{propertiesObj});

        try {
            if (propertiesObj instanceof File) {
                return new PropertiesConfiguration((File)propertiesObj);
            } else if (propertiesObj instanceof String) {
                return new PropertiesConfiguration((String)propertiesObj);
            } else {
                return propertiesObj instanceof URL ? new PropertiesConfiguration((URL)propertiesObj) : new PropertiesConfiguration();
            }
        } catch (ConfigurationException var2) {
            throw ArchivesException.getInstanceByErrorCode("SYS005", new Object[0]);
        }
    }

    protected static void storePropertiesFile(File propertyFile, Properties properties) {
        FileOutputStream fos = null;

        try {
            createFile(propertyFile);
            fos = new FileOutputStream(propertyFile);
            properties.store(fos, propertyFile.getName());
            fos.flush();
        } catch (IOException var7) {
            throw ArchivesException.getInstanceByErrorCode("SYS005", new Object[0]);
        } finally {
            safeCloseFileOutputStream(fos);
        }

        reloadPropertiesFile(propertyFile);
    }

    protected void clearPropertiesFile(File propertyFile, Properties properties) {
        Collections.list(properties.propertyNames()).forEach((propertyObject) -> {
            properties.setProperty(propertyObject.toString(), "");
        });
        storePropertiesFile(propertyFile, properties);
        reloadPropertiesFile(propertyFile);
    }

    public static Boolean isEncrypt() {
        return IS_ENCRYPT.equals("Y");
    }

    static {
        Properties propEn = loadPropertiesFromFile(encryptConfigFile);
        SECRETKEY_SEGMENT = propEn.getProperty("skseg", "1,5,7");
        IS_ENCRYPT = propEn.getProperty("IS_ENCRYPT", "Y");
        Properties propInit = loadPropertiesFromFile(initPropertiesFile);
        INIT_URL = propInit.getProperty("init.jdbcUrl", "");
        INIT_COMMANDER = propInit.getProperty("init.commander", "");
        INIT_COMMANDER_PWD = propInit.getProperty("init.commanderPwd", "");
        INIT_QUERIER = propInit.getProperty("init.querier", "");
        INIT_QUERIER_PWD = propInit.getProperty("init.querierPwd", "");
    }
}

