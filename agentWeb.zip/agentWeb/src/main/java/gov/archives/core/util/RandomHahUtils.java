package gov.archives.core.util;

import java.util.UUID;
import org.iii.security.hash.HashGenerators;

public class RandomHahUtils {
    public RandomHahUtils() {
    }

    public static String genRandomHash() {
        String randomUUID = UUID.randomUUID().toString();
        return HashGenerators.getInstanceByAlgorithm("SHA-256").getHashByString(randomUUID);
    }
}
