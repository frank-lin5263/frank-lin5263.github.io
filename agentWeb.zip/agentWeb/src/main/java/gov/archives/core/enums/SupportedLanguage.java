package gov.archives.core.enums;

public enum SupportedLanguage {
    TW,
    EN;

    private SupportedLanguage() {
    }
}
