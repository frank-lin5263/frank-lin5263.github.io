package gov.archives.core.facade.impl;

import gov.archives.core.domain.entity.UpdateCertEntity;
import gov.archives.core.domain.vo.UpdateCertVO;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.facade.UpdateCertFacade;
import gov.archives.core.mapper.command.ChangeCertCommandMapper;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.security.DigitalSignHandle;
import gov.archives.core.service.PKIIdentityService;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.service.UserInfoService;
import gov.archives.core.util.CertificateVerifier;
import gov.archives.core.util.PathUtils;
import gov.archives.core.util.UserInfoUtil;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.cert.X509Certificate;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.iii.common.util.FileSystemUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Transactional
@Service
public class UpdateCertFacadeImpl implements UpdateCertFacade {
    @Autowired
    private ChangeCertCommandMapper certCommandMapper;
    @Autowired
    private PKIIdentityService pkiIdentityService;
    @Autowired
    private DigitalSignHandle digitalSignHandle;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private SessionManageService sessionManageService;
    private File tempCerFile;

    public UpdateCertFacadeImpl() {
    }

    public File getTempCerFolder() {
        return Paths.get(this.tempCerFile.getParent()).toFile();
    }

    public boolean isSomeAccount(String account) {
        if (account == null) {
            throw new NullPointerException();
        } else {
            return account.equals(UserInfoUtil.getCurrentAccount());
        }
    }

    public void updateCert(UpdateCertVO certVO) {
        if (certVO == null) {
            throw new NullPointerException();
        } else {
            X509Certificate x509 = certVO.getX509();
            String cardNumber = certVO.getHwIcCardNumber();
            if (null == cardNumber) {
                cardNumber = String.format("%x", x509.getSerialNumber()).toUpperCase();
            }

            String cerHash = this.pkiIdentityService.getSHA256CertHash(x509);
            UpdateCertEntity entity = UpdateCertEntity.newUpdateCertEntity().setAccount(certVO.getAccount()).setCardNumber(cardNumber).setCertHash(cerHash).setAccountStatus(ACCOUNT_REVIEW_STATUS).build();
            entity.initUpdate(certVO.getAccount());
            this.certCommandMapper.update(entity);
            this.digitalSignHandle.saveCertFile(PathUtils.getCertFolderPath().resolve(cardNumber + ".cer").toFile(), x509);
        }
    }

    private String getCardNumber(String fileName) {
        return fileName.substring(0, fileName.lastIndexOf(46));
    }

    private String checkHwCardNumber(String fileName) {
        String cardNumber = this.getCardNumber(fileName);
        return this.verifyCardNumber(cardNumber);
    }

    private String verifyCardNumber(String cardNumber) {
        return null != cardNumber && 16 == cardNumber.length() && Pattern.compile("^[A-Z0-9]+$").matcher(cardNumber).matches() ? cardNumber : null;
    }

    public UpdateCertVO checkCertFile(MultipartFile multipartFile) {
        UpdateCertVO certVO = this.getX509FromFile(multipartFile);
        if (!CertificateVerifier.isSelfSigned(certVO.getX509())) {
            String certHash = this.pkiIdentityService.getSHA256CertHash(certVO.getX509());
            if (this.userInfoService.getByCertHash(certHash).size() > 0) {
                throw ArchivesException.getInstanceByErrorCode("AP0020", new Object[0]);
            } else {
                String cardNumber = this.checkHwCardNumber(multipartFile.getOriginalFilename());
                certVO.setHwIcCardNumber(cardNumber);
                return certVO;
            }
        } else {
            throw ArchivesException.getInstanceByErrorCode("AP0021", new Object[0]);
        }
    }

    private UpdateCertVO getX509FromFile(MultipartFile multipartFile) {
        if (!FilenameUtils.isExtension(multipartFile.getOriginalFilename(), "cer")) {
            throw new ArchivesException(CoreErrorMessage.findByCode("FU0000"));
        } else {
            try {
                this.tempCerFile = this.getTempFolderPath().resolve(multipartFile.getOriginalFilename()).toFile();
                FileUtils.writeByteArrayToFile(this.tempCerFile, multipartFile.getBytes());
                X509Certificate x509 = this.digitalSignHandle.readX509FromFile(this.tempCerFile);
                UpdateCertVO certVO = UpdateCertVO.newUpdateCertVO().setX509(x509).setTempCerFile(this.tempCerFile).build();
                return certVO;
            } catch (IOException var4) {
                throw ArchivesException.getInstanceByErrorCode("SYS0006", new Object[0]);
            }
        }
    }

    private Path getTempFolderPath() {
        Path path = PathUtils.buildTempFileUrlByPaths(new String[]{System.getProperty("user.home"), "agentWeb", "TempFiles"});
        if (!FileSystemUtils.isExists(path)) {
            FileSystemUtils.checkFolder(path);
        }

        return path;
    }
}
