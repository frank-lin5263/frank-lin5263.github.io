package gov.archives.core.security.access.intercept;

import gov.archives.core.domain.entity.UserInfoEntity;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;

public interface RequestConfigMappingService {
    String ROLE_PREFIX = "ROLE_";
    String CONTROLLER_JS = "Controller.js";
    String VIEW_SUFFIX = ".html";
    String CONTROLLER_PREFIX_URL = "/archivesapps/controllers/";
    String VIEW_PREFIX_URL = "/archivesapps/views/";
    String ARCH_ASSETS_ALL = "/archivesapps/assets/**";
    String ARCH_TEMPLATES_ALL = "/archivesapps/templates/**";
    String ARCH_CONTROLLERS_ALL = "/archivesapps/controllers/**";
    String ARCH_VIEWS_ALL = "/archivesapps/views/**";
    String HOME_CONTROLLER_JS = "/archivesapps/controllers/HomeController.js";
    String HOME_HTML = "/archivesapps/views/home.html";
    String REST_PREFIX_URL = "/v1/";
    String REST_SESSION_ALL = "/v1/session/**";
    String REST_CORE_MENU = "/v1/core/menu";
    String REST_CORE_MENU_ALL = "/v1/core/menu/all";
    String REST_MENU_URL_MAP = "/v1/core/rest/urlMap";
    String REST_TOKEN_ALL = "/v1/token/**";
    String LOGOUT_URL_ALL = "/logout/**";
    String CONFLICT_URL_ALL = "/conflict";
    String CHECK_CERT_HASH = "/v1/cert/check";
    String HOME_PAGE = "/v1/home";
    String ERROR_PREFIX = "/errors/*";
    String INDEX_JSP = "/index.jsp";
    String CORE_INDEX = "/core/index";
    String INDEX_HOME = "/index#/home/auth_home";
    String INDEX_HOME_NOT_AUTH = "/index#/home/not_auth";
    String CAPTCHA_JPG = "/captcha.jpg";
    String RESOURCES_PREFIX = "/resources/**";
    String PERMIT_ALL = "permitAll";

    List<RequestConfigMapping> getRequestConfigMappings();

    Collection<? extends GrantedAuthority> createAuthorities(UserInfoEntity var1);
}

