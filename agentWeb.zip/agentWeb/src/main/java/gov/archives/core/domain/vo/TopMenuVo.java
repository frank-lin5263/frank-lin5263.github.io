package gov.archives.core.domain.vo;

import gov.archives.core.domain.entity.MenuEntity;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class TopMenuVo {
    private String menuCode;
    private String menuName;
    private Map<Integer, MenuEntity> subMenus;

    public TopMenuVo() {
    }

    public String getMenuCode() {
        return this.menuCode;
    }

    public void setMenuCode(String menuCode) {
        this.menuCode = menuCode;
    }

    public String getMenuName() {
        return this.menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public Map<Integer, MenuEntity> getSubMenus() {
        return this.subMenus;
    }

    public void setSubMenus(Map<Integer, MenuEntity> subMenus) {
        this.subMenus = subMenus;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public static class Builder {
        private TopMenuVo menu = new TopMenuVo();
        private Map<Integer, MenuEntity> subMenus = new HashMap();
        private TopMenuVo.Builder self;

        public static TopMenuVo.Builder create() {
            return new TopMenuVo.Builder();
        }

        private Builder() {
            this.menu.subMenus = this.subMenus;
            this.self = this;
        }

        public TopMenuVo.Builder setMenuCode(String menuCode) {
            this.menu.menuCode = menuCode;
            return this.self;
        }

        public TopMenuVo.Builder setMenuName(String menuName) {
            this.menu.menuName = menuName;
            return this.self;
        }

        public TopMenuVo.Builder setSubMenus(Map<Integer, MenuEntity> subMenus) {
            this.subMenus.putAll(subMenus);
            return this.self;
        }

        public TopMenuVo.Builder addSubMenu(Integer menuSeq, MenuEntity subMenu) {
            this.subMenus.put(menuSeq, subMenu);
            return this.self;
        }

        public TopMenuVo build() {
            return this.menu;
        }
    }
}

