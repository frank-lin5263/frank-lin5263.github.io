package gov.archives.core.facade;

import gov.archives.core.domain.vo.UpdateCertVO;
import java.io.File;
import org.springframework.web.multipart.MultipartFile;

public interface UpdateCertFacade {
    Integer ACCOUNT_REVIEW_STATUS = -1;

    File getTempCerFolder();

    boolean isSomeAccount(String var1);

    void updateCert(UpdateCertVO var1);

    UpdateCertVO checkCertFile(MultipartFile var1);
}
