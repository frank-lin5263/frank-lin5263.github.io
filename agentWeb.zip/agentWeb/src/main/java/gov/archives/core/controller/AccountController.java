package gov.archives.core.controller;

import gov.archives.core.domain.vo.AccountForm;
import gov.archives.core.exception.ArchivesException;
import gov.archives.core.exception.ExceptionMessage;
import gov.archives.core.facade.DocumentExchangeServiceFacade;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.util.ValidatorUtil;
import gov.archives.core.validators.AccountValidator;
import java.sql.Timestamp;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/v1/core"})
public class AccountController extends RestControllerBase {
    private static final String RANDOM_CAPTCHA = "CAPTCHA";
    @Autowired
    private AccountValidator validator;
    @Autowired
    private DocumentExchangeServiceFacade documentExchangeServiceFacade;

    public AccountController() {
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.setValidator(this.validator);
    }

    @RequestMapping(
            value = {"/init/account"},
            method = {RequestMethod.GET}
    )
    public void initAccount() {
        System.out.println("initAccount: ");
    }

    @RequestMapping(
            value = {"/account"},
            method = {RequestMethod.POST}
    )
    public ResponseEntity<ExceptionMessage> accountForm(HttpServletRequest request, @Valid @RequestBody AccountForm account, BindingResult result) {
        try {
            ValidatorUtil.raiseFirstError(result);
            ExceptionMessage message = new ExceptionMessage("0", "帳號申請成功，新申請資料審查中!!");
            this.saveAccountProcess(request, account);
            return new ResponseEntity(message, HttpStatus.OK);
        } catch (AuthenticationException var5) {
            super.insertActionLog(request, "帳號申請模組", CoreErrorMessage.findByCode("AP0017"), "AP0017", "高");
            throw new ArchivesException(var5.getMessage(), var5.getCause());
        }
    }

    private void saveAccountProcess(HttpServletRequest request, AccountForm account) {
        PreconditionUtils.checkArguments(new Object[]{account});
        this.actionLogService.setSuccessActionLog(account.getAccount(), request.getRemoteAddr());
        this.checkCaptcha(request, account);
        this.documentExchangeServiceFacade.checkAccountExist(account);
        this.documentExchangeServiceFacade.saveNewAccount(account, request.getSession().getLastAccessedTime());
        this.actionLogService.saveSuccessActionAndRsysLog("帳號申請模組", "中", new Timestamp(System.currentTimeMillis()));
    }

    private void checkCaptcha(HttpServletRequest request, AccountForm account) {
        String randomCaptcha = this.getRequestSessionAttribute(request, "CAPTCHA");
        String captcha = account.getCaptcha();
        if (!randomCaptcha.equals(captcha)) {
            throw new AuthenticationServiceException("AP0001", new Throwable(CoreErrorMessage.findByCode("AP0001")));
        }
    }

    private String getRequestSessionAttribute(HttpServletRequest request, String paraKey) {
        Object parameter = request.getSession().getAttribute(paraKey);
        PreconditionUtils.checkArguments(new Object[]{parameter});
        return parameter.toString();
    }
}
