package gov.archives.core.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import gov.archives.core.exception.CoreException;
import java.io.IOException;
import java.util.Locale;
import org.iii.common.util.StringUtils;

public abstract class ReportUtils {
    private ReportUtils() {
    }

    public static JsonNode convertBeanToJsonNode(Object resultBean) throws CoreException {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectWriter objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
            return objectMapper.readTree(objectWriter.writeValueAsString(resultBean));
        } catch (IOException var3) {
            throw new CoreException(var3, "PR9003");
        }
    }

    public static Boolean equalsReportType(String reportType, String exportType) {
        return !StringUtils.isEmpty(reportType) && reportType.toUpperCase(Locale.ENGLISH).equals(exportType);
    }
}

