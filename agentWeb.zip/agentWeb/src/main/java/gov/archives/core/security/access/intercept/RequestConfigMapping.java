package gov.archives.core.security.access.intercept;

import gov.archives.core.exception.ArchivesException;
import gov.archives.core.message.CoreErrorMessage;
import java.util.Collection;
import java.util.Collections;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class RequestConfigMapping {
    private final RequestMatcher matcher;
    private final Collection<ConfigAttribute> attributes;

    public RequestConfigMapping(RequestMatcher matcher, ConfigAttribute attribute) {
        this(matcher, (Collection)Collections.singleton(attribute));
    }

    public RequestConfigMapping(RequestMatcher matcher, Collection<ConfigAttribute> attributes) {
        if (matcher == null) {
            throw new ArchivesException(CoreErrorMessage.findByCode("SEC001"));
        } else {
            this.matcher = matcher;
            this.attributes = attributes;
        }
    }

    public RequestMatcher getMatcher() {
        return this.matcher;
    }

    public Collection<ConfigAttribute> getAttributes() {
        return this.attributes;
    }
}

