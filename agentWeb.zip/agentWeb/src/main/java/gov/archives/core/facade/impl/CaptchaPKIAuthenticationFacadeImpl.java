package gov.archives.core.facade.impl;

import gov.archives.core.domain.entity.LogInControlEntity;
import gov.archives.core.domain.entity.UserInfoEntity;
import gov.archives.core.domain.vo.AccountDetail;
import gov.archives.core.domain.vo.AuthInfoVO;
import gov.archives.core.domain.vo.SignInMeta;
import gov.archives.core.domain.vo.SignInMeta.Builder;
import gov.archives.core.facade.CaptchaPKIAuthenticationFacade;
import gov.archives.core.message.CoreErrorMessage;
import gov.archives.core.service.LogInControlService;
import gov.archives.core.service.PKIIdentityService;
import gov.archives.core.service.SessionManageService;
import gov.archives.core.service.UserInfoService;
import org.iii.common.util.PreconditionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Service;

@Service
public class CaptchaPKIAuthenticationFacadeImpl implements CaptchaPKIAuthenticationFacade {
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private LogInControlService logInControlService;
    @Autowired
    private SessionManageService sessionManageService;
    @Autowired
    private PKIIdentityService pkiIdentityService;
    private LogInControlEntity lastLogin;

    public CaptchaPKIAuthenticationFacadeImpl() {
    }

    public UserInfoEntity getUserInfoByAccount(String account) {
        PreconditionUtils.checkArguments(new Object[]{account});
        return this.userInfoService.getByAccount(account);
    }

    public void checkTryCount(AuthInfoVO authInfo) {
        PreconditionUtils.checkArguments(new Object[]{authInfo});
        this.setLastLoginInfo(authInfo.getAccount());
        if (null != this.lastLogin && this.lastLogin.getLoginCount() == 3 && authInfo.getLastAccessedTime().before(this.lastLogin.getMaxLimitLoginTime())) {
            this.exceptionHandler("AP0008");
        }

    }

    public void checkCaptcha(String randomCaptcha, String currentCaptcha, AuthInfoVO authInfo) {
        PreconditionUtils.checkArguments(new Object[]{randomCaptcha, currentCaptcha, authInfo});
        if (!randomCaptcha.equals(currentCaptcha)) {
            this.checkLoginCount(authInfo);
            this.exceptionHandler("AP0001");
        }

    }

    public void checkAccountStatus(AuthInfoVO authInfo, UserInfoEntity userInfo) {
        PreconditionUtils.checkArguments(new Object[]{authInfo});
        if (null == userInfo) {
            this.checkLoginCount(authInfo);
            this.exceptionHandler("AP0002");
        } else if (userInfo.getActiveStatus().equals(-1)) {
            this.checkLoginCount(authInfo);
            this.exceptionHandler("AP0013");
        } else if (userInfo.getActiveStatus().equals(0)) {
            this.checkLoginCount(authInfo);
            this.exceptionHandler("AP0014");
        }

        authInfo.setOrgUnitId(userInfo.getOrgUnitId());
        if (authInfo.getCardNum().equals("連線成功")) {
            authInfo.setCardNum(userInfo.getCertCardNum());
        }

    }

    public void resetAccountTryCount() {
        if (null != this.lastLogin) {
            this.logInControlService.delete(this.lastLogin);
        }

    }

    public void setAccountSession(AuthInfoVO authInfo, String requestSessionId, Integer timeOut) {
        SignInMeta signInMeta = Builder.create().setOrgUnitId(authInfo.getOrgUnitId()).setCardNumber(authInfo.getCardNum()).build();
        AccountDetail detail = gov.archives.core.domain.vo.AccountDetail.Builder.create().setAccount(authInfo.getAccount()).setOrgUnitId(authInfo.getOrgUnitId()).setSessionId(requestSessionId).setRemoteAddress(authInfo.getIpAddress()).setTimeOut(timeOut).setSignInMeta(signInMeta).build();
        this.sessionManageService.setAccountDetail(detail);
    }

    private void checkLoginCount(AuthInfoVO authInfo) {
        if (null == this.lastLogin) {
            this.lastLogin = new LogInControlEntity();
            this.lastLogin.initSysId();
            this.lastLogin.setSessionId(authInfo.getSessionId());
            this.lastLogin.setLoginAccount(authInfo.getAccount());
            this.lastLogin.setCertCardNum(authInfo.getCardNum());
            this.lastLogin.setLoginTime(authInfo.getLastAccessedTime());
            this.lastLogin.setRemoteIp(authInfo.getIpAddress());
            this.lastLogin.setLoginCount(1);
            this.logInControlService.insert(this.lastLogin);
        } else {
            Integer loginCount = this.lastLogin.getLoginCount();
            if (loginCount < 3) {
                this.lastLogin.setLoginCount(loginCount + 1);
            } else {
                this.lastLogin.setLoginTime(authInfo.getLastAccessedTime());
                this.lastLogin.setLoginCount(1);
            }

            this.logInControlService.update(this.lastLogin);
        }

    }

    private void setLastLoginInfo(String account) {
        this.lastLogin = this.logInControlService.getByAccountMaxlimitTime(account);
    }

    private void exceptionHandler(String errorCode) {
        throw new AuthenticationServiceException(errorCode, new Throwable(CoreErrorMessage.findByCode(errorCode)));
    }
}
