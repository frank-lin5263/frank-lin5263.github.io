package gov.archives.core.domain.vo;

public class AccountDetail {
    private String account;
    private String orgUnitId;
    private String sessionId;
    private String remoteAddress;
    private Integer timeOut;
    private SignInMeta signInMeta;

    public AccountDetail() {
    }

    public String getAccount() {
        return this.account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getOrgUnitId() {
        return this.orgUnitId;
    }

    public void setOrgUnitId(String orgUnitId) {
        this.orgUnitId = orgUnitId;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getRemoteAddress() {
        return this.remoteAddress;
    }

    public void setRemoteAddress(String remoteAddress) {
        this.remoteAddress = remoteAddress;
    }

    public Integer getTimeOut() {
        return this.timeOut;
    }

    public void setTimeOut(Integer timeOut) {
        this.timeOut = timeOut;
    }

    public SignInMeta getSignInMeta() {
        return this.signInMeta;
    }

    public void setSignInMeta(SignInMeta signInMeta) {
        this.signInMeta = signInMeta;
    }

    public static final class Builder {
        private String account;
        private String orgUnitId;
        private String sessionId;
        private String remoteAddress;
        private Integer timeOut;
        private SignInMeta signInMeta;

        private Builder() {
        }

        public static AccountDetail.Builder create() {
            return new AccountDetail.Builder();
        }

        public AccountDetail build() {
            AccountDetail detail = new AccountDetail();
            detail.setAccount(this.account);
            detail.setOrgUnitId(this.orgUnitId);
            detail.setSessionId(this.sessionId);
            detail.setRemoteAddress(this.remoteAddress);
            detail.setTimeOut(this.timeOut);
            detail.setSignInMeta(this.signInMeta);
            return detail;
        }

        public AccountDetail.Builder setAccount(String account) {
            this.account = account;
            return this;
        }

        public AccountDetail.Builder setOrgUnitId(String orgUnitId) {
            this.orgUnitId = orgUnitId;
            return this;
        }

        public AccountDetail.Builder setSessionId(String sessionId) {
            this.sessionId = sessionId;
            return this;
        }

        public AccountDetail.Builder setRemoteAddress(String remoteAddress) {
            this.remoteAddress = remoteAddress;
            return this;
        }

        public AccountDetail.Builder setTimeOut(Integer timeOut) {
            this.timeOut = timeOut;
            return this;
        }

        public AccountDetail.Builder setSignInMeta(SignInMeta signInMeta) {
            this.signInMeta = signInMeta;
            return this;
        }
    }
}

