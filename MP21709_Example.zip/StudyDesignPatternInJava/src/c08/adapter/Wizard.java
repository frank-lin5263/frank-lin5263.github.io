package c08.adapter;
/**
 * 法師介面(Target)
 */
public interface Wizard {
	// 丟火球
	void fireBall();
}
