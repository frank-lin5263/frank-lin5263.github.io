package c10.template.adventurer;
/**
 * 冒險者-劍士
 */
public class Sabar extends Adventurer {
	public Sabar(){
		super.type = "Sabar";
		super.level = 10;	//劍士等級就普普
	}
}
