package c21.bridge.descript.a;

public class 掛號普通信 extends 普通信件{

}
