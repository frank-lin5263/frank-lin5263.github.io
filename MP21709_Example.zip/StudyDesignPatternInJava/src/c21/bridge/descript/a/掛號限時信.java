package c21.bridge.descript.a;

public abstract class 掛號限時信 extends 限時信件 {

}
