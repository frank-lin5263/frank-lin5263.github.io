package c21.bridge.descript.a;

public class 雙掛號普通信 extends 普通信件{

}
