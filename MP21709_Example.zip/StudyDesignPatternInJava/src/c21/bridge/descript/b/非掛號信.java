package c21.bridge.descript.b;

public class 非掛號信 extends 信件{
	@Override
	void resgiterState() {
		System.out.println("這是封信不是註冊信，收件人不用簽名  ");		
	}
}
