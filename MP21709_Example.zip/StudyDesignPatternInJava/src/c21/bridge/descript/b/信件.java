package c21.bridge.descript.b;

public abstract class 信件 {
	// 平信，掛號信，雙掛號信等
	abstract void resgiterState();
}
