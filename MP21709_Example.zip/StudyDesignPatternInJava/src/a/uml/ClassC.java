package a.uml;

public class ClassC {

}
