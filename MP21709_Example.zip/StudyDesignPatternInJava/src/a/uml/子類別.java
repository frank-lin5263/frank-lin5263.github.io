package a.uml;
@SuppressWarnings("unused")
public class 子類別  extends 父類別{
	private String 屬性;
	public void 方法(){
		new ClassA();
	};
}
