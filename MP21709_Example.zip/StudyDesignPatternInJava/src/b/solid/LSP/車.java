package b.solid.LSP;

public interface 車 {
	void 路上跑();
}
