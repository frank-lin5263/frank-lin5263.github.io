package c03.abstractfactory.factory;
/**
 * 皮甲(ConcreteProduct)-弓箭手上衣
 */
public class Leather extends Clothes {
	
}
