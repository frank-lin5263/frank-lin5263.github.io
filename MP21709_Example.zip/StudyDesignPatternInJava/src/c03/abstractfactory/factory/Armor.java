package c03.abstractfactory.factory;
/**
 * 盔甲(ConcreteProduct)-鬥士上衣
 */
public class Armor extends Clothes {

}
