package c03.abstractfactory.factory;
/**
 * 弓(ConcreteProduct)-弓箭手武器
 */
public class Bow extends Weapon {

}
