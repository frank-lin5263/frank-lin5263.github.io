package c01.simpleFactory.village;

public class ProductB implements Product {

}
