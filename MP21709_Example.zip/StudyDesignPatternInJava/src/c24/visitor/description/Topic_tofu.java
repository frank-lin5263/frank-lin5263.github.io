package c24.visitor.description;
// 豆腐
public class Topic_tofu implements Topic {

}
