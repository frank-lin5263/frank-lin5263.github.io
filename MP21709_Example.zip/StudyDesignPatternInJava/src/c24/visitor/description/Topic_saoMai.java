package c24.visitor.description;
//燒賣
public class Topic_saoMai implements Topic {

}
