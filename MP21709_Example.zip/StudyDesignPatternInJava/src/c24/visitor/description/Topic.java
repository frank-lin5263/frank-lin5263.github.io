package c24.visitor.description;
/**
 * 指定的比賽菜餚
 */
public interface Topic {

}
