package c13.proxy.game;
public interface GameDisplay {
	/**
	 * 顯示畫面
	 */
	void display();
}
