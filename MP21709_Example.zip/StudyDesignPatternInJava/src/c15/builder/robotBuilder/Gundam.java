
package c15.builder.robotBuilder;
/**
 * 鋼彈-實體機器人(ConcreteProduct)
 */
public class Gundam extends IRobot{

}
