package com.apress.hibernaterecipes.chapter14.services;

public class ExternalServiceTest {

}
